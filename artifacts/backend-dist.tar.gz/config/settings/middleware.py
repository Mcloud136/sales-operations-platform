from apps.common.models import set_isolation_user, reset_isolation_user


class IsolationContextMiddleware:
    """Middleware that sets the data isolation user context for each request."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        token = self.get_response
        if request.user and request.user.is_authenticated:
            set_isolation_user(request.user)
        else:
            reset_isolation_user()
        response = self.get_response(request)
        reset_isolation_user()
        return response
