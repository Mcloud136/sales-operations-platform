import uuid

from apps.common.models import set_isolation_user, reset_isolation_user
from config.settings.logging_filters import set_request_id, reset_request_id


class IsolationContextMiddleware:
    """Middleware that sets the data isolation user context and request_id for each request."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Set request_id for log correlation
        request_id = str(uuid.uuid4())[:8]
        set_request_id(request_id)
        request.request_id = request_id

        if request.user and request.user.is_authenticated:
            set_isolation_user(request.user)
        else:
            reset_isolation_user()

        try:
            response = self.get_response(request)
        finally:
            reset_isolation_user()
            reset_request_id()

        response["X-Request-ID"] = request_id
        return response
