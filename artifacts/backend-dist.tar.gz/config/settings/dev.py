"""
Development settings.

WARNING: Do NOT use this settings module in production.
    Set DJANGO_SETTINGS_MODULE=config.settings.base for production.
"""
from .base import *  # noqa: F401, F403

DEBUG = True  # noqa: F405 — Intentionally overridden for development

ALLOWED_HOSTS = ["*"]

INSTALLED_APPS += [  # noqa: F405
    "django_extensions",
]

MIDDLEWARE += [  # noqa: F405
    "config.settings.middleware.IsolationContextMiddleware",
    "config.settings.request_logging.RequestLoggingMiddleware",
]

CORS_ALLOW_ALL_ORIGINS = True  # Development only

# Email (console backend for dev)
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
