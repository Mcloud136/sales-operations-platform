"""
Development settings.
"""
from .base import *  # noqa: F401, F403

DEBUG = True

ALLOWED_HOSTS = ["*"]

INSTALLED_APPS += [  # noqa: F405
    "django_extensions",
]

MIDDLEWARE += [  # noqa: F405
    "config.settings.middleware.IsolationContextMiddleware",
]

# Logging
LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
        },
    },
    "root": {
        "handlers": ["console"],
        "level": "INFO",
    },
}

# Email (console backend for dev)
EMAIL_BACKEND = "django.core.mail.backends.console.EmailBackend"
