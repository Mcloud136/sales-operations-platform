"""Logging filter that injects request_id into log records."""
import logging
import threading

# Thread-local storage for request_id
_local = threading.local()


def set_request_id(request_id: str):
    _local.request_id = request_id


def get_request_id() -> str:
    return getattr(_local, "request_id", "-")


def reset_request_id():
    _local.request_id = "-"


class RequestIDFilter(logging.Filter):
    """Inject request_id from thread-local into every log record."""

    def filter(self, record):
        record.request_id = getattr(_local, "request_id", "-")
        return True
