"""Lightweight request/response logging middleware."""
import logging
import time

logger = logging.getLogger("django.request")


class RequestLoggingMiddleware:
    """Log method, path, status code and duration for every request.

    Handles exceptions from views correctly — logs the request info
    even when the view raises an unhandled exception (e.g. 500 errors).
    """

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        start = time.monotonic()
        try:
            response = self.get_response(request)
        except Exception:
            duration_ms = (time.monotonic() - start) * 1000
            logger.error(
                "%s %s 500 (%.1fms) [unhandled exception]",
                request.method,
                request.path,
                duration_ms,
                exc_info=True,
            )
            raise
        duration_ms = (time.monotonic() - start) * 1000
        logger.info(
            "%s %s %d (%.1fms)",
            request.method,
            request.path,
            response.status_code,
            duration_ms,
        )
        return response
