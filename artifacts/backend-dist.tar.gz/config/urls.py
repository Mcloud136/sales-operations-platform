"""Root URL configuration."""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path("admin/", admin.site.urls),
    path("api/v1/auth/", include("apps.users.urls")),
    path("api/v1/setup/", include("apps.setup.urls")),
    path("api/v1/", include("apps.customers.urls")),
    path("api/v1/", include("apps.leads.urls")),
    path("api/v1/bids/", include("apps.bids.urls")),
    path("api/v1/", include("apps.approvals.urls")),
    path("api/v1/", include("apps.contracts.urls")),
    path("api/v1/", include("apps.reports.urls")),
    path("api/v1/notifications/", include("apps.notifications.urls")),
]
