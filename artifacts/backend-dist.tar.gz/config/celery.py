"""
Celery application configuration.

Celery Beat is configured here with the dashboard KPI refresh schedule.
Celery uses Valkey db 1 as the message broker.
"""

from celery import Celery
from celery.schedules import crontab

# Django settings module
app = Celery("sales_ops")

# Load Django settings
app.config_from_object("django.conf:settings", namespace="CELERY")

# Auto-discover tasks in all installed apps
app.autodiscover_tasks()

# Celery Beat schedule
app.conf.beat_schedule = {
    # Dashboard KPI pre-aggregation: every 15 minutes
    "refresh-dashboard-kpis": {
        "task": "reports.refresh_dashboard_kpis",
        "schedule": 900.0,  # 15 minutes in seconds
    },
    # Data archival: daily at 03:00 UTC (soft-deleted records past retention)
    "archive-soft-deleted": {
        "task": "common.archive_soft_deleted_task",
        "schedule": crontab(hour=3, minute=0),  # daily 03:00
        "args": [],  # no arguments -> archive all models
    },
}
app.conf.timezone = "UTC"
