import pytest
from django.utils import timezone
from django.db import models
from apps.common.models import (
    UUIDv7ModelMixin,
    TimestampMixin,
    SoftDeleteModel,
    ActiveManager,
    DataIsolationManager,
    set_isolation_user,
    reset_isolation_user,
    _isolation_user,
)


# ---------------------------------------------------------------------------
# Concrete test model that uses all mixins
# ---------------------------------------------------------------------------

class TestModel(UUIDv7ModelMixin, TimestampMixin, SoftDeleteModel):
    class Meta(UUIDv7ModelMixin.Meta, TimestampMixin.Meta, SoftDeleteModel.Meta):
        app_label = "common"
        abstract = False


class IsolatedModel(UUIDv7ModelMixin, TimestampMixin, SoftDeleteModel):
    assigned_to_id = models.UUIDField()  # simplified FK reference

    _isolation_field = "assigned_to"

    class Meta(UUIDv7ModelMixin.Meta, TimestampMixin.Meta, SoftDeleteModel.Meta):
        app_label = "common"
        abstract = False


# ---------------------------------------------------------------------------
# UUIDv7ModelMixin tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_uuidv7_primary_key():
    """Models with UUIDv7ModelMixin should have a string UUID primary key."""
    obj = TestModel()
    assert hasattr(obj, "id")
    # uuid7() returns a UUID object; calling str gives the canonical form
    generated_id = obj.id
    assert generated_id is not None
    # UUIDv7 strings start with a digit (first character of version is the
    # variant/version nibble, but the high bits encode a timestamp so
    # UUIDv7 always starts with 0-7).
    assert str(generated_id)[0] in "01234567"


@pytest.mark.django_db
def test_uuidv7_values_are_unique():
    """Each instance should get a different UUIDv7."""
    obj_a = TestModel()
    obj_b = TestModel()
    assert obj_a.id != obj_b.id


@pytest.mark.django_db
def test_uuidv7_monotonically_ordered():
    """UUIDv7 values generated in sequence should be sortable (timestamp-ordered)."""
    ids = [TestModel().id for _ in range(20)]
    str_ids = [str(i) for i in ids]
    assert str_ids == sorted(str_ids), "UUIDv7 IDs should be monotonically ordered"


# ---------------------------------------------------------------------------
# TimestampMixin tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_created_at_auto_set():
    """created_at should be set on first save."""
    obj = TestModel()
    obj.save()
    assert obj.created_at is not None
    assert obj.created_at <= timezone.now()


@pytest.mark.django_db
def test_updated_at_changes_on_save():
    """updated_at should update on each save."""
    obj = TestModel()
    obj.save()
    first_updated = obj.updated_at
    # Force a DB update to trigger auto_now
    obj.save(update_fields=["updated_at"])
    assert obj.updated_at >= first_updated


# ---------------------------------------------------------------------------
# SoftDeleteModel tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_soft_delete_sets_flag():
    """Calling soft_delete() should set is_deleted=True and deleted_at."""
    obj = TestModel()
    obj.save()
    obj.soft_delete()
    assert obj.is_deleted is True
    assert obj.deleted_at is not None


@pytest.mark.django_db
def test_active_manager_excludes_deleted():
    """ActiveManager (default manager) should exclude soft-deleted records."""
    obj_a = TestModel()
    obj_a.save()
    obj_b = TestModel()
    obj_b.save()
    obj_a.soft_delete()

    active_ids = set(TestModel.objects.values_list("id", flat=True))
    all_ids = set(TestModel.all_objects.values_list("id", flat=True))

    assert obj_a.id not in active_ids
    assert obj_b.id in active_ids
    assert obj_a.id in all_ids
    assert obj_b.id in all_ids


@pytest.mark.django_db
def test_all_objects_includes_deleted():
    """all_objects manager should return both active and deleted records."""
    obj_a = TestModel()
    obj_a.save()
    obj_b = TestModel()
    obj_b.save()
    obj_a.soft_delete()

    assert TestModel.all_objects.count() == 2
    assert TestModel.objects.count() == 1


@pytest.mark.django_db
def test_active_manager_is_default():
    """The default manager on SoftDeleteModel should be ActiveManager."""
    assert isinstance(TestModel.objects, ActiveManager)


# ---------------------------------------------------------------------------
# DataIsolation tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_isolation_manager_no_user_raises():
    """DataIsolationManager should raise RuntimeError when no user is in context."""
    with pytest.raises(RuntimeError, match="DataIsolation: no user in context"):
        list(IsolatedModel.objects.all())


@pytest.mark.django_db
def test_isolation_with_bypass():
    """bypass_isolation() should return unfiltered queryset when no user in context."""
    # No user in context -- normal manager would raise
    qs = IsolatedModel.objects.bypass_isolation()
    # Should not raise; bypass returns the parent manager queryset
    list(qs)  # noqa: B018 -- just ensuring no exception


@pytest.mark.django_db
def test_bypass_raises_when_user_in_context():
    """bypass_isolation() should raise RuntimeError when a user is in context."""
    user_mock = type("User", (), {"id": "test-uuid", "role": "system_admin"})()
    set_isolation_user(user_mock)
    try:
        with pytest.raises(RuntimeError, match="bypass_isolation.*must not be called"):
            IsolatedModel.objects.bypass_isolation()
    finally:
        reset_isolation_user()


@pytest.mark.django_db
def test_isolated_queryset_no_user():
    """isolated_queryset() should return unfiltered data when no user in context."""
    qs = IsolatedModel.objects.isolated_queryset()
    # Should not raise; returns unfiltered queryset for Celery/system tasks
    list(qs)  # noqa: B018 -- just ensuring no exception


@pytest.mark.django_db
def test_isolated_queryset_with_user():
    """isolated_queryset() should apply isolation when a user is in context."""
    user_mock = type(
        "User",
        (),
        {"id": "test-uuid", "role": "sales_rep", "department_id": None},
    )()
    set_isolation_user(user_mock)
    try:
        qs = IsolatedModel.objects.isolated_queryset()
        # Should not raise; returns queryset with isolation filter applied
        list(qs)  # noqa: B018 -- just ensuring no exception
    finally:
        reset_isolation_user()


@pytest.mark.django_db
def test_set_and_reset_isolation_user():
    """set_isolation_user and reset_isolation_user should manage the ContextVar."""
    user_mock = type("User", (), {"id": "test-uuid", "role": "system_admin"})()
    set_isolation_user(user_mock)
    assert _isolation_user.get() is user_mock
    reset_isolation_user()
    assert _isolation_user.get() is None
