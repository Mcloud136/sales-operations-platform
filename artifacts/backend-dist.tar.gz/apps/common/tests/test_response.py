import pytest
from apps.common.response import success_response, error_response


def test_success_response_basic():
    """success_response should return correct structure."""
    result = success_response({"id": 1, "name": "Test"}, "Fetched successfully")
    assert result["success"] is True
    assert result["data"] == {"id": 1, "name": "Test"}
    assert result["message"] == "Fetched successfully"


def test_success_response_default_message():
    """success_response should use 'Success' as default message."""
    result = success_response({"key": "value"})
    assert result["success"] is True
    assert result["message"] == "Success"


def test_success_response_none_data():
    """success_response with None data should still work."""
    result = success_response(None, "No data")
    assert result["success"] is True
    assert result["data"] is None


def test_error_response_basic():
    """error_response should return correct structure."""
    result = error_response("Something went wrong", 400)
    assert result["success"] is False
    assert result["error"] == "Something went wrong"
    assert result["status_code"] == 400


def test_error_response_default_status():
    """error_response should use 400 as default status code."""
    result = error_response("Bad request")
    assert result["status_code"] == 400


def test_error_response_with_500():
    """error_response should accept custom status codes."""
    result = error_response("Server error", 500)
    assert result["status_code"] == 500
