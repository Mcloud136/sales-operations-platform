import pytest
from rest_framework.test import APIClient, force_authenticate
from rest_framework.views import APIView
from rest_framework.response import Response as DRFResponse
from django.urls import path

from apps.common.pagination import CursorPagination


class DummyListView(APIView):
    """Dummy view that returns a paginated list of items."""

    def get(self, request):
        items = [{"id": i, "name": f"item-{i}"} for i in range(50)]
        paginator = CursorPagination()
        page = paginator.paginate_queryset(items, request, view=self)
        return paginator.get_paginated_response(page)


urlpatterns_dummy = [path("dummy-list/", DummyListView.as_view())]


@pytest.mark.django_db
def test_cursor_pagination_returns_page():
    """CursorPagination should return a page of results."""
    client = APIClient()
    from django.urls import reverse

    # Use the dummy list endpoint directly
    from apps.common.pagination import CursorPagination

    # Test pagination behavior directly without URL routing
    class FakeRequest:
        def __init__(self):
            self.query_params = {}
            self.GET = {}

    items = [{"id": i, "name": f"item-{i}"} for i in range(50)]
    paginator = CursorPagination()
    page = paginator.paginate_queryset(items, FakeRequest(), view=None)

    assert page is not None
    assert len(page) == 20  # default page_size


@pytest.mark.django_db
def test_cursor_pagination_has_next_cursor():
    """Paginated response should include 'next' cursor when more items exist."""
    class FakeRequest:
        def __init__(self):
            self.query_params = {}
            self.GET = {}

    items = [{"id": i, "name": f"item-{i}"} for i in range(50)]
    paginator = CursorPagination()
    page = paginator.paginate_queryset(items, FakeRequest(), view=None)
    response = paginator.get_paginated_response(page)

    assert "next" in response.data
    assert response.data["next"] is not None  # More items exist
    assert "previous" in response.data
    assert response.data["previous"] is None  # No previous on first page
