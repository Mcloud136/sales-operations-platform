import pytest
from rest_framework.test import APIRequestFactory
from rest_framework.views import APIView
from rest_framework.response import Response

from apps.common.permissions import IsRoleAllowed


class DummyView(APIView):
    permission_classes = [IsRoleAllowed]
    allowed_roles = ["system_admin", "sales_manager"]

    def get(self, request):
        return Response({"ok": True})


@pytest.mark.django_db
def test_role_allowed_permits_admin():
    """IsRoleAllowed should permit users with allowed role."""
    from apps.users.models import User

    user = User.objects.create_user(
        username="admin1",
        email="admin1@example.com",
        role="system_admin",
    )

    factory = APIRequestFactory()
    request = factory.get("/")
    request.user = user

    view = DummyView()
    view.request = request
    view.format_kwarg = None

    assert view.check_permissions(request) is None  # No exception = permitted


@pytest.mark.django_db
def test_role_allowed_permits_sales_manager():
    """IsRoleAllowed should permit sales_manager when in allowed_roles."""
    from apps.users.models import User

    user = User.objects.create_user(
        username="mgr1",
        email="mgr1@example.com",
        role="sales_manager",
    )

    factory = APIRequestFactory()
    request = factory.get("/")
    request.user = user

    view = DummyView()
    view.request = request
    view.format_kwarg = None

    assert view.check_permissions(request) is None


@pytest.mark.django_db
def test_role_allowed_denies_sales_rep():
    """IsRoleAllowed should deny users with non-allowed role."""
    from apps.users.models import User
    from rest_framework.exceptions import PermissionDenied

    user = User.objects.create_user(
        username="rep1",
        email="rep1@example.com",
        role="sales_rep",
    )

    factory = APIRequestFactory()
    request = factory.get("/")
    request.user = user

    view = DummyView()
    view.request = request
    view.format_kwarg = None

    with pytest.raises(PermissionDenied):
        view.check_permissions(request)


@pytest.mark.django_db
def test_role_allowed_denies_unauthenticated():
    """IsRoleAllowed should deny unauthenticated users."""
    from rest_framework.exceptions import NotAuthenticated
    from rest_framework.test import APIRequestFactory

    factory = APIRequestFactory()
    request = factory.get("/")
    request.user = type("AnonUser", (), {"is_authenticated": False})()

    view = DummyView()
    view.request = request
    view.format_kwarg = None

    with pytest.raises(NotAuthenticated):
        view.check_permissions(request)
