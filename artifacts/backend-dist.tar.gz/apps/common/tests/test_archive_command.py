import pytest
from io import StringIO
from django.core.management import call_command
from apps.common.models import SoftDeleteModel


@pytest.mark.django_db
def test_archive_dry_run_no_records():
    """Dry run with no soft-deleted records produces 0 count."""
    out = StringIO()
    call_command('archive_soft_deleted', '--dry-run', stdout=out)
    assert 'Total archived: 0' in out.getvalue()


@pytest.mark.django_db
def test_archive_skips_recently_deleted(customer_factory):
    """Records deleted within retention window are NOT archived."""
    customer = customer_factory()
    customer.soft_delete()
    out = StringIO()
    call_command('archive_soft_deleted', '--dry-run', stdout=out)
    # Should be 0 since deleted just now (within 90-day retention)
    assert 'customers.customer] No records to archive' in out.getvalue()
