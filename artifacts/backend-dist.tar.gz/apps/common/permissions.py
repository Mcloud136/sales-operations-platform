from rest_framework import permissions


class IsRoleAllowed(permissions.BasePermission):
    """
    Permission class that checks if the authenticated user has an allowed role.

    Must be used with the `allowed_roles` attribute on the ViewSet/View:

        class MyViewSet(ViewSet):
            permission_classes = [IsRoleAllowed]
            allowed_roles = ["system_admin", "sales_manager"]
    """

    def has_permission(self, request, view):
        if not request.user or not request.user.is_authenticated:
            self.permission_denied(
                request,
                message="Authentication required.",
                code="not_authenticated",
            )

        allowed_roles = getattr(view, "allowed_roles", [])
        user_role = getattr(request.user, "role", None)

        if user_role not in allowed_roles:
            self.permission_denied(
                request,
                message=f"Role '{user_role}' is not allowed. "
                f"Required: {', '.join(allowed_roles)}",
                code="role_not_allowed",
            )

        return True
