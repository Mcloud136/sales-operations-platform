# Placeholder for custom filter backends
# django-filter is configured globally in settings; this module is reserved
# for app-specific filter backend additions in later phases.
