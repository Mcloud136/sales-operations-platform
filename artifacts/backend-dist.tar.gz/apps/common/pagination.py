from rest_framework.pagination import CursorPagination as DRFCursorPagination


class CursorPagination(DRFCursorPagination):
    """Cursor-based pagination for large datasets.

    Cursor pagination is more performant than offset pagination for large
    tables because it does not require counting total records.
    """

    page_size = 20
    ordering = "-created_at"
