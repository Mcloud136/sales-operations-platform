"""
Common models, mixins, and utilities shared across all apps.

Provides:
- UUIDv7ModelMixin: timestamp-ordered UUID primary key
- TimestampMixin: created_at / updated_at fields
- SoftDeleteModel: soft-delete with ActiveManager
- DataIsolationManager: automatic ORM-level data isolation via ContextVar
"""

import uuid
import logging
from threading import ContextVar
from typing import TYPE_CHECKING

from django.db import models
from django.utils import timezone
from uuid7 import uuid7

if TYPE_CHECKING:
    from apps.users.models import User

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Data Isolation ContextVar
# ---------------------------------------------------------------------------

_isolation_user: ContextVar["User | None"] = ContextVar(
    "isolation_user", default=None
)


def set_isolation_user(user: "User") -> None:
    """Set the current user for data isolation context."""
    _isolation_user.set(user)


def reset_isolation_user() -> None:
    """Reset the data isolation context (remove current user)."""
    _isolation_user.set(None)


def get_isolation_user() -> "User | None":
    """Get the current isolation user (read-only accessor)."""
    return _isolation_user.get()


# ---------------------------------------------------------------------------
# UUIDv7 Primary Key Mixin
# ---------------------------------------------------------------------------

class UUIDv7ModelMixin(models.Model):
    """Mixin that provides a UUIDv7 primary key.

    UUIDv7 is timestamp-ordered, making it index-friendly in PostgreSQL
    and preserving insertion order locality. Far superior to UUIDv4 for B+ tree
    performance.
    """

    id = models.UUIDField(primary_key=True, default=uuid7, editable=False)

    class Meta:
        abstract = True


# ---------------------------------------------------------------------------
# Timestamp Mixin
# ---------------------------------------------------------------------------

class TimestampMixin(models.Model):
    """Mixin that provides created_at and updated_at timestamps."""

    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True, db_index=True)

    class Meta:
        abstract = True


# ---------------------------------------------------------------------------
# Soft Delete
# ---------------------------------------------------------------------------

class ActiveManager(models.Manager):
    """Manager that filters out soft-deleted records by default."""

    def get_queryset(self):
        return super().get_queryset().filter(is_deleted=False)


class SoftDeleteModel(models.Model):
    """Abstract model providing soft-delete functionality.

    - `is_deleted`: Boolean flag (default False, db_index=True)
    - `deleted_at`: Timestamp of deletion (null when active)
    - `objects`: ActiveManager -- excludes soft-deleted records
    - `all_objects`: Unfiltered manager -- includes all records
    """

    is_deleted = models.BooleanField(default=False, db_index=True)
    deleted_at = models.DateTimeField(null=True, blank=True)

    objects = ActiveManager()
    all_objects = models.Manager()

    class Meta:
        abstract = True

    def soft_delete(self) -> None:
        """Mark this record as soft-deleted."""
        self.is_deleted = True
        self.deleted_at = timezone.now()
        self.save(update_fields=["is_deleted", "deleted_at"])


# ---------------------------------------------------------------------------
# Data Isolation Manager
# ---------------------------------------------------------------------------

class DataIsolationManager(ActiveManager):
    """Manager that combines soft-delete filtering with data isolation.

    Reads the current user from a thread-safe ContextVar and applies
    role-based filtering automatically. Business code never manually
    writes isolation filters.

    Role rules:
    - system_admin: no filtering (sees all data)
    - sales_manager: filters by assigned_to__department=user.department
    - sales_rep: filters by assigned_to=user
    - admin_staff: filters by assigned_to=user (explicit assignment only)
    """

    def get_queryset(self):
        qs = super().get_queryset()
        user = _isolation_user.get()

        if user is None:
            raise RuntimeError(
                "DataIsolation: no user in context. "
                "Use bypass_isolation() for system tasks, "
                "or set_isolation_user() in Celery tasks."
            )

        isolation_field = getattr(self.model, "_isolation_field", None)
        if isolation_field:
            qs = qs.filter(**self._build_isolation_filter(user, isolation_field))

        return qs

    def bypass_isolation(self):
        """Return unfiltered queryset for system-level operations.

        Logs a warning for audit trail. Only callable from management
        commands, Celery tasks, and system cron jobs -- NOT from DRF ViewSets.
        """
        logger.warning(
            "bypass_isolation() called -- returning unfiltered queryset. "
            "Ensure this is only used in system-level operations."
        )
        return super().get_queryset()

    @staticmethod
    def _build_isolation_filter(user, isolation_field):
        """Build the filter kwargs based on user role and isolation field."""
        role = getattr(user, "role", None)

        if role == "system_admin":
            return {}  # No filtering for admin

        if role == "sales_manager":
            dept = getattr(user, "department_id", None)
            if dept is None:
                return {isolation_field: user}
            return {f"{isolation_field}__department_id": dept}

        # sales_rep and admin_staff: filter by exact user
        return {isolation_field: user}
