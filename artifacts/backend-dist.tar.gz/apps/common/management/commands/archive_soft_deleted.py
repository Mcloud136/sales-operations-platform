import logging
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

logger = logging.getLogger(__name__)

# Per-model retention: how long soft-deleted records stay recoverable
# before archival. Key = 'app_label.model_name', Value = days
DEFAULT_RETENTION_DAYS = 90

RETENTION_CONFIG = {
    'customers.customer': 90,
    'customers.lead': 90,
    'customers.followup': 90,
    'bids.bidproject': 180,
    'bids.document': 180,
    'contracts.contract': 365,
    'approvals.approvalinstance': 365,
    'notifications.notification': 30,
}


class Command(BaseCommand):
    help = 'Archive soft-deleted records past retention period into archive tables'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Only report counts, do not actually archive',
        )
        parser.add_argument(
            '--model',
            type=str,
            default=None,
            help='Archive a specific model (app_label.model_name)',
        )

    def handle(self, *args, **options):
        from django.apps import apps
        from django.db import connection

        dry_run = options['dry_run']
        target_model = options['model']
        cutoff = timezone.now()

        models_to_process = []
        if target_model:
            model = apps.get_model(target_model)
            models_to_process.append((target_model, model))
        else:
            for key, days in RETENTION_CONFIG.items():
                try:
                    model = apps.get_model(key)
                    models_to_process.append((key, model))
                except LookupError:
                    logger.warning("Model %s not found, skipping", key)

        total_archived = 0
        for key, model in models_to_process:
            days = RETENTION_CONFIG.get(key, DEFAULT_RETENTION_DAYS)
            archive_cutoff = cutoff - timedelta(days=days)

            # Find soft-deleted records past retention
            qs = model.objects.filter(
                is_deleted=True,
                deleted_at__lte=archive_cutoff,
            )

            count = qs.count()
            if count == 0:
                self.stdout.write(f"[{key}] No records to archive (0)")
                continue

            self.stdout.write(
                f"[{key}] Found {count} records older than {days} days"
            )

            if dry_run:
                self.stdout.write(f"  DRY RUN: would archive {count} records")
                total_archived += count
                continue

            # Create archive table name and ensure it exists
            archive_table = f"archive_{model._meta.db_table}"
            with connection.cursor() as cursor:
                cursor.execute(
                    f"CREATE TABLE IF NOT EXISTS {archive_table} "
                    f"(LIKE {model._meta.db_table} INCLUDING DEFAULTS INCLUDING CONSTRAINTS)"
                )
                # Remove unique constraints from archive table
                cursor.execute(
                    f"SELECT conname FROM pg_constraint WHERE conrelid = "
                    f"'{archive_table}'::regclass AND contype = 'u'"
                )
                for row in cursor.fetchall():
                    cursor.execute(
                        f"ALTER TABLE {archive_table} DROP CONSTRAINT IF EXISTS \"{row[0]}\""
                    )

            # Bulk insert into archive, then delete from source
            fields = [f.name for f in model._meta.fields]
            field_list = ', '.join(fields)
            param_placeholders = ', '.join(['%s'] * len(fields))

            rows = list(qs.values_list(*fields))
            if rows:
                with connection.cursor() as cursor:
                    cursor.executemany(
                        f"INSERT INTO {archive_table} ({field_list}) "
                        f"VALUES ({param_placeholders})",
                        rows,
                    )
                    # Hard delete the archived records
                    qs.delete()

            self.stdout.write(
                f"  Archived {count} records -> {archive_table}"
            )
            total_archived += count

        self.stdout.write(
            self.style.SUCCESS(
                f"Done. Total archived: {total_archived} records"
                + (" (DRY RUN)" if dry_run else "")
            )
        )
