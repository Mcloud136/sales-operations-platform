from typing import Any


def success_response(data: Any = None, message: str = "Success") -> dict:
    """Build a standardized success response payload.

    Args:
        data: The response data payload.
        message: Human-readable success message.

    Returns:
        Dict with success=True, data, and message.
    """
    return {
        "success": True,
        "data": data,
        "message": message,
    }


def error_response(message: str, status_code: int = 400) -> dict:
    """Build a standardized error response payload.

    Args:
        message: Human-readable error description.
        status_code: HTTP status code (default 400).

    Returns:
        Dict with success=False, error message, and status code.
    """
    return {
        "success": False,
        "error": message,
        "status_code": status_code,
    }
