"""
Reusable DRF mixins for the Sales Operations Platform.
"""

from rest_framework.viewsets import GenericViewSet


class DataIsolationMixin(GenericViewSet):
    """Mixin for ViewSets that need automatic data isolation.

    When the model uses DataIsolationManager as its default manager,
    this mixin simply returns `self.queryset` (the manager's queryset).
    The DataIsolationManager automatically applies role-based filtering
    via the ContextVar set by IsolationContextMiddleware.

    Usage:
        class MyViewSet(DataIsolationMixin, viewsets.ModelViewSet):
            queryset = MyModel.objects.all()
            serializer_class = MySerializer

    Iron Rule compliance:
    - bypass_isolation() is NEVER called inside get_queryset().
    - The isolation filter is applied automatically by the manager.
    """

    def get_queryset(self):
        """Return the model's default queryset with isolation applied."""
        if self.queryset is None:
            return super().get_queryset()
        return self.queryset
