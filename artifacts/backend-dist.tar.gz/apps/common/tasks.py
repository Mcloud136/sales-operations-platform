import logging
from celery import shared_task
from django.core.management import call_command
from io import StringIO

logger = logging.getLogger(__name__)


@shared_task(
    bind=True,
    max_retries=1,
    default_retry_delay=300,
)
def archive_soft_deleted_task(self, *args, **kwargs):
    """
    Celery task that wraps the archive_soft_deleted management command.
    Called by Celery Beat daily at 03:00 UTC.
    """
    try:
        out = StringIO()
        call_command('archive_soft_deleted', stdout=out, stderr=out)
        result = out.getvalue()
        logger.info("Archive task completed:\n%s", result)
        return {"status": "ok", "output": result}
    except Exception as exc:
        logger.exception("Archive task failed")
        raise self.retry(exc=exc)
