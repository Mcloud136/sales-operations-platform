import re
from rest_framework import serializers


class AdminFieldSerializer(serializers.Serializer):
    username = serializers.CharField(
        min_length=3,
        max_length=30,
        regex=r"^[a-zA-Z0-9_]+$",
        help_text="3-30 chars, alphanumeric and underscore only",
    )
    email = serializers.EmailField()
    password = serializers.CharField(
        min_length=8,
        write_only=True,
        style={"input_type": "password"},
        help_text="Min 8 chars, must include uppercase, lowercase, and digit",
    )

    def validate_password(self, value):
        if not re.search(r"[A-Z]", value):
            raise serializers.ValidationError(
                "Password must contain at least one uppercase letter."
            )
        if not re.search(r"[a-z]", value):
            raise serializers.ValidationError(
                "Password must contain at least one lowercase letter."
            )
        if not re.search(r"\d", value):
            raise serializers.ValidationError(
                "Password must contain at least one digit."
            )
        return value


class RoleMappingFieldSerializer(serializers.Serializer):
    sales_manager = serializers.UUIDField()
    legal = serializers.UUIDField()
    gm = serializers.UUIDField()
    vp = serializers.UUIDField()


class ApprovalConfigSerializer(serializers.Serializer):
    amount_threshold = serializers.IntegerField(min_value=10000, default=1000000)
    enable_bid_review = serializers.BooleanField(default=True)
    role_mapping = RoleMappingFieldSerializer()


class SetupCompleteSerializer(serializers.Serializer):
    """3-level nested serializer for setup completion request.

    Level 1: company_name (string)
    Level 2: admin (AdminFieldSerializer)
    Level 3: approval > role_mapping (RoleMappingFieldSerializer)
    """
    company_name = serializers.CharField(min_length=2, max_length=100)
    admin = AdminFieldSerializer()
    approval = ApprovalConfigSerializer()
