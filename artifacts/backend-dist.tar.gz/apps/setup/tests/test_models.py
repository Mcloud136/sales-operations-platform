import pytest
from django.core.cache import cache
from apps.setup.models import SystemConfig, is_system_initialized, CACHE_KEY_INITIALIZED


@pytest.mark.django_db
class TestSystemConfig:
    def test_create_system_config(self):
        config = SystemConfig.objects.create(
            key="test_key",
            value={"v": "hello"},
        )
        assert str(config) == "SystemConfig[test_key]"
        assert config.id is not None

    def test_uuid_v7_primary_key(self):
        """Iron Rule 1: SystemConfig.id must be UUIDv7 (timestamp-ordered)."""
        from uuid7 import uuid7 as _uuid7
        config1 = SystemConfig.objects.create(key="k1", value={"v": True})
        config2 = SystemConfig.objects.create(key="k2", value={"v": True})
        # UUIDv7 IDs are timestamp-ordered; later creation has greater ID
        assert config2.id > config1.id

    def test_get_returns_default_when_missing(self):
        result = SystemConfig.get("nonexistent_key", default="fallback")
        assert result == "fallback"
        # get_or_create creates the row
        assert SystemConfig.objects.filter(key="nonexistent_key").exists()

    def test_get_returns_stored_value(self):
        SystemConfig.objects.create(key="mykey", value={"v": 42})
        result = SystemConfig.get("mykey", default=0)
        assert result == 42

    def test_not_soft_delete_model(self):
        """SystemConfig must NOT have is_deleted field (exempt from Rule 2)."""
        assert not hasattr(SystemConfig(), "is_deleted")

    def test_key_is_unique(self):
        """Rule 3 exemption: unique=True is safe because SystemConfig is not
        a SoftDeleteModel heir."""
        SystemConfig.objects.create(key="unique_test", value={"v": True})
        with pytest.raises(Exception):  # IntegrityError
            SystemConfig.objects.create(key="unique_test", value={"v": False})


@pytest.mark.django_db
class TestIsSystemInitialized:
    def setup_method(self):
        cache.delete(CACHE_KEY_INITIALIZED)

    def teardown_method(self):
        cache.delete(CACHE_KEY_INITIALIZED)

    def test_returns_false_when_not_initialized(self):
        result = is_system_initialized()
        assert result is False

    def test_returns_true_when_initialized(self):
        SystemConfig.objects.create(key="initialized", value={"v": True})
        result = is_system_initialized()
        assert result is True

    def test_valkey_cache_hit(self):
        """Iron Rule 10: second call should hit Valkey cache, not DB."""
        SystemConfig.objects.create(key="initialized", value={"v": True})
        # First call -- cache miss, reads DB, writes cache
        result1 = is_system_initialized()
        assert result1 is True
        # Delete DB record -- cache should still return True
        SystemConfig.objects.filter(key="initialized").delete()
        result2 = is_system_initialized()
        assert result2 is True  # From Valkey cache

    def test_cache_written_on_miss(self):
        """Iron Rule 10: on cache miss, result is written back to Valkey."""
        assert cache.get(CACHE_KEY_INITIALIZED) is None  # No cache
        is_system_initialized()
        # Cache should now be populated (False, since not initialized)
        assert cache.get(CACHE_KEY_INITIALIZED) is False
