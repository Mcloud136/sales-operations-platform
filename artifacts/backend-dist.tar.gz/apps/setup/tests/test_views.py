import pytest
from django.core.cache import cache
from django.urls import reverse
from rest_framework.test import APIClient

from apps.setup.models import (
    CACHE_KEY_INITIALIZED,
    SystemConfig,
)


@pytest.fixture(autouse=True)
def clear_cache():
    """Clear Valkey cache before each test."""
    cache.delete(CACHE_KEY_INITIALIZED)
    yield
    cache.delete(CACHE_KEY_INITIALIZED)


@pytest.fixture
def client():
    return APIClient()


VALID_PAYLOAD = {
    "company_name": "Test Company Ltd.",
    "admin": {
        "username": "admin",
        "email": "admin@testcompany.com",
        "password": "SecurePassword123!",
    },
    "approval": {
        "amount_threshold": 1000000,
        "enable_bid_review": True,
        "role_mapping": {
            "sales_manager": "00000000-0000-0000-0000-000000000001",
            "legal": "00000000-0000-0000-0000-000000000001",
            "gm": "00000000-0000-0000-0000-000000000001",
            "vp": "00000000-0000-0000-0000-000000000001",
        },
    },
}


@pytest.mark.django_db
class TestSetupStatusView:
    def test_returns_false_when_not_initialized(self, client):
        url = reverse("setup:setup-status")
        response = client.get(url)
        assert response.status_code == 200
        assert response.data["initialized"] is False

    def test_returns_true_when_initialized(self, client):
        SystemConfig.objects.create(key="initialized", value={"v": True})
        url = reverse("setup:setup-status")
        response = client.get(url)
        assert response.status_code == 200
        assert response.data["initialized"] is True


@pytest.mark.django_db
class TestSetupCompleteView:
    def test_complete_setup_success(self, client):
        url = reverse("setup:setup-complete")
        response = client.post(url, VALID_PAYLOAD, format="json")
        assert response.status_code == 201
        assert response.data["success"] is True
        assert response.data["admin_user"]["username"] == "admin"
        assert "Standard Contract Approval" in response.data["templates_created"]
        assert "Quick Contract Approval" in response.data["templates_created"]
        assert "Bid Review" in response.data["templates_created"]

        # Verify DB state
        assert SystemConfig.objects.get(key="initialized").value["v"] is True
        assert SystemConfig.objects.get(key="company_name").value["v"] == "Test Company Ltd."

        # Verify admin user created
        from apps.users.models import User
        admin = User.objects.get(username="admin")
        assert admin.role == "system_admin"
        assert admin.is_superuser is True

        # Verify Valkey cache written
        assert cache.get(CACHE_KEY_INITIALIZED) is True

    def test_403_on_reinit(self, client):
        """Iron Rule 9: already-initialized system must return 403."""
        SystemConfig.objects.create(key="initialized", value={"v": True})
        url = reverse("setup:setup-complete")
        response = client.post(url, VALID_PAYLOAD, format="json")
        assert response.status_code == 403
        assert "already initialized" in response.data["detail"].lower()

    def test_403_after_successful_init(self, client):
        """Second POST after successful init must return 403."""
        url = reverse("setup:setup-complete")
        response1 = client.post(url, VALID_PAYLOAD, format="json")
        assert response1.status_code == 201
        response2 = client.post(url, VALID_PAYLOAD, format="json")
        assert response2.status_code == 403

    def test_validation_company_name_too_short(self, client):
        url = reverse("setup:setup-complete")
        payload = {
            **VALID_PAYLOAD,
            "company_name": "A",
        }
        response = client.post(url, payload, format="json")
        assert response.status_code == 400
        assert "company_name" in response.data

    def test_validation_username_invalid_chars(self, client):
        url = reverse("setup:setup-complete")
        payload = {
            **VALID_PAYLOAD,
            "admin": {**VALID_PAYLOAD["admin"], "username": "bad-user!"},
        }
        response = client.post(url, payload, format="json")
        assert response.status_code == 400

    def test_validation_password_no_uppercase(self, client):
        url = reverse("setup:setup-complete")
        payload = {
            **VALID_PAYLOAD,
            "admin": {**VALID_PAYLOAD["admin"], "password": "lowercase123"},
        }
        response = client.post(url, payload, format="json")
        assert response.status_code == 400

    def test_validation_threshold_below_minimum(self, client):
        url = reverse("setup:setup-complete")
        payload = {
            **VALID_PAYLOAD,
            "approval": {**VALID_PAYLOAD["approval"], "amount_threshold": 5000},
        }
        response = client.post(url, payload, format="json")
        assert response.status_code == 400


@pytest.mark.django_db
class TestConcurrencyLock:
    """Iron Rule 9: select_for_update() prevents concurrent initialization."""

    def test_select_for_update_used(self, client, monkeypatch):
        """Verify select_for_update() is called in the POST handler."""
        from unittest.mock import patch
        url = reverse("setup:setup-complete")

        original_queryset = SystemConfig.objects
        call_tracker = {"select_for_update_called": False}

        class TrackedManager:
            def select_for_update(self, **kwargs):
                call_tracker["select_for_update_called"] = True
                return original_queryset.select_for_update(**kwargs)

            def __getattr__(self, name):
                return getattr(original_queryset, name)

        monkeypatch.setattr(SystemConfig, "objects", TrackedManager())

        response = client.post(url, VALID_PAYLOAD, format="json")
        assert response.status_code == 201
        assert call_tracker["select_for_update_called"] is True
