import pytest
from django.core.cache import cache
from django.core.management import call_command
from io import StringIO

from apps.setup.models import CACHE_KEY_INITIALIZED, SystemConfig


@pytest.mark.django_db
class TestFactoryReset:
    def test_requires_confirm_flag(self):
        out = StringIO()
        err = StringIO()
        call_command("factory_reset", stdout=out, stderr=err)
        assert "Pass --confirm" in err.getvalue()

    def test_clears_initialization_flag(self):
        SystemConfig.objects.create(key="initialized", value={"v": True})
        cache.set(CACHE_KEY_INITIALIZED, True, 86400)

        out = StringIO()
        call_command("factory_reset", "--confirm", stdout=out)
        assert SystemConfig.objects.filter(key="initialized").count() == 0
        assert cache.get(CACHE_KEY_INITIALIZED) is None

    def test_clears_all_system_configs(self):
        SystemConfig.objects.create(key="initialized", value={"v": True})
        SystemConfig.objects.create(key="company_name", value={"v": "TestCo"})
        SystemConfig.objects.create(key="approval_role_mapping", value={"v": {}})

        out = StringIO()
        call_command("factory_reset", "--confirm", stdout=out)
        assert SystemConfig.objects.count() == 0
