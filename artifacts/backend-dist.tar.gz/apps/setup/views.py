import logging

from django.core.cache import cache
from django.db import transaction as db_transaction
from django.utils import timezone
from rest_framework import status, views
from rest_framework.response import Response
from rest_framework.throttling import AnonRateThrottle

from apps.setup.models import (
    CACHE_KEY_INITIALIZED,
    CACHE_TTL_INITIALIZED,
    SystemConfig,
)
from apps.setup.serializers import SetupCompleteSerializer
from apps.setup.services import _create_approval_templates

logger = logging.getLogger(__name__)


class SetupStatusView(views.APIView):
    """
    GET /api/v1/setup/status/
    Public endpoint -- no authentication required.
    Returns whether the system has been initialized.
    Uses sync def (Iron Rule 5).
    """

    authentication_classes = []

    def get(self, request):
        from apps.setup.models import is_system_initialized

        initialized = is_system_initialized()
        return Response({"initialized": initialized})


class SetupCompleteView(views.APIView):
    """
    POST /api/v1/setup/complete/
    Public endpoint -- no authentication required.
    Executes full system initialization in a single atomic transaction.
    Rate limited to 5 requests per IP per hour.

    Uses sync def (Iron Rule 5).
    """

    authentication_classes = []
    throttle_classes = [AnonRateThrottle]
    throttle_scope = "setup"

    def post(self, request):
        serializer = SetupCompleteSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        data = serializer.validated_data

        from apps.users.models import User

        # ================================================================
        # ── ATOMIC BLOCK START ──
        # Iron Rule 9: select_for_update() inside atomic
        # Iron Rule 12: NO Valkey writes, NO Celery tasks, NO external
        #               API calls, NO emails inside this block.
        #               Only pure DB operations.
        # ================================================================
        with db_transaction.atomic():
            # Lock the initialization record (or create it locked)
            config, _created = SystemConfig.objects.select_for_update().get_or_create(
                key="initialized",
                defaults={"value": {"v": False}},
            )

            # Already initialized? Abort with 403.
            if config.value.get("v", False):
                return Response(
                    {"detail": "System is already initialized."},
                    status=status.HTTP_403_FORBIDDEN,
                )

            # 1. Create admin superuser (DB only -- Iron Rule 12)
            admin = User.objects.create_superuser(
                username=data["admin"]["username"],
                email=data["admin"]["email"],
                password=data["admin"]["password"],
                role="system_admin",
            )

            # 2. Create approval workflow templates (DB only -- Iron Rule 12)
            template_names = _create_approval_templates(
                threshold=data["approval"]["amount_threshold"],
                role_mapping=data["approval"]["role_mapping"],
                enable_bid_review=data["approval"]["enable_bid_review"],
            )

            # 3. Store company name (DB only -- Iron Rule 12)
            SystemConfig.objects.update_or_create(
                key="company_name",
                defaults={"value": {"v": data["company_name"]}},
            )

            # 4. Store approval role mapping (DB only -- Iron Rule 12)
            SystemConfig.objects.update_or_create(
                key="approval_role_mapping",
                defaults={"value": {"v": data["approval"]["role_mapping"]}},
            )

            # 5. Mark initialized in DB (DB only -- Iron Rule 12)
            config.value = {"v": True}
            config.save(update_fields=["value", "updated_at"])

        # ================================================================
        # ── ATOMIC BLOCK END ──
        # All DB writes are committed. Safe to perform side effects now.
        # ================================================================

        # Iron Rule 10 + 12: Write Valkey cache AFTER commit (not inside atomic)
        cache.set(CACHE_KEY_INITIALIZED, True, CACHE_TTL_INITIALIZED)

        logger.info(
            "System initialized: admin=%s, templates=%s",
            admin.username,
            template_names,
        )

        return Response(
            {
                "success": True,
                "message": "System initialized successfully.",
                "admin_user": {
                    "id": str(admin.id),
                    "username": admin.username,
                    "role": admin.role,
                },
                "templates_created": template_names,
            },
            status=status.HTTP_201_CREATED,
        )
