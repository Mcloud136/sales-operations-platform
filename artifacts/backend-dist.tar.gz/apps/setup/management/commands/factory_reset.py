from django.core.cache import cache
from django.core.management.base import BaseCommand
from django.db import connection

from apps.setup.models import CACHE_KEY_INITIALIZED, SystemConfig


class Command(BaseCommand):
    help = "Reset system to uninitialized state. Deletes ALL business data."

    def add_arguments(self, parser):
        parser.add_argument(
            "--confirm",
            action="store_true",
            help="Must be passed to actually perform the reset.",
        )

    def handle(self, *args, **options):
        if not options["confirm"]:
            self.stderr.write(self.style.ERROR("Pass --confirm to proceed."))
            return

        self.stdout.write(self.style.WARNING("Starting factory reset..."))

        # Step 1: Clear Valkey cache (Iron Rule 10)
        cache.delete(CACHE_KEY_INITIALIZED)
        self.stdout.write("  Cleared Valkey initialization cache.")

        # Step 2: Delete SystemConfig records (safe -- no FK constraints pointing here)
        count = SystemConfig.objects.count()
        SystemConfig.objects.all().delete()
        self.stdout.write(f"  Deleted {count} SystemConfig records.")

        # Step 3: Wipe all business tables via raw SQL (ordered by FK dependencies)
        # Order: children first, parents last
        tables_to_truncate = [
            "approvals_approvalstepinstance",
            "approvals_approvalinstance",
            "approvals_approvalstepdefinition",
            "approvals_approvalworkflowdefinition",
            "notifications_notification",
            "reports_reportlog",
            "contracts_contractdocument",
            "contracts_contract",
            "bids_bidattachment",
            "bids_bidproject",
            "leads_lead",
            "customers_customercontact",
            "customers_customer",
            "users_user",
        ]
        with connection.cursor() as cursor:
            for table in tables_to_truncate:
                try:
                    cursor.execute(f'DELETE FROM "{table}"')
                    self.stdout.write(f"  Truncated table: {table}")
                except Exception as e:
                    self.stderr.write(
                        self.style.WARNING(f"  Could not truncate {table}: {e}")
                    )

        # Reset PostgreSQL sequences
        with connection.cursor() as cursor:
            cursor.execute(
                "SELECT schemaname || '.' || relname FROM pg_stat_user_tables "
                "WHERE schemaname = 'public'"
            )
            tables = [row[0] for row in cursor.fetchall()]
            for table in tables:
                try:
                    cursor.execute(
                        f"ALTER TABLE \"{table}\" ALTER COLUMN id RESTART WITH 1"
                    )
                except Exception:
                    pass

        self.stdout.write(self.style.SUCCESS("System reset to uninitialized state."))
