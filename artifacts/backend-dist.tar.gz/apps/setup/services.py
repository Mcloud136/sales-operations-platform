import logging

logger = logging.getLogger(__name__)


def _create_approval_templates(threshold, role_mapping, enable_bid_review):
    """
    Create ApprovalWorkflowDefinition + ApprovalStepDefinition records.

    Returns list of template names created.
    ONLY DB operations -- no external calls, no Celery (Iron Rule 12).
    """
    from apps.approvals.models import (
        ApprovalWorkflowDefinition,
        ApprovalStepDefinition,
    )

    created = []

    # Template 1: Standard Contract Approval (>= threshold)
    std, _ = ApprovalWorkflowDefinition.objects.get_or_create(
        name="Standard Contract Approval",
        workflow_type="contract_approval",
        defaults={
            "conditions": {"amount": {"gte": threshold}},
            "is_default": False,
        },
    )
    for i, (role, name) in enumerate(
        [
            ("sales_manager", "Sales Manager Review"),
            ("legal", "Legal Review"),
            ("gm", "General Manager Approval"),
        ],
        start=1,
    ):
        ApprovalStepDefinition.objects.get_or_create(
            workflow_def=std,
            step_order=i,
            defaults={"step_name": name, "assignee_role": role},
        )
    created.append(std.name)

    # Template 2: Quick Contract Approval (< threshold)
    quick, _ = ApprovalWorkflowDefinition.objects.get_or_create(
        name="Quick Contract Approval",
        workflow_type="contract_approval",
        defaults={
            "conditions": {"amount": {"lt": threshold}},
            "is_default": True,
        },
    )
    for i, (role, name) in enumerate(
        [
            ("sales_manager", "Sales Manager Review"),
            ("gm", "General Manager Approval"),
        ],
        start=1,
    ):
        ApprovalStepDefinition.objects.get_or_create(
            workflow_def=quick,
            step_order=i,
            defaults={"step_name": name, "assignee_role": role},
        )
    created.append(quick.name)

    # Template 3: Bid Review (optional)
    if enable_bid_review:
        bid, _ = ApprovalWorkflowDefinition.objects.get_or_create(
            name="Bid Review",
            workflow_type="bid_review",
            defaults={"conditions": {}, "is_default": True},
        )
        for i, (role, name) in enumerate(
            [
                ("sales_manager", "Sales Manager Review"),
                ("vp", "VP Approval"),
            ],
            start=1,
        ):
            ApprovalStepDefinition.objects.get_or_create(
                workflow_def=bid,
                step_order=i,
                defaults={"step_name": name, "assignee_role": role},
            )
        created.append(bid.name)

    return created
