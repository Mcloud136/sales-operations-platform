import logging
from django.core.cache import cache
from django.db import models
from uuid7 import uuid7

logger = logging.getLogger(__name__)

CACHE_KEY_INITIALIZED = "system:initialized"
CACHE_TTL_INITIALIZED = 86400  # 24 hours


class SystemConfig(models.Model):
    """
    System-level key-value configuration store.
    NOT a business model -- exempt from Iron Rules 2 (Isolation) and 3 (Uniqueness).

    - Uses UUIDv7 primary key (Iron Rule 1).
    - Does NOT inherit SoftDeleteModel or DataIsolationManager (exempt, Rule 2).
    - Uses unique=True on key because records are never soft-deleted (exempt, Rule 3).
    """

    id = models.UUIDField(primary_key=True, default=uuid7, editable=False)
    key = models.CharField(max_length=100, unique=True)
    value = models.JSONField(default=dict)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "System Config"
        db_table = "setup_system_config"

    def __str__(self) -> str:
        return f"SystemConfig[{self.key}]"

    @classmethod
    def get(cls, key: str, default=None):
        """Get-or-create a config entry and return its inner value."""
        obj, _ = cls.objects.get_or_create(key=key)
        return obj.value.get("v", default)


def is_system_initialized() -> bool:
    """
    Read initialization state. Valkey-first (Iron Rule 10).

    1. Check Valkey cache -- if cache hit, return immediately.
    2. On cache miss, query DB via SystemConfig.get().
    3. Write result back to Valkey with 24h TTL.
    """
    cached = cache.get(CACHE_KEY_INITIALIZED)
    if cached is not None:
        return cached

    initialized = SystemConfig.get("initialized", default=False)
    cache.set(CACHE_KEY_INITIALIZED, initialized, CACHE_TTL_INITIALIZED)
    return initialized
