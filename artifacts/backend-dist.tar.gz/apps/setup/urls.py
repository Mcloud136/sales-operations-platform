from django.urls import path

from apps.setup.views import SetupCompleteView, SetupStatusView

app_name = "setup"

urlpatterns = [
    path("status/", SetupStatusView.as_view(), name="setup-status"),
    path("complete/", SetupCompleteView.as_view(), name="setup-complete"),
]
