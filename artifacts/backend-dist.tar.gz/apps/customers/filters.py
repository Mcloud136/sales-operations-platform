"""
Django-filter filterset for Customer model.

Supports filtering by industry, level, source, assigned_to,
and full-text search (PostgreSQL FTS-compatible via icontains fallback).
"""

import django_filters
from django_filters import rest_framework as filters
from apps.customers.models import Customer, IndustryChoices, LevelChoices, SourceChoices


class CustomerFilter(filters.FilterSet):
    """Filter set for the Customer list endpoint."""

    search = filters.CharFilter(
        method="filter_search",
        help_text="Search by name, contact person, or phone (partial match)",
    )
    industry = filters.ChoiceFilter(
        choices=IndustryChoices.choices,
        null_label="All",
        empty_label="All",
    )
    level = filters.ChoiceFilter(
        choices=LevelChoices.choices,
        null_label="All",
        empty_label="All",
    )
    source = filters.ChoiceFilter(
        choices=SourceChoices.choices,
        null_label="All",
        empty_label="All",
    )
    assigned_to = django_filters.UUIDFilter(field_name="assigned_to_id")
    created_after = filters.DateTimeFilter(field_name="created_at", lookup_expr="gte")
    created_before = filters.DateTimeFilter(field_name="created_at", lookup_expr="lte")

    class Meta:
        model = Customer
        fields = (
            "industry",
            "level",
            "source",
            "assigned_to",
            "search",
            "created_after",
            "created_before",
        )

    def filter_search(self, queryset, name, value):
        """Search across name, contact_person, and contact_phone.

        Uses icontains for broad compatibility. In production with
        PostgreSQL 18, this can be upgraded to full-text search via
        SearchVectorField or a custom database function.
        """
        if not value:
            return queryset
        lookup = (
            django_filters.Q(name__icontains=value)
            | django_filters.Q(contact_person__icontains=value)
            | django_filters.Q(contact_phone__icontains=value)
        )
        return queryset.filter(lookup)
