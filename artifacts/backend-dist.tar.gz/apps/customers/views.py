"""
Customer API views.

Provides CRUD endpoints for customer management with data isolation,
role-based access control, and filtering support.
"""

import base64

from rest_framework import viewsets, status
from rest_framework.permissions import IsAuthenticated
from rest_framework.decorators import action
from rest_framework.response import Response

from apps.common.mixins import DataIsolationMixin
from apps.common.permissions import IsRoleAllowed
from apps.customers.models import Customer
from apps.customers.serializers import (
    CustomerListSerializer,
    CustomerDetailSerializer,
    CustomerCreateSerializer,
    CustomerUpdateSerializer,
)
from apps.customers.filters import CustomerFilter
from apps.customers.tasks import export_customers_task, import_customers_task


class CustomerViewSet(DataIsolationMixin, viewsets.ModelViewSet):
    """
    Customer CRUD API.

    - List: GET /api/v1/customers/
    - Create: POST /api/v1/customers/
    - Detail: GET /api/v1/customers/{id}/
    - Update: PUT /api/v1/customers/{id}/
    - Delete: DELETE /api/v1/customers/{id}/
    - Export: GET /api/v1/customers/export/
    - Import: POST /api/v1/customers/import/

    Permissions: system_admin, sales_manager, sales_rep can CRUD.
    admin_staff can read only.
    """

    permission_classes = [IsAuthenticated, IsRoleAllowed]
    allowed_roles = ["system_admin", "sales_manager", "sales_rep", "admin_staff"]

    queryset = Customer.objects.select_related("assigned_to").all()
    filterset_class = CustomerFilter
    search_fields = ("name", "contact_person", "contact_phone")
    ordering_fields = ("name", "level", "created_at", "updated_at")
    ordering = ("-created_at",)

    def get_serializer_class(self):
        """Return the appropriate serializer based on action."""
        if self.action == "list":
            return CustomerListSerializer
        if self.action == "retrieve":
            return CustomerDetailSerializer
        if self.action in ("create",):
            return CustomerCreateSerializer
        if self.action in ("update", "partial_update"):
            return CustomerUpdateSerializer
        return CustomerDetailSerializer

    def check_object_permissions(self, request, obj):
        """admin_staff can only read, not modify."""
        super().check_object_permissions(request, obj)
        if (
            request.method not in ("GET", "HEAD", "OPTIONS")
            and hasattr(request.user, "role")
            and request.user.role == "admin_staff"
        ):
            from rest_framework.exceptions import PermissionDenied

            raise PermissionDenied("Admin staff can only view customers.")

    def perform_create(self, serializer):
        """Set assigned_to to current user if not provided."""
        if serializer.validated_data.get("assigned_to") is None:
            serializer.validated_data["assigned_to"] = self.request.user
        serializer.save()

    def destroy(self, request, *args, **kwargs):
        """Soft-delete the customer instead of physical deletion."""
        customer = self.get_object()
        customer.soft_delete()
        return Response(
            {"detail": "Customer deleted successfully."},
            status=status.HTTP_204_NO_CONTENT,
        )

    # -----------------------------------------------------------------------
    # Excel export endpoint
    # -----------------------------------------------------------------------

    @action(detail=False, methods=["get"], url_path="export")
    def export_excel(self, request):
        """GET /api/v1/customers/export/

        Export customers to an Excel (.xlsx) file.
        Supports the same filters as the list endpoint via query params.
        """
        from django.http import HttpResponse

        # Collect filter params
        filters = {}
        for key in ("industry", "level", "source"):
            val = request.query_params.get(key)
            if val:
                filters[key] = val

        # Dispatch to Celery for async processing
        task = export_customers_task.delay(
            user_id=request.user.id,
            filters=filters,
        )

        # For synchronous mode (small datasets), execute inline
        # In production with large datasets, use task.result with polling
        try:
            result = task.get(timeout=30)
        except Exception:
            # Fallback: execute synchronously
            result = export_customers_task(
                user_id=request.user.id,
                filters=filters,
            )

        if "file_bytes" not in result:
            return Response(result, status=status.HTTP_400_BAD_REQUEST)

        # Decode base64 and return as file download
        file_bytes = base64.b64decode(result["file_bytes"])
        filename = result.get("filename", "customers_export.xlsx")

        response = HttpResponse(
            file_bytes,
            content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
        response["Content-Disposition"] = f'attachment; filename="{filename}"'
        return response

    # -----------------------------------------------------------------------
    # Excel import endpoint
    # -----------------------------------------------------------------------

    @action(detail=False, methods=["post"], url_path="import")
    def import_excel(self, request):
        """POST /api/v1/customers/import/

        Import customers from an uploaded Excel (.xlsx) file.
        Expected columns: Company Name, Industry, Contact Person, Contact Phone,
        Contact Email, Address, Level, Source, Notes.
        """
        file_obj = request.FILES.get("file")
        if not file_obj:
            return Response(
                {"detail": "No file uploaded. Use 'file' field."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        # Read file bytes and encode as base64 for Celery task
        file_bytes = file_obj.read()
        file_b64 = base64.b64encode(file_bytes).decode("ascii")

        # Dispatch to Celery
        task = import_customers_task.delay(
            user_id=request.user.id,
            file_bytes_b64=file_b64,
        )

        # For synchronous mode, execute inline
        try:
            result = task.get(timeout=30)
        except Exception:
            result = import_customers_task(
                user_id=request.user.id,
                file_bytes_b64=file_b64,
            )

        return Response(result, status=status.HTTP_200_OK)
