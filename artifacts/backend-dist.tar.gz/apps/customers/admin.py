from django.contrib import admin
from apps.customers.models import Customer


@admin.register(Customer)
class CustomerAdmin(admin.ModelAdmin):
    """Django Admin for Customer model."""

    list_display = (
        "name",
        "industry",
        "level",
        "source",
        "contact_person",
        "assigned_to",
        "is_deleted",
        "created_at",
    )
    list_filter = ("industry", "level", "source", "is_deleted")
    search_fields = ("name", "contact_person", "contact_email", "contact_phone")
    readonly_fields = ("id", "created_at", "updated_at", "deleted_at")
    date_hierarchy = "created_at"
