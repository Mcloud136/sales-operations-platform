import pytest
from django.db import IntegrityError
from apps.common.models import set_isolation_user, reset_isolation_user
from apps.users.models import User
from apps.customers.models import Customer


@pytest.fixture
def admin_user():
    """Create a system_admin user for tests."""
    return User.objects.create_user(
        username="admin_test",
        email="admin_test@example.com",
        role="system_admin",
    )


@pytest.fixture
def sales_rep():
    """Create a sales_rep user for tests."""
    return User.objects.create_user(
        username="rep_test",
        email="rep_test@example.com",
        role="sales_rep",
    )


@pytest.fixture(autouse=True)
def _set_isolation(admin_user):
    """Automatically set isolation user for all tests in this module."""
    set_isolation_user(admin_user)
    yield
    reset_isolation_user()


# ---------------------------------------------------------------------------
# UUIDv7 PK tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_customer_has_uuidv7_pk():
    """Customer primary key should be UUIDv7 (starts with 0-7)."""
    user = User.objects.get(username="admin_test")
    customer = Customer.objects.create(
        name="Test Corp",
        assigned_to=user,
    )
    assert customer.id is not None
    assert str(customer.id)[0] in "01234567"


# ---------------------------------------------------------------------------
# Soft delete tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_customer_soft_delete():
    """Soft-deleting a customer should hide it from default queryset."""
    user = User.objects.get(username="admin_test")
    c = Customer.objects.create(name="To Delete", assigned_to=user)
    c.soft_delete()

    assert c not in Customer.objects.all()
    assert c in Customer.all_objects.all()


# ---------------------------------------------------------------------------
# Partial unique constraint tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_active_customer_name_unique():
    """Two active customers with the same name should violate the unique constraint."""
    user = User.objects.get(username="admin_test")
    Customer.objects.create(name="Acme Corp", assigned_to=user)
    with pytest.raises(IntegrityError):
        Customer.objects.create(name="Acme Corp", assigned_to=user)


@pytest.mark.django_db
def test_deleted_customer_name_reusable():
    """After soft-deleting a customer, a new customer with the same name should be allowed."""
    user = User.objects.get(username="admin_test")
    c = Customer.objects.create(name="Acme Corp", assigned_to=user)
    c.soft_delete()

    # Should succeed -- soft-deleted records excluded from unique check
    c2 = Customer.objects.create(name="Acme Corp", assigned_to=user)
    assert c2.id != c.id


# ---------------------------------------------------------------------------
# Data isolation tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_customer_isolation_sales_rep_sees_own():
    """A sales_rep should only see customers assigned to them."""
    rep1 = User.objects.create_user(username="rep1", email="rep1@example.com", role="sales_rep")
    rep2 = User.objects.create_user(username="rep2", email="rep2@example.com", role="sales_rep")

    Customer.objects.create(name="Rep1 Customer", assigned_to=rep1)
    Customer.objects.create(name="Rep2 Customer", assigned_to=rep2)

    # Switch to rep1's context
    set_isolation_user(rep1)
    visible = list(Customer.objects.values_list("name", flat=True))
    assert visible == ["Rep1 Customer"]

    # Switch to rep2's context
    set_isolation_user(rep2)
    visible = list(Customer.objects.values_list("name", flat=True))
    assert visible == ["Rep2 Customer"]


@pytest.mark.django_db
def test_customer_isolation_admin_sees_all():
    """A system_admin should see all customers regardless of assignment."""
    rep = User.objects.create_user(username="rep_x", email="rep_x@example.com", role="sales_rep")
    admin = User.objects.get(username="admin_test")

    Customer.objects.create(name="Rep Customer", assigned_to=rep)
    Customer.objects.create(name="Admin Customer", assigned_to=admin)

    set_isolation_user(admin)
    visible = list(Customer.objects.values_list("name", flat=True))
    assert len(visible) == 2


# ---------------------------------------------------------------------------
# Field validation tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_customer_industry_choices():
    """Customer industry must be one of the defined choices."""
    user = User.objects.get(username="admin_test")
    c = Customer.objects.create(name="Tech Co", industry="technology", assigned_to=user)
    c.full_clean()  # Should not raise
    assert c.industry == "technology"


@pytest.mark.django_db
def test_customer_level_choices():
    """Customer level must be one of the defined choices."""
    user = User.objects.get(username="admin_test")
    c = Customer.objects.create(name="Big Co", level="strategic", assigned_to=user)
    c.full_clean()
    assert c.level == "strategic"


@pytest.mark.django_db
def test_customer_timestamp_fields():
    """Customer should have created_at and updated_at from TimestampMixin."""
    user = User.objects.get(username="admin_test")
    c = Customer.objects.create(name="Timestamp Co", assigned_to=user)
    assert c.created_at is not None
    assert c.updated_at is not None


@pytest.mark.django_db
def test_customer_string_representation():
    """Customer __str__ should return the company name."""
    user = User.objects.get(username="admin_test")
    c = Customer.objects.create(name="String Test Co", assigned_to=user)
    assert str(c) == "String Test Co"
