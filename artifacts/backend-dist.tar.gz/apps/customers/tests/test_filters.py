import pytest
from apps.common.models import set_isolation_user, reset_isolation_user
from apps.users.models import User
from apps.customers.models import Customer


@pytest.fixture(autouse=True)
def _isolation():
    admin = User.objects.create_user(
        username="filter_admin", email="filter_admin@example.com", role="system_admin"
    )
    set_isolation_user(admin)
    yield
    reset_isolation_user()


@pytest.mark.django_db
def test_filter_by_level_strategic():
    """Filtering by level=strategic should return only strategic customers."""
    admin = User.objects.get(username="filter_admin")
    Customer.objects.create(name="Strategic Co", level="strategic", assigned_to=admin)
    Customer.objects.create(name="Normal Co", level="normal", assigned_to=admin)

    from apps.customers.filters import CustomerFilter
    from apps.customers.models import Customer

    qs = Customer.objects.all()
    f = CustomerFilter(data={"level": "strategic"}, queryset=qs)
    result = list(f.qs.values_list("name", flat=True))
    assert result == ["Strategic Co"]


@pytest.mark.django_db
def test_filter_by_source():
    """Filtering by source=exhibition should return only exhibition-sourced customers."""
    admin = User.objects.get(username="filter_admin")
    Customer.objects.create(name="Exhibit Co", source="exhibition", assigned_to=admin)
    Customer.objects.create(name="Partner Co", source="partner", assigned_to=admin)

    from apps.customers.filters import CustomerFilter

    qs = Customer.objects.all()
    f = CustomerFilter(data={"source": "exhibition"}, queryset=qs)
    result = list(f.qs.values_list("name", flat=True))
    assert result == ["Exhibit Co"]


@pytest.mark.django_db
def test_filter_by_assigned_to():
    """Filtering by assigned_to should return only that user's customers."""
    admin = User.objects.get(username="filter_admin")
    other = User.objects.create_user(
        username="other_filter", email="other_filter@example.com", role="sales_rep"
    )
    Customer.objects.create(name="Admin Co", assigned_to=admin)
    Customer.objects.create(name="Other Co", assigned_to=other)

    from apps.customers.filters import CustomerFilter

    qs = Customer.objects.all()
    f = CustomerFilter(data={"assigned_to": str(other.id)}, queryset=qs)
    result = list(f.qs.values_list("name", flat=True))
    assert result == ["Other Co"]


@pytest.mark.django_db
def test_filter_search_phone():
    """Search filter should match contact_phone."""
    admin = User.objects.get(username="filter_admin")
    Customer.objects.create(
        name="Phone Co", contact_phone="555-0123", assigned_to=admin
    )
    Customer.objects.create(
        name="NoPhone Co", contact_phone="555-9999", assigned_to=admin
    )

    from apps.customers.filters import CustomerFilter

    qs = Customer.objects.all()
    f = CustomerFilter(data={"search": "0123"}, queryset=qs)
    result = list(f.qs.values_list("name", flat=True))
    assert result == ["Phone Co"]
