import pytest
import base64
import openpyxl
from io import BytesIO
from rest_framework.test import APIClient
from apps.common.models import set_isolation_user, reset_isolation_user
from apps.users.models import User
from apps.customers.models import Customer


@pytest.fixture
def admin_user():
    return User.objects.create_user(
        username="excel_admin", email="excel_admin@example.com", role="system_admin", password="pass123"
    )


@pytest.fixture
def admin_token(admin_user):
    client = APIClient()
    resp = client.post("/api/v1/auth/login/", {"username": "excel_admin", "password": "pass123"})
    return resp.data["access"]


@pytest.fixture(autouse=True)
def _isolation(admin_user):
    set_isolation_user(admin_user)
    yield
    reset_isolation_user()


# ---------------------------------------------------------------------------
# Export tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_export_customers(admin_token, admin_user):
    """GET /api/v1/customers/export/ should return an Excel file."""
    set_isolation_user(admin_user)
    Customer.objects.create(name="Export Corp", industry="technology", assigned_to=admin_user)
    Customer.objects.create(name="Import Corp", industry="finance", assigned_to=admin_user)

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.get("/api/v1/customers/export/")
    assert resp.status_code == 200
    assert resp["Content-Type"] == "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    assert "attachment" in resp["Content-Disposition"]

    # Verify it's a valid Excel file
    wb = openpyxl.load_workbook(BytesIO(resp.content))
    ws = wb.active
    assert ws is not None
    headers = [cell.value for cell in ws[1]]
    assert "Company Name" in headers
    data_rows = list(ws.iter_rows(min_row=2))
    assert len(data_rows) >= 2


@pytest.mark.django_db
def test_export_with_filters(admin_token, admin_user):
    """GET /api/v1/customers/export/?industry=technology should filter."""
    set_isolation_user(admin_user)
    Customer.objects.create(name="Tech Export", industry="technology", assigned_to=admin_user)
    Customer.objects.create(name="Fin Export", industry="finance", assigned_to=admin_user)

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.get("/api/v1/customers/export/?industry=technology")
    assert resp.status_code == 200

    wb = openpyxl.load_workbook(BytesIO(resp.content))
    ws = wb.active
    data_rows = list(ws.iter_rows(min_row=2))
    names = [row[0].value for row in data_rows]
    assert "Tech Export" in names
    assert "Fin Export" not in names


# ---------------------------------------------------------------------------
# Import tests
# ---------------------------------------------------------------------------

def _make_excel_file(rows: list[list[str]]) -> bytes:
    """Helper: create an Excel file with the given rows (first row = header)."""
    wb = openpyxl.Workbook()
    ws = wb.active
    for row in rows:
        ws.append(row)
    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)
    return buffer.read()


@pytest.mark.django_db
def test_import_customers(admin_token, admin_user):
    """POST /api/v1/customers/import/ should import from Excel."""
    set_isolation_user(admin_user)
    file_bytes = _make_excel_file([
        ["Company Name", "Industry", "Contact Person", "Contact Phone", "Level"],
        ["Imported Corp 1", "Technology", "Alice", "555-0101", "Strategic"],
        ["Imported Corp 2", "Finance", "Bob", "555-0102", "Normal"],
    ])

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.post(
        "/api/v1/customers/import/",
        {"file": (BytesIO(file_bytes), "import.xlsx")},
        format="multipart",
    )
    assert resp.status_code == 200
    assert resp.data["success"] == 2
    assert resp.data["errors"] == 0

    # Verify the customers were created
    set_isolation_user(admin_user)
    names = list(Customer.objects.values_list("name", flat=True))
    assert "Imported Corp 1" in names
    assert "Imported Corp 2" in names


@pytest.mark.django_db
def test_import_customers_empty_name_fails(admin_token, admin_user):
    """Importing a row with empty Company Name should count as error."""
    set_isolation_user(admin_user)
    file_bytes = _make_excel_file([
        ["Company Name", "Industry"],
        ["Valid Corp", "Technology"],
        ["", "Finance"],  # Empty name -- should error
    ])

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.post(
        "/api/v1/customers/import/",
        {"file": (BytesIO(file_bytes), "import.xlsx")},
        format="multipart",
    )
    assert resp.status_code == 200
    assert resp.data["success"] == 1
    assert resp.data["errors"] == 1


@pytest.mark.django_db
def test_import_customers_no_file(admin_token):
    """POST /api/v1/customers/import/ without a file should return 400."""
    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.post("/api/v1/customers/import/", {})
    assert resp.status_code == 400


@pytest.mark.django_db
def test_import_customers_missing_header(admin_token):
    """Importing a file without 'Company Name' header should fail."""
    file_bytes = _make_excel_file([
        ["Industry", "Contact Person"],
        ["Technology", "Alice"],
    ])

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.post(
        "/api/v1/customers/import/",
        {"file": (BytesIO(file_bytes), "bad_import.xlsx")},
        format="multipart",
    )
    assert resp.status_code == 200
    assert resp.data.get("detail") is not None or resp.data["success"] == 0


# ---------------------------------------------------------------------------
# Celery task unit tests (without Celery broker)
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_export_task_directly(admin_user):
    """Test export_customers_task function directly (no Celery)."""
    set_isolation_user(admin_user)
    Customer.objects.create(name="Task Export", industry="technology", assigned_to=admin_user)

    from apps.customers.tasks import export_customers_task
    result = export_customers_task(user_id=admin_user.id, filters=None)

    assert "file_bytes" in result
    assert result["count"] >= 1

    # Verify file is valid Excel
    file_bytes = base64.b64decode(result["file_bytes"])
    wb = openpyxl.load_workbook(BytesIO(file_bytes))
    ws = wb.active
    assert ws is not None


@pytest.mark.django_db
def test_import_task_directly(admin_user):
    """Test import_customers_task function directly (no Celery)."""
    set_isolation_user(admin_user)

    file_bytes = _make_excel_file([
        ["Company Name", "Industry", "Level"],
        ["Task Import Corp", "Technology", "Strategic"],
    ])
    file_b64 = base64.b64encode(file_bytes).decode("ascii")

    from apps.customers.tasks import import_customers_task
    result = import_customers_task(user_id=admin_user.id, file_bytes_b64=file_b64)

    assert result["success"] == 1
    assert result["errors"] == 0

    set_isolation_user(admin_user)
    assert Customer.objects.filter(name="Task Import Corp").exists()
