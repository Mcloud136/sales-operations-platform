import pytest
from rest_framework.test import APIClient
from apps.common.models import set_isolation_user, reset_isolation_user
from apps.users.models import User
from apps.customers.models import Customer


@pytest.fixture
def admin_user():
    return User.objects.create_user(
        username="admin_view", email="admin_view@example.com", role="system_admin", password="pass123"
    )


@pytest.fixture
def sales_rep():
    return User.objects.create_user(
        username="rep_view", email="rep_view@example.com", role="sales_rep", password="pass123"
    )


@pytest.fixture
def admin_staff():
    return User.objects.create_user(
        username="staff_view", email="staff_view@example.com", role="admin_staff", password="pass123"
    )


@pytest.fixture
def admin_token(admin_user):
    client = APIClient()
    resp = client.post("/api/v1/auth/login/", {"username": "admin_view", "password": "pass123"})
    return resp.data["access"]


@pytest.fixture
def rep_token(sales_rep):
    client = APIClient()
    resp = client.post("/api/v1/auth/login/", {"username": "rep_view", "password": "pass123"})
    return resp.data["access"]


@pytest.fixture
def staff_token(admin_staff):
    client = APIClient()
    resp = client.post("/api/v1/auth/login/", {"username": "staff_view", "password": "pass123"})
    return resp.data["access"]


@pytest.fixture(autouse=True)
def _isolation(admin_user):
    set_isolation_user(admin_user)
    yield
    reset_isolation_user()


# ---------------------------------------------------------------------------
# Create tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_create_customer(admin_token):
    """POST /api/v1/customers/ should create a customer."""
    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.post(
        "/api/v1/customers/",
        {
            "name": "New Corp",
            "industry": "technology",
            "contact_person": "John Doe",
            "contact_phone": "555-0100",
            "contact_email": "john@newcorp.com",
            "level": "strategic",
            "source": "exhibition",
        },
    )
    assert resp.status_code == 201
    assert resp.data["name"] == "New Corp"
    assert resp.data["industry"] == "technology"
    assert resp.data["level"] == "strategic"
    assert "id" in resp.data


@pytest.mark.django_db
def test_create_customer_without_assigned_to_auto_assigns(admin_token):
    """POST /api/v1/customers/ without assigned_to should auto-assign to current user."""
    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.post("/api/v1/customers/", {"name": "Auto Corp"})
    assert resp.status_code == 201
    assert resp.data["assigned_to"] is not None


@pytest.mark.django_db
def test_create_customer_duplicate_name_fails(admin_token):
    """Creating two active customers with the same name should fail."""
    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    client.post("/api/v1/customers/", {"name": "Duplicate Corp"})
    resp = client.post("/api/v1/customers/", {"name": "Duplicate Corp"})
    # Should be a 400 (unique constraint violation)
    assert resp.status_code == 400


# ---------------------------------------------------------------------------
# List tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_list_customers(admin_token, admin_user):
    """GET /api/v1/customers/ should return a paginated list."""
    set_isolation_user(admin_user)
    Customer.objects.create(name="Corp A", assigned_to=admin_user)
    Customer.objects.create(name="Corp B", assigned_to=admin_user)

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.get("/api/v1/customers/")
    assert resp.status_code == 200
    assert resp.data["results"] is not None


# ---------------------------------------------------------------------------
# Detail tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_retrieve_customer(admin_token, admin_user):
    """GET /api/v1/customers/{id}/ should return full customer details."""
    set_isolation_user(admin_user)
    c = Customer.objects.create(
        name="Detail Corp",
        assigned_to=admin_user,
        address="123 Main St",
        notes="VIP customer",
    )

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.get(f"/api/v1/customers/{c.id}/")
    assert resp.status_code == 200
    assert resp.data["name"] == "Detail Corp"
    assert resp.data["address"] == "123 Main St"
    assert resp.data["notes"] == "VIP customer"


# ---------------------------------------------------------------------------
# Update tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_update_customer(admin_token, admin_user):
    """PUT /api/v1/customers/{id}/ should update the customer."""
    set_isolation_user(admin_user)
    c = Customer.objects.create(name="Update Corp", assigned_to=admin_user)

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.put(
        f"/api/v1/customers/{c.id}/",
        {
            "name": "Updated Corp",
            "industry": "finance",
            "level": "important",
        },
    )
    assert resp.status_code == 200
    assert resp.data["name"] == "Updated Corp"
    assert resp.data["industry"] == "finance"


# ---------------------------------------------------------------------------
# Delete (soft) tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_delete_customer_soft(admin_token, admin_user):
    """DELETE /api/v1/customers/{id}/ should soft-delete the customer."""
    set_isolation_user(admin_user)
    c = Customer.objects.create(name="Delete Corp", assigned_to=admin_user)

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.delete(f"/api/v1/customers/{c.id}/")
    assert resp.status_code == 204

    # Customer should no longer appear in list
    resp = client.get("/api/v1/customers/")
    names = [r["name"] for r in resp.data["results"]]
    assert "Delete Corp" not in names


# ---------------------------------------------------------------------------
# Filter tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_filter_by_industry(admin_token, admin_user):
    """GET /api/v1/customers/?industry=technology should filter."""
    set_isolation_user(admin_user)
    Customer.objects.create(name="Tech Corp", industry="technology", assigned_to=admin_user)
    Customer.objects.create(name="Finance Corp", industry="finance", assigned_to=admin_user)

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.get("/api/v1/customers/?industry=technology")
    names = [r["name"] for r in resp.data["results"]]
    assert "Tech Corp" in names
    assert "Finance Corp" not in names


@pytest.mark.django_db
def test_filter_by_search(admin_token, admin_user):
    """GET /api/v1/customers/?search=corp should match name."""
    set_isolation_user(admin_user)
    Customer.objects.create(name="Alpha Corp", assigned_to=admin_user)
    Customer.objects.create(name="Beta Inc", assigned_to=admin_user)

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.get("/api/v1/customers/?search=Corp")
    names = [r["name"] for r in resp.data["results"]]
    assert "Alpha Corp" in names
    assert "Beta Inc" not in names


# ---------------------------------------------------------------------------
# Permission tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_admin_staff_cannot_create(staff_token):
    """admin_staff should not be able to create customers."""
    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {staff_token}")
    resp = client.post("/api/v1/customers/", {"name": "Staff Corp"})
    assert resp.status_code == 403


@pytest.mark.django_db
def test_admin_staff_can_read(admin_user, staff_token):
    """admin_staff should be able to list customers."""
    set_isolation_user(admin_user)
    Customer.objects.create(name="Read Corp", assigned_to=admin_user)

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {staff_token}")
    resp = client.get("/api/v1/customers/")
    assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Unauthenticated tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_unauthenticated_access_denied():
    """Requests without JWT token should return 401."""
    client = APIClient()
    resp = client.get("/api/v1/customers/")
    assert resp.status_code == 401
