"""
Customer Excel import/export tasks for Celery async processing.

Export: queries customers -> generates .xlsx -> returns file path.
Import: reads .xlsx -> validates -> bulk creates -> returns stats.
"""

from celery import shared_task
from django.http import HttpResponse
import openpyxl
from io import BytesIO

from apps.customers.models import Customer, IndustryChoices, LevelChoices, SourceChoices


# ---------------------------------------------------------------------------
# Reverse lookup dicts for Excel import
# ---------------------------------------------------------------------------

_INDUSTRY_REVERSE = {v.label: v.value for v in IndustryChoices}
_LEVEL_REVERSE = {v.label: v.value for v in LevelChoices}
_SOURCE_REVERSE = {v.label: v.value for v in SourceChoices}

# Column header mapping (Excel header -> field name)
_HEADER_MAP = {
    "Company Name": "name",
    "Industry": "industry",
    "Contact Person": "contact_person",
    "Contact Phone": "contact_phone",
    "Contact Email": "contact_email",
    "Address": "address",
    "Level": "level",
    "Source": "source",
    "Notes": "notes",
}


@shared_task(queue="exports")
def export_customers_task(user_id: int, filters: dict | None = None):
    """Export customers to Excel file bytes.

    Args:
        user_id: ID of the user requesting the export (for audit/logging).
        filters: Optional dict of filters to apply to the queryset.

    Returns:
        dict with 'file_bytes' (base64-encoded) or error info.
    """
    import base64

    qs = Customer.objects.bypass_isolation()
    if filters:
        if "industry" in filters and filters["industry"]:
            qs = qs.filter(industry=filters["industry"])
        if "level" in filters and filters["level"]:
            qs = qs.filter(level=filters["level"])
        if "source" in filters and filters["source"]:
            qs = qs.filter(source=filters["source"])

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Customers"

    headers = [
        "Company Name",
        "Industry",
        "Contact Person",
        "Contact Phone",
        "Contact Email",
        "Address",
        "Level",
        "Source",
        "Assigned To",
        "Notes",
        "Created At",
    ]
    ws.append(headers)

    for customer in qs.select_related("assigned_to").iterator():
        ws.append([
            customer.name,
            customer.get_industry_display() if customer.industry else "",
            customer.contact_person,
            customer.contact_phone,
            customer.contact_email,
            customer.address,
            customer.get_level_display() if customer.level else "",
            customer.get_source_display() if customer.source else "",
            customer.assigned_to.name if customer.assigned_to else "",
            customer.notes,
            customer.created_at.strftime("%Y-%m-%d %H:%M:%S") if customer.created_at else "",
        ])

    # Auto-adjust column widths
    for col in ws.columns:
        max_length = 0
        column = col[0].column_letter
        for cell in col:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except Exception:
                pass
        ws.column_dimensions[column].width = min(max_length + 2, 50)

    buffer = BytesIO()
    wb.save(buffer)
    buffer.seek(0)

    return {
        "file_bytes": base64.b64encode(buffer.read()).decode("ascii"),
        "filename": "customers_export.xlsx",
        "count": qs.count(),
    }


@shared_task(queue="imports")
def import_customers_task(user_id: int, file_bytes_b64: str):
    """Import customers from an Excel file.

    Args:
        user_id: ID of the user performing the import (set as assigned_to if empty).
        file_bytes_b64: Base64-encoded Excel file bytes.

    Returns:
        dict with 'success' count and 'errors' count and 'error_rows' list.
    """
    import base64
    from django.contrib.auth import get_user_model

    User = get_user_model()

    try:
        user = User.objects.get(id=user_id)
    except User.DoesNotExist:
        return {"success": 0, "errors": 0, "error_rows": [], "detail": "User not found"}

    file_bytes = base64.b64decode(file_bytes_b64)
    buffer = BytesIO(file_bytes)

    try:
        wb = openpyxl.load_workbook(buffer)
    except Exception:
        return {"success": 0, "errors": 0, "error_rows": [], "detail": "Invalid Excel file"}

    ws = wb.active
    if ws is None:
        return {"success": 0, "errors": 0, "error_rows": [], "detail": "No active worksheet"}

    # Read header row (row 1)
    header_cells = []
    for cell in ws[1]:
        if cell.value:
            header_cells.append(str(cell.value).strip())

    field_map = {}
    for idx, header in enumerate(header_cells):
        if header in _HEADER_MAP:
            field_map[idx] = _HEADER_MAP[header]

    if "name" not in field_map.values():
        return {"success": 0, "errors": 0, "error_rows": [], "detail": "Missing 'Company Name' column"}

    success = 0
    errors = 0
    error_rows = []

    for row_idx, row in enumerate(ws.iter_rows(min_row=2), start=2):
        try:
            row_data = {}
            for col_idx, field_name in field_map.items():
                cell_value = row[col_idx].value if col_idx < len(row) else None
                if cell_value is not None:
                    row_data[field_name] = str(cell_value).strip()

            # Name is required
            name = row_data.get("name", "").strip()
            if not name:
                raise ValueError("Company name is empty")

            # Map display labels back to choice values
            if "industry" in row_data and row_data["industry"] in _INDUSTRY_REVERSE:
                row_data["industry"] = _INDUSTRY_REVERSE[row_data["industry"]]
            if "level" in row_data and row_data["level"] in _LEVEL_REVERSE:
                row_data["level"] = _LEVEL_REVERSE[row_data["level"]]
            if "source" in row_data and row_data["source"] in _SOURCE_REVERSE:
                row_data["source"] = _SOURCE_REVERSE[row_data["source"]]

            # Set assigned_to to importing user if not specified
            row_data.setdefault("assigned_to", user)

            Customer.objects.create(**row_data)
            success += 1

        except Exception as exc:
            errors += 1
            error_rows.append({"row": row_idx, "error": str(exc)})

    return {
        "success": success,
        "errors": errors,
        "error_rows": error_rows[:50],  # Cap at 50 error rows
    }
