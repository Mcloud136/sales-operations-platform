"""
Customer (Client Organization) model.

Represents a B2B customer company with contact info, classification,
and data isolation by assigned sales representative.
"""

from django.db import models

from apps.common.models import (
    UUIDv7ModelMixin,
    TimestampMixin,
    SoftDeleteModel,
    DataIsolationManager,
    ActiveManager,
)


class IndustryChoices(models.TextChoices):
    TECHNOLOGY = "technology", "Technology"
    MANUFACTURING = "manufacturing", "Manufacturing"
    FINANCE = "finance", "Finance"
    HEALTHCARE = "healthcare", "Healthcare"
    ENERGY = "energy", "Energy"
    REAL_ESTATE = "real_estate", "Real Estate"
    RETAIL = "retail", "Retail"
    EDUCATION = "education", "Education"
    GOVERNMENT = "government", "Government"
    OTHER = "other", "Other"


class LevelChoices(models.TextChoices):
    STRATEGIC = "strategic", "Strategic"
    IMPORTANT = "important", "Important"
    NORMAL = "normal", "Normal"
    POTENTIAL = "potential", "Potential"


class SourceChoices(models.TextChoices):
    SELF_DEVELOPED = "self_developed", "Self-Developed"
    EXHIBITION = "exhibition", "Exhibition"
    REFERRAL = "referral", "Referral"
    BIDDING_SITE = "bidding_site", "Bidding Site"
    COLD_CALL = "cold_call", "Cold Call"
    PARTNER = "partner", "Partner"
    OTHER = "other", "Other"


class CustomerManager(DataIsolationManager):
    """Manager for Customer that combines soft-delete filtering and data isolation."""
    pass


class Customer(UUIDv7ModelMixin, TimestampMixin, SoftDeleteModel):
    """B2B Customer (Client Organization).

    Inherits:
    - UUIDv7ModelMixin: timestamp-ordered UUID primary key
    - TimestampMixin: created_at / updated_at
    - SoftDeleteModel: is_deleted / deleted_at with ActiveManager

    Isolation:
    - isolation_field = 'assigned_to'
    - DataIsolationManager applies role-based filtering automatically
    """

    name = models.CharField(max_length=255, db_index=True)
    industry = models.CharField(
        max_length=30,
        choices=IndustryChoices.choices,
        blank=True,
        default="",
    )
    contact_person = models.CharField(max_length=200, blank=True, default="")
    contact_phone = models.CharField(max_length=30, blank=True, default="")
    contact_email = models.EmailField(blank=True, default="")
    address = models.TextField(blank=True, default="")
    level = models.CharField(
        max_length=20,
        choices=LevelChoices.choices,
        blank=True,
        default="normal",
    )
    source = models.CharField(
        max_length=30,
        choices=SourceChoices.choices,
        blank=True,
        default="",
    )
    assigned_to = models.ForeignKey(
        "users.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="assigned_customers",
        db_index=True,
    )
    notes = models.TextField(blank=True, default="")

    # Replace the default ActiveManager with DataIsolationManager
    objects = CustomerManager()
    all_objects = ActiveManager()

    _isolation_field = "assigned_to"

    class Meta(UUIDv7ModelMixin.Meta, TimestampMixin.Meta, SoftDeleteModel.Meta):
        db_table = "customers_customer"
        verbose_name = "Customer"
        verbose_name_plural = "Customers"
        constraints = [
            models.UniqueConstraint(
                fields=["name"],
                condition=models.Q(is_deleted=False),
                name="unique_active_customer_name",
            ),
        ]

    def __str__(self):
        return self.name
