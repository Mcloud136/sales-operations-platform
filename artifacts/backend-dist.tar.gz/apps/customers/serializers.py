"""
Serializers for the Customer model.

Provides list (summary), detail (full), create, and update variants
to control which fields are exposed at each API endpoint.
"""

from rest_framework import serializers
from apps.customers.models import (
    Customer,
    IndustryChoices,
    LevelChoices,
    SourceChoices,
)


class CustomerListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for list views -- excludes notes and address."""

    assigned_to_name = serializers.CharField(
        source="assigned_to.name", read_only=True, default=""
    )

    class Meta:
        model = Customer
        fields = (
            "id",
            "name",
            "industry",
            "level",
            "source",
            "contact_person",
            "contact_phone",
            "contact_email",
            "assigned_to",
            "assigned_to_name",
            "created_at",
            "updated_at",
        )
        read_only_fields = ("id", "created_at", "updated_at")


class CustomerDetailSerializer(CustomerListSerializer):
    """Full serializer for detail views -- includes all fields."""

    class Meta(CustomerListSerializer.Meta):
        fields = CustomerListSerializer.Meta.fields + (
            "address",
            "notes",
        )


class CustomerCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating new customers."""

    class Meta:
        model = Customer
        fields = (
            "name",
            "industry",
            "contact_person",
            "contact_phone",
            "contact_email",
            "address",
            "level",
            "source",
            "assigned_to",
            "notes",
        )

    def validate_name(self, value):
        """Ensure name is not empty/whitespace-only."""
        if not value or not value.strip():
            raise serializers.ValidationError("Customer name cannot be empty.")
        return value.strip()


class CustomerUpdateSerializer(CustomerCreateSerializer):
    """Serializer for updating existing customers. All fields optional."""

    class Meta(CustomerCreateSerializer.Meta):
        extra_kwargs = {
            "name": {"required": False, "allow_blank": False},
        }
