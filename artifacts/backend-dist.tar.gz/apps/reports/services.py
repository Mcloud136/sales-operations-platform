"""
ORM aggregation queries for dashboard KPIs and report endpoints.

All queries use bypass_isolation() because they are system-level
aggregation operations (run by Celery Beat or by admin/manager
report endpoints where data isolation is applied at the endpoint
level by DataIsolationMixin).
"""

from datetime import date, timedelta
from decimal import Decimal

from django.db.models import Sum, Count, Q, F
from django.utils import timezone

from apps.leads.models import Lead, StageChoices
from apps.contracts.models import Contract


def aggregate_dashboard_kpis() -> dict:
    """
    Aggregate dashboard KPI metrics from the database.

    Returns a dict with:
        new_leads_count: int -- leads created this month
        won_amount: str -- total estimated_amount of leads won this month
        contracts_signed_count: int -- contracts signed/active this month
        expiring_contracts_count: int -- contracts expiring within 30 days

    Uses bypass_isolation() because Celery Beat has no request user context.
    This is a system-level aggregation that spans all data.
    """
    today = timezone.now().date()
    month_start = today.replace(day=1)
    month_end = (month_start + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    expiry_threshold = today + timedelta(days=30)

    # New leads this month
    new_leads_count = (
        Lead.objects.bypass_isolation()
        .filter(
            created_at__date__gte=month_start,
            created_at__date__lte=month_end,
        )
        .count()
    )

    # Won amount this month (leads with stage='won' updated this month)
    won_result = (
        Lead.objects.bypass_isolation()
        .filter(
            stage=StageChoices.WON,
            updated_at__date__gte=month_start,
            updated_at__date__lte=month_end,
        )
        .aggregate(total=Sum("estimated_amount"))
    )
    won_amount = str(won_result["total"] or Decimal("0"))

    # Contracts signed this month (status in signed/active, start_date this month)
    contracts_signed_count = (
        Contract.objects.bypass_isolation()
        .filter(
            status__in=[Contract.STATUS_SIGNED, Contract.STATUS_ACTIVE],
            start_date__gte=month_start,
            start_date__lte=month_end,
        )
        .count()
    )

    # Expiring contracts (active/signed, end_date within 30 days)
    expiring_contracts_count = (
        Contract.objects.bypass_isolation()
        .filter(
            status__in=[Contract.STATUS_SIGNED, Contract.STATUS_ACTIVE],
            end_date__lte=expiry_threshold,
            end_date__gte=today,
        )
        .count()
    )

    return {
        "new_leads_count": new_leads_count,
        "won_amount": won_amount,
        "contracts_signed_count": contracts_signed_count,
        "expiring_contracts_count": expiring_contracts_count,
    }


def aggregate_monthly_trends(months: int = 6) -> list[dict]:
    """
    Aggregate monthly trend data for leads, won amount, and contracts.

    Returns a list of dicts, one per month (most recent first):
        {"month": "2026-06", "leads_count": 12, "won_amount": "500000.00",
         "contracts_count": 8}

    Uses bypass_isolation() for system-level aggregation.
    """
    today = timezone.now().date()
    results = []

    for i in range(months):
        # Go back i months
        ref_date = (today - timedelta(days=i * 30)).replace(day=1)
        month_end = (ref_date + timedelta(days=32)).replace(day=1) - timedelta(days=1)
        month_str = ref_date.strftime("%Y-%m")

        leads_count = (
            Lead.objects.bypass_isolation()
            .filter(
                created_at__date__gte=ref_date,
                created_at__date__lte=month_end,
            )
            .count()
        )

        won_result = (
            Lead.objects.bypass_isolation()
            .filter(
                stage=StageChoices.WON,
                updated_at__date__gte=ref_date,
                updated_at__date__lte=month_end,
            )
            .aggregate(total=Sum("estimated_amount"))
        )

        contracts_count = (
            Contract.objects.bypass_isolation()
            .filter(
                status__in=[Contract.STATUS_SIGNED, Contract.STATUS_ACTIVE],
                start_date__gte=ref_date,
                start_date__lte=month_end,
            )
            .count()
        )

        results.append({
            "month": month_str,
            "leads_count": leads_count,
            "won_amount": str(won_result["total"] or Decimal("0")),
            "contracts_count": contracts_count,
        })

    return results


def aggregate_sales_funnel() -> list[dict]:
    """
    Aggregate sales funnel data -- lead count per stage.

    Returns a list of dicts ordered by stage position:
        [{"stage": "initial_contact", "count": 20, "stage_display": "Initial Contact", ...}]

    Uses bypass_isolation() for system-level aggregation.
    """
    stage_order = [
        StageChoices.INITIAL_CONTACT,
        StageChoices.NEEDS_CONFIRMATION,
        StageChoices.PROPOSAL,
        StageChoices.NEGOTIATION,
        StageChoices.WON,
        StageChoices.LOST,
    ]

    results = []
    for stage in stage_order:
        count = (
            Lead.objects.bypass_isolation()
            .filter(stage=stage)
            .count()
        )
        results.append({
            "stage": stage,
            "stage_display": stage.label,
            "count": count,
        })

    return results


def aggregate_pending_todos() -> dict:
    """
    Aggregate pending action items for the dashboard.

    Returns:
        {
            "pending_followups": int,
            "pending_approvals": int,
            "upcoming_bid_deadlines": int,
        }
    """
    from apps.leads.models import FollowUp
    from apps.approvals.models import ApprovalStepInstance
    from apps.bids.models import BidProject

    today = timezone.now()
    week_later = today + timedelta(days=7)

    # Pending follow-ups: leads with no follow-up in the last 7 days
    pending_followups = (
        Lead.objects.bypass_isolation()
        .filter(stage__in=[
            StageChoices.INITIAL_CONTACT,
            StageChoices.NEEDS_CONFIRMATION,
            StageChoices.PROPOSAL,
            StageChoices.NEGOTIATION,
        ])
        .annotate(
            last_followup=F("followups__created_at"),
        )
        .distinct()
        .count()
    )

    # Pending approvals: approval step instances with action='pending'
    pending_approvals = (
        ApprovalStepInstance.objects.filter(
            action=ApprovalStepInstance.ACTION_PENDING
        )
        .count()
    )

    # Upcoming bid deadlines: bids with deadline within 7 days
    upcoming_deadlines = (
        BidProject.objects.bypass_isolation()
        .filter(
            bid_deadline__gte=today,
            bid_deadline__lte=week_later,
            status__in=["watching", "preparing", "submitted"],
        )
        .count()
    )

    return {
        "pending_followups": pending_followups,
        "pending_approvals": pending_approvals,
        "upcoming_bid_deadlines": upcoming_deadlines,
    }


def aggregate_sales_performance(
    start_date: date | None = None,
    end_date: date | None = None,
) -> list[dict]:
    """
    Per-person sales performance: won amount and count.

    Returns:
        [{"user_id": str, "username": str, "department": str,
          "won_amount": str, "won_count": int}]

    Filters by date range (lead updated_at) if provided.
    """
    queryset = Lead.objects.bypass_isolation().filter(stage=StageChoices.WON)

    if start_date:
        queryset = queryset.filter(updated_at__date__gte=start_date)
    if end_date:
        queryset = queryset.filter(updated_at__date__lte=end_date)

    results = (
        queryset
        .values(
            user_id=F("assigned_to__id"),
            username=F("assigned_to__username"),
            department=F("assigned_to__name"),
        )
        .annotate(
            won_amount=Sum("estimated_amount"),
            won_count=Count("id"),
        )
        .order_by("-won_amount")
    )

    return [
        {
            "user_id": str(row["user_id"]),
            "username": row["username"] or "Unknown",
            "department": row["department"] or "Unassigned",
            "won_amount": str(row["won_amount"] or Decimal("0")),
            "won_count": row["won_count"],
        }
        for row in results
    ]


def aggregate_customer_analysis() -> dict:
    """
    Customer distribution by level, industry, and source.

    Returns:
        {
            "by_level": [{"value": "important", "label": "Important", "count": 10}, ...],
            "by_industry": [{"value": "technology", "label": "Technology", "count": 8}, ...],
            "by_source": [{"value": "self_developed", "label": "Self-Developed", "count": 12}, ...],
        }
    """
    from apps.customers.models import Customer, LevelChoices, IndustryChoices, SourceChoices

    queryset = Customer.objects.bypass_isolation()

    by_level = list(
        queryset.values("level")
        .annotate(count=Count("id"))
        .order_by("-count")
    )
    by_industry = list(
        queryset.values("industry")
        .annotate(count=Count("id"))
        .order_by("-count")
    )
    by_source = list(
        queryset.values("source")
        .annotate(count=Count("id"))
        .order_by("-count")
    )

    level_map = dict(LevelChoices.choices)
    industry_map = dict(IndustryChoices.choices)
    source_map = dict(SourceChoices.choices)

    return {
        "by_level": [
            {
                "value": row["level"],
                "label": level_map.get(row["level"], row["level"]),
                "count": row["count"],
            }
            for row in by_level
        ],
        "by_industry": [
            {
                "value": row["industry"],
                "label": industry_map.get(row["industry"], row["industry"]),
                "count": row["count"],
            }
            for row in by_industry
        ],
        "by_source": [
            {
                "value": row["source"],
                "label": source_map.get(row["source"], row["source"]),
                "count": row["count"],
            }
            for row in by_source
        ],
    }


def aggregate_bid_analysis(
    start_date: date | None = None,
    end_date: date | None = None,
) -> dict:
    """
    Bid analysis: win rate by period and by team member.

    Returns:
        {
            "overall_win_rate": float,
            "total_bids": int,
            "won_bids": int,
            "lost_bids": int,
            "by_member": [{"username": str, "won": int, "lost": int, "win_rate": float}, ...],
        }
    """
    from apps.bids.models import BidProject

    queryset = BidProject.objects.bypass_isolation()

    if start_date:
        queryset = queryset.filter(created_at__date__gte=start_date)
    if end_date:
        queryset = queryset.filter(created_at__date__lte=end_date)

    total_bids = queryset.count()
    won_bids = queryset.filter(status="won").count()
    lost_bids = queryset.filter(status="lost").count()
    overall_win_rate = round(won_bids / total_bids * 100, 1) if total_bids > 0 else 0.0

    # Per member breakdown
    by_member = list(
        queryset
        .values(
            username=F("created_by__username"),
        )
        .annotate(
            won=Count("id", filter=Q(status="won")),
            lost=Count("id", filter=Q(status="lost")),
            total=Count("id"),
        )
        .order_by("-won")
    )

    member_results = []
    for row in by_member:
        total = row["total"]
        won = row["won"]
        member_results.append({
            "username": row["username"] or "Unknown",
            "won": won,
            "lost": row["lost"],
            "win_rate": round(won / total * 100, 1) if total > 0 else 0.0,
        })

    return {
        "overall_win_rate": overall_win_rate,
        "total_bids": total_bids,
        "won_bids": won_bids,
        "lost_bids": lost_bids,
        "by_member": member_results,
    }
