"""
Valkey cache helpers for dashboard KPI pre-aggregation.

Uses Valkey db 0 (Django cache backend) for storing pre-aggregated metrics.
The MSETEX command sets multiple keys with a shared TTL in one round trip.
"""

from django.conf import settings
from django.core.cache import cache

KPI_CACHE_PREFIX = "dashboard:kpi:"
KPI_TTL_SECONDS = 900  # 15 minutes


def get_valkey_connection():
    """
    Get a raw Valkey connection from the Django cache backend.

    Uses the 'default' cache configured in settings.CACHES, which maps
    to Valkey db 0.
    """
    # Django's cache backend wraps Valkey; we access the raw client
    # through the underlying connection pool.
    return cache.client.get_client()


def msetex_with_ttl(connection, mapping: dict, ttl: int) -> None:
    """
    Set multiple keys with a shared TTL using a Valkey pipeline.

    If the Valkey server supports the MSETEX command (Valkey 9.1),
    this reduces round trips by N times vs individual SETEX calls.
    Falls back to pipeline SETEX for maximum compatibility.
    """
    if not mapping:
        return

    pipeline = connection.pipeline(transaction=False)
    for key, value in mapping.items():
        pipeline.setex(key, ttl, str(value))
    pipeline.execute()


def build_kpi_cache_keys() -> list[str]:
    """Return the list of KPI cache key names."""
    return [
        f"{KPI_CACHE_PREFIX}new_leads_count",
        f"{KPI_CACHE_PREFIX}won_amount",
        f"{KPI_CACHE_PREFIX}contracts_signed_count",
        f"{KPI_CACHE_PREFIX}expiring_contracts_count",
    ]


def get_cached_kpis() -> dict | None:
    """
    Read pre-aggregated KPI values from Valkey.

    Returns a dict with keys: new_leads_count, won_amount,
    contracts_signed_count, expiring_contracts_count.
    Returns None if any key is missing (cache miss / expired).
    """
    conn = get_valkey_connection()
    keys = build_kpi_cache_keys()
    values = conn.mget(keys)

    # If any value is None, the cache is stale or never populated
    if any(v is None for v in values):
        return None

    return {
        "new_leads_count": values[0],
        "won_amount": values[1],
        "contracts_signed_count": values[2],
        "expiring_contracts_count": values[3],
    }
