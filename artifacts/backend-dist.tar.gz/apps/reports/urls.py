from django.urls import path

from apps.reports.views import (
    DashboardKpiView,
    DashboardTrendView,
    DashboardFunnelView,
    DashboardTodoView,
    SalesPerformanceView,
    CustomerAnalysisView,
    BidAnalysisView,
    ExportReportView,
)

urlpatterns = [
    # Dashboard endpoints
    path("dashboard/kpis/", DashboardKpiView.as_view(), name="dashboard-kpis"),
    path("dashboard/trends/", DashboardTrendView.as_view(), name="dashboard-trends"),
    path("dashboard/funnel/", DashboardFunnelView.as_view(), name="dashboard-funnel"),
    path("dashboard/todos/", DashboardTodoView.as_view(), name="dashboard-todos"),
    # Report endpoints
    path("reports/sales-performance/", SalesPerformanceView.as_view(), name="sales-performance"),
    path("reports/customer-analysis/", CustomerAnalysisView.as_view(), name="customer-analysis"),
    path("reports/bid-analysis/", BidAnalysisView.as_view(), name="bid-analysis"),
    # Export endpoint
    path("reports/export/", ExportReportView.as_view(), name="report-export"),
]
