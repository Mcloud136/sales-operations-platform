"""
Generic Excel export via Celery.

Exports are generated asynchronously: the API accepts an export request,
dispatches a Celery task, and the task saves the .xlsx to media/exports/.
A notification is created with the download URL upon completion.
"""

import logging
import os
from pathlib import Path

from celery import shared_task
from django.conf import settings
from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, PatternFill, Border, Side

from apps.reports.services import (
    aggregate_sales_performance,
    aggregate_customer_analysis,
    aggregate_bid_analysis,
)

logger = logging.getLogger(__name__)

EXPORT_DIR = "exports"

# Styles
HEADER_FONT = Font(bold=True, size=11)
HEADER_FILL = PatternFill(start_color="1a73e8", end_color="1a73e8", fill_type="solid")
HEADER_FONT_WHITE = Font(bold=True, size=11, color="FFFFFF")
THIN_BORDER = Border(
    left=Side(style="thin"),
    right=Side(style="thin"),
    top=Side(style="thin"),
    bottom=Side(style="thin"),
)


def build_workbook() -> Workbook:
    """Create a new workbook with default style settings."""
    wb = Workbook()
    wb.remove(wb.active)  # Remove default sheet
    return wb


def _style_header_row(ws, row: int, max_col: int) -> None:
    """Apply header styling to a row."""
    for col in range(1, max_col + 1):
        cell = ws.cell(row=row, column=col)
        cell.font = HEADER_FONT_WHITE
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="center")
        cell.border = THIN_BORDER


def _auto_width(ws) -> None:
    """Auto-adjust column widths based on content."""
    for col in ws.columns:
        max_length = 0
        col_letter = col[0].column_letter
        for cell in col:
            if cell.value:
                max_length = max(max_length, len(str(cell.value)))
        ws.column_dimensions[col_letter].width = min(max_length + 4, 40)


def build_sales_performance_sheet(wb: Workbook, data: list[dict]) -> None:
    """Build the Sales Performance sheet."""
    ws = wb.create_sheet("Sales Performance")
    headers = ["Name", "Department", "Won Count", "Won Amount"]
    ws.append(headers)
    _style_header_row(ws, 1, len(headers))

    for row in data:
        ws.append([
            row.get("username", ""),
            row.get("department", ""),
            row.get("won_count", 0),
            row.get("won_amount", "0"),
        ])

    _auto_width(ws)


def build_customer_analysis_sheet(wb: Workbook, data: dict) -> None:
    """Build customer analysis sheets: by level, by industry, by source."""
    # By Level
    ws_level = wb.create_sheet("Customer by Level")
    ws_level.append(["Level", "Count"])
    _style_header_row(ws_level, 1, 2)
    for item in data.get("by_level", []):
        ws_level.append([item.get("label", ""), item.get("count", 0)])
    _auto_width(ws_level)

    # By Industry
    ws_industry = wb.create_sheet("Customer by Industry")
    ws_industry.append(["Industry", "Count"])
    _style_header_row(ws_industry, 1, 2)
    for item in data.get("by_industry", []):
        ws_industry.append([item.get("label", ""), item.get("count", 0)])
    _auto_width(ws_industry)

    # By Source
    ws_source = wb.create_sheet("Customer by Source")
    ws_source.append(["Source", "Count"])
    _style_header_row(ws_source, 1, 2)
    for item in data.get("by_source", []):
        ws_source.append([item.get("label", ""), item.get("count", 0)])
    _auto_width(ws_source)


def build_bid_analysis_sheet(wb: Workbook, data: dict) -> None:
    """Build bid analysis sheets: summary and per-member."""
    # Summary
    ws_summary = wb.create_sheet("Bid Summary")
    ws_summary.append(["Metric", "Value"])
    _style_header_row(ws_summary, 1, 2)
    ws_summary.append(["Overall Win Rate (%)", data.get("overall_win_rate", 0)])
    ws_summary.append(["Total Bids", data.get("total_bids", 0)])
    ws_summary.append(["Won Bids", data.get("won_bids", 0)])
    ws_summary.append(["Lost Bids", data.get("lost_bids", 0)])
    _auto_width(ws_summary)

    # By Member
    ws_member = wb.create_sheet("Bid by Member")
    ws_member.append(["Member", "Won", "Lost", "Win Rate (%)"])
    _style_header_row(ws_member, 1, 4)
    for item in data.get("by_member", []):
        ws_member.append([
            item.get("username", ""),
            item.get("won", 0),
            item.get("lost", 0),
            item.get("win_rate", 0),
        ])
    _auto_width(ws_member)


def run_export(
    report_type: str,
    user_id: str,
    start_date=None,
    end_date=None,
) -> str:
    """
    Generate the Excel export and return the file path.

    Called by the Celery task. Returns the relative path within MEDIA_ROOT.
    """
    wb = build_workbook()

    if report_type == "sales_performance":
        data = aggregate_sales_performance(
            start_date=start_date,
            end_date=end_date,
        )
        build_sales_performance_sheet(wb, data)
    elif report_type == "customer_analysis":
        data = aggregate_customer_analysis()
        build_customer_analysis_sheet(wb, data)
    elif report_type == "bid_analysis":
        data = aggregate_bid_analysis(
            start_date=start_date,
            end_date=end_date,
        )
        build_bid_analysis_sheet(wb, data)
    else:
        raise ValueError(f"Unknown report type: {report_type}")

    # Ensure export directory exists
    export_path = os.path.join(settings.MEDIA_ROOT, EXPORT_DIR)
    os.makedirs(export_path, exist_ok=True)

    filename = f"{report_type}_{user_id}.xlsx"
    filepath = os.path.join(export_path, filename)
    wb.save(filepath)

    return os.path.join(EXPORT_DIR, filename)


@shared_task(
    name="reports.export_report",
    max_retries=1,
    default_retry_delay=60,
)
def export_report(
    report_type: str,
    user_id: str,
    start_date: str | None = None,
    end_date: str | None = None,
) -> dict:
    """
    Celery task to generate an Excel export.

    Args:
        report_type: One of sales_performance, customer_analysis, bid_analysis.
        user_id: UUID string of the requesting user.
        start_date: Optional ISO date string (YYYY-MM-DD).
        end_date: Optional ISO date string (YYYY-MM-DD).

    Returns:
        dict: {"file_url": "/media/exports/<filename>"}
    """
    try:
        from datetime import datetime

        sd = datetime.strptime(start_date, "%Y-%m-%d").date() if start_date else None
        ed = datetime.strptime(end_date, "%Y-%m-%d").date() if end_date else None

        rel_path = run_export(
            report_type=report_type,
            user_id=user_id,
            start_date=sd,
            end_date=ed,
        )

        file_url = f"/media/{rel_path}"
        logger.info("Export complete: %s for user %s", report_type, user_id)

        # Notify user -- best-effort, don't fail the export
        try:
            from django.contrib.auth import get_user_model

            User = get_user_model()
            user = User.objects.get(pk=user_id)
            # If notifications app exists, create a notification
            try:
                from apps.notifications.models import Notification
                Notification.objects.create(
                    recipient=user,
                    type="task_assigned",
                    title=f"Export Ready: {report_type}",
                    content=f"Your {report_type} export is ready. [Download]({file_url})",
                )
            except ImportError:
                logger.info("Notifications app not available, skipping notification.")
        except Exception as notify_err:
            logger.warning("Failed to create export notification: %s", notify_err)

        return {"file_url": file_url}

    except Exception as exc:
        logger.error("Export task failed: %s", exc, exc_info=True)
        raise export_report.retry(exc=exc)
