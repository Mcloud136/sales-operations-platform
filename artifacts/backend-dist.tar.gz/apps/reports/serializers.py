"""
Serializers for dashboard and report API endpoints.

Dashboard serializers are thin wrappers since data comes pre-aggregated.
Report serializers handle filtering parameters and output formatting.
"""

from rest_framework import serializers


# --- Dashboard Serializers ---

class DashboardKpiSerializer(serializers.Serializer):
    """Pre-aggregated dashboard KPI metrics."""
    new_leads_count = serializers.CharField(help_text="New leads created this month")
    won_amount = serializers.CharField(help_text="Total won amount this month")
    contracts_signed_count = serializers.CharField(help_text="Contracts signed this month")
    expiring_contracts_count = serializers.CharField(help_text="Contracts expiring within 30 days")


class TrendItemSerializer(serializers.Serializer):
    """Single month in the trend data."""
    month = serializers.CharField()
    leads_count = serializers.IntegerField()
    won_amount = serializers.CharField()
    contracts_count = serializers.IntegerField()


class DashboardTrendSerializer(serializers.Serializer):
    """Monthly trend data for the dashboard."""
    trends = TrendItemSerializer(many=True)


class FunnelItemSerializer(serializers.Serializer):
    """Single stage in the sales funnel."""
    stage = serializers.CharField()
    stage_display = serializers.CharField()
    count = serializers.IntegerField()


class DashboardFunnelSerializer(serializers.Serializer):
    """Sales funnel data for the dashboard."""
    funnel = FunnelItemSerializer(many=True)


class DashboardTodoSerializer(serializers.Serializer):
    """Pending action items for the dashboard."""
    pending_followups = serializers.IntegerField()
    pending_approvals = serializers.IntegerField()
    upcoming_bid_deadlines = serializers.IntegerField()


# --- Report Serializers ---

class SalesPerformanceItemSerializer(serializers.Serializer):
    """Single row in the sales performance report."""
    user_id = serializers.CharField()
    username = serializers.CharField()
    department = serializers.CharField()
    won_amount = serializers.CharField()
    won_count = serializers.IntegerField()


class SalesPerformanceSerializer(serializers.Serializer):
    """Sales performance report data."""
    results = SalesPerformanceItemSerializer(many=True)


class DistributionItemSerializer(serializers.Serializer):
    """Single item in a distribution breakdown."""
    value = serializers.CharField()
    label = serializers.CharField()
    count = serializers.IntegerField()


class CustomerAnalysisSerializer(serializers.Serializer):
    """Customer distribution analysis."""
    by_level = DistributionItemSerializer(many=True)
    by_industry = DistributionItemSerializer(many=True)
    by_source = DistributionItemSerializer(many=True)


class BidMemberItemSerializer(serializers.Serializer):
    """Single team member in the bid analysis."""
    username = serializers.CharField()
    won = serializers.IntegerField()
    lost = serializers.IntegerField()
    win_rate = serializers.FloatField()


class BidAnalysisSerializer(serializers.Serializer):
    """Bid win-rate analysis."""
    overall_win_rate = serializers.FloatField()
    total_bids = serializers.IntegerField()
    won_bids = serializers.IntegerField()
    lost_bids = serializers.IntegerField()
    by_member = BidMemberItemSerializer(many=True)


class ReportDateRangeSerializer(serializers.Serializer):
    """Common date range filter for report endpoints."""
    start_date = serializers.DateField(required=False, allow_null=True)
    end_date = serializers.DateField(required=False, allow_null=True)


class ExportRequestSerializer(serializers.Serializer):
    """Request body for initiating an Excel export."""
    report_type = serializers.ChoiceField(
        choices=["sales_performance", "customer_analysis", "bid_analysis"],
    )
    start_date = serializers.DateField(required=False, allow_null=True)
    end_date = serializers.DateField(required=False, allow_null=True)
