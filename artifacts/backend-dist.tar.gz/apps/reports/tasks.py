"""
Celery tasks for the reports module.

refresh_dashboard_kpis is scheduled via Celery Beat every 15 minutes
to pre-aggregate dashboard KPI metrics into Valkey.
"""

import logging

from celery import shared_task

from apps.reports.cache import (
    KPI_CACHE_PREFIX,
    KPI_TTL_SECONDS,
    msetex_with_ttl,
    get_valkey_connection,
)
from apps.reports.services import aggregate_dashboard_kpis

logger = logging.getLogger(__name__)


@shared_task(
    name="reports.refresh_dashboard_kpis",
    max_retries=2,
    default_retry_delay=60,
)
def refresh_dashboard_kpis() -> dict:
    """
    Pre-aggregate dashboard KPIs and store in Valkey with 15-min TTL.

    This task runs on Celery Beat every 15 minutes.
    It uses isolated_queryset() internally (via aggregate_dashboard_kpis)
    which returns unfiltered data since there is no HTTP request context.

    Returns:
        dict: The aggregated KPI values.
    """
    try:
        kpis = aggregate_dashboard_kpis()
        conn = get_valkey_connection()

        mapping = {
            f"{KPI_CACHE_PREFIX}new_leads_count": kpis["new_leads_count"],
            f"{KPI_CACHE_PREFIX}won_amount": kpis["won_amount"],
            f"{KPI_CACHE_PREFIX}contracts_signed_count": kpis["contracts_signed_count"],
            f"{KPI_CACHE_PREFIX}expiring_contracts_count": kpis["expiring_contracts_count"],
        }

        msetex_with_ttl(conn, mapping, KPI_TTL_SECONDS)

        logger.info(
            "Dashboard KPIs refreshed: leads=%s, won=%s, contracts=%s, expiring=%s",
            kpis["new_leads_count"],
            kpis["won_amount"],
            kpis["contracts_signed_count"],
            kpis["expiring_contracts_count"],
        )

        return kpis

    except Exception as exc:
        logger.error("Failed to refresh dashboard KPIs: %s", exc, exc_info=True)
        raise refresh_dashboard_kpis.retry(exc=exc)
