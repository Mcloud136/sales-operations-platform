import os
from decimal import Decimal
from unittest.mock import patch, MagicMock
from pathlib import Path

import pytest
from django.conf import settings
from django.core.files.uploadedfile import SimpleUploadedFile

from apps.users.models import User
from apps.reports.export import (
    build_workbook,
    build_sales_performance_sheet,
    build_customer_analysis_sheet,
    build_bid_analysis_sheet,
)


pytestmark = pytest.mark.django_db


@pytest.fixture
def user():
    return User.objects.create_user(
        username="exporter",
        email="exporter@example.com",
        role="sales_rep",
    )


class TestBuildSalesPerformanceSheet:
    """Test building the sales performance Excel sheet."""

    def test_creates_sheet_with_headers(self):
        """Sheet should have headers: Name, Department, Won Count, Won Amount."""
        wb = build_workbook()
        build_sales_performance_sheet(wb, [])
        ws = wb["Sales Performance"]
        assert ws["A1"].value == "Name"
        assert ws["B1"].value == "Department"
        assert ws["C1"].value == "Won Count"
        assert ws["D1"].value == "Won Amount"

    def test_populates_rows_from_data(self):
        """Sheet should contain one row per data item."""
        data = [
            {"username": "alice", "department": "Sales", "won_count": 5, "won_amount": "500000.00"},
            {"username": "bob", "department": "Marketing", "won_count": 3, "won_amount": "200000.00"},
        ]
        wb = build_workbook()
        build_sales_performance_sheet(wb, data)
        ws = wb["Sales Performance"]
        assert ws["A2"].value == "alice"
        assert ws["A3"].value == "bob"
        assert ws["D2"].value == "500000.00"


class TestBuildCustomerAnalysisSheet:
    """Test building the customer analysis Excel sheet."""

    def test_creates_level_distribution_sheet(self):
        """Sheet should list customer levels and counts."""
        data = {
            "by_level": [
                {"value": "strategic", "label": "Strategic", "count": 5},
                {"value": "important", "label": "Important", "count": 10},
            ],
            "by_industry": [],
            "by_source": [],
        }
        wb = build_workbook()
        build_customer_analysis_sheet(wb, data)
        ws = wb["Customer by Level"]
        assert ws["A1"].value == "Level"
        assert ws["B1"].value == "Count"
        assert ws["A2"].value == "Strategic"
        assert ws["B2"].value == 5


class TestBuildBidAnalysisSheet:
    """Test building the bid analysis Excel sheet."""

    def test_creates_summary_and_member_sheets(self):
        """Workbook should contain summary and per-member sheets."""
        data = {
            "overall_win_rate": 45.0,
            "total_bids": 20,
            "won_bids": 9,
            "lost_bids": 11,
            "by_member": [
                {"username": "alice", "won": 5, "lost": 3, "win_rate": 62.5},
            ],
        }
        wb = build_workbook()
        build_bid_analysis_sheet(wb, data)
        ws_summary = wb["Bid Summary"]
        assert ws_summary["A1"].value == "Metric"
        assert ws_summary["A2"].value == "Overall Win Rate (%)"
        assert ws_summary["B2"].value == 45.0

        ws_members = wb["Bid by Member"]
        assert ws_members["A1"].value == "Member"
        assert ws_members["A2"].value == "alice"


class TestExportTaskIntegration:
    """Test the full Celery export task flow."""

    @patch("apps.reports.export.build_workbook")
    def test_export_task_generates_file(self, mock_build_wb, user, tmp_path):
        """Export task should generate xlsx file in media/exports/."""
        mock_wb = MagicMock()
        mock_build_wb.return_value = mock_wb

        with patch("apps.reports.export.settings") as mock_settings:
            mock_settings.MEDIA_ROOT = str(tmp_path)
            mock_settings.EXPORT_DIR = "exports"

            from apps.reports.export import run_export

            filepath = run_export(
                report_type="sales_performance",
                user_id=str(user.id),
                start_date=None,
                end_date=None,
            )

        assert filepath is not None
        mock_wb.save.assert_called_once()
