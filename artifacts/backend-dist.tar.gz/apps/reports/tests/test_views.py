import json
from decimal import Decimal
from datetime import date, timedelta
from unittest.mock import patch

import pytest
from rest_framework.test import APIClient

from apps.users.models import User
from apps.customers.models import Customer
from apps.leads.models import Lead
from apps.contracts.models import Contract


pytestmark = pytest.mark.django_db


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def admin_user():
    user = User.objects.create_user(
        username="admin",
        email="admin@example.com",
        role="system_admin",
    )
    user.set_password("adminpass123")
    user.save()
    return user


@pytest.fixture
def sales_user():
    user = User.objects.create_user(
        username="sales1",
        email="sales1@example.com",
        role="sales_rep",
    )
    user.set_password("salespass123")
    user.save()
    return user


@pytest.fixture
def authed_client(api_client, sales_user):
    """Client authenticated as a sales rep."""
    response = api_client.post(
        "/api/v1/auth/login/",
        data={"username": "sales1", "password": "salespass123"},
        format="json",
    )
    token = response.data["access"]
    api_client.credentials(HTTP_AUTHORIZATION=f"Bearer {token}")
    return api_client


class TestDashboardKpisEndpoint:
    """Test GET /api/v1/dashboard/kpis/"""

    def test_returns_kpis_from_cache(self, authed_client):
        """Should return pre-aggregated KPIs from Valkey cache."""
        cached_kpis = {
            "new_leads_count": "10",
            "won_amount": "500000.00",
            "contracts_signed_count": "5",
            "expiring_contracts_count": "2",
        }
        with patch("apps.reports.views.get_cached_kpis", return_value=cached_kpis):
            response = authed_client.get("/api/v1/dashboard/kpis/")

        assert response.status_code == 200
        data = response.data
        assert data["new_leads_count"] == "10"
        assert data["won_amount"] == "500000.00"
        assert data["contracts_signed_count"] == "5"
        assert data["expiring_contracts_count"] == "2"

    def test_returns_stale_data_on_cache_miss(self, authed_client):
        """On cache miss, should fall back to real-time aggregation."""
        with (
            patch("apps.reports.views.get_cached_kpis", return_value=None),
            patch("apps.reports.views.aggregate_dashboard_kpis", return_value={
                "new_leads_count": 0,
                "won_amount": "0.00",
                "contracts_signed_count": 0,
                "expiring_contracts_count": 0,
            }),
        ):
            response = authed_client.get("/api/v1/dashboard/kpis/")

        assert response.status_code == 200

    def test_requires_authentication(self, api_client):
        """Unauthenticated requests should be rejected."""
        response = api_client.get("/api/v1/dashboard/kpis/")
        assert response.status_code == 401


class TestDashboardTrendsEndpoint:
    """Test GET /api/v1/dashboard/trends/"""

    def test_returns_monthly_trends(self, authed_client):
        """Should return 6 months of trend data."""
        mock_trends = [
            {"month": "2026-06", "leads_count": 12, "won_amount": "300000.00", "contracts_count": 8},
            {"month": "2026-05", "leads_count": 10, "won_amount": "250000.00", "contracts_count": 6},
        ]
        with patch("apps.reports.views.aggregate_monthly_trends", return_value=mock_trends):
            response = authed_client.get("/api/v1/dashboard/trends/")

        assert response.status_code == 200
        assert "trends" in response.data
        assert len(response.data["trends"]) == 2


class TestDashboardFunnelEndpoint:
    """Test GET /api/v1/dashboard/funnel/"""

    def test_returns_funnel_data(self, authed_client):
        """Should return lead counts by stage."""
        mock_funnel = [
            {"stage": "initial_contact", "stage_display": "Initial Contact", "count": 20},
            {"stage": "needs_confirmation", "stage_display": "Needs Confirmation", "count": 15},
        ]
        with patch("apps.reports.views.aggregate_sales_funnel", return_value=mock_funnel):
            response = authed_client.get("/api/v1/dashboard/funnel/")

        assert response.status_code == 200
        assert "funnel" in response.data
        assert len(response.data["funnel"]) == 2


class TestDashboardTodosEndpoint:
    """Test GET /api/v1/dashboard/todos/"""

    def test_returns_pending_todos(self, authed_client):
        """Should return counts for pending followups, approvals, deadlines."""
        mock_todos = {
            "pending_followups": 5,
            "pending_approvals": 3,
            "upcoming_bid_deadlines": 2,
        }
        with patch("apps.reports.views.aggregate_pending_todos", return_value=mock_todos):
            response = authed_client.get("/api/v1/dashboard/todos/")

        assert response.status_code == 200
        assert response.data["pending_followups"] == 5
        assert response.data["pending_approvals"] == 3
        assert response.data["upcoming_bid_deadlines"] == 2


class TestSalesPerformanceEndpoint:
    """Test GET /api/v1/reports/sales-performance/"""

    def test_returns_sales_performance(self, authed_client):
        """Should return per-person sales performance data."""
        mock_data = [
            {
                "user_id": "some-uuid",
                "username": "sales1",
                "department": "Sales",
                "won_amount": "500000.00",
                "won_count": 10,
            }
        ]
        with patch("apps.reports.views.aggregate_sales_performance", return_value=mock_data):
            response = authed_client.get("/api/v1/reports/sales-performance/")

        assert response.status_code == 200
        assert "results" in response.data
        assert len(response.data["results"]) == 1

    def test_accepts_date_range_filter(self, authed_client):
        """Should accept start_date and end_date query parameters."""
        with patch("apps.reports.views.aggregate_sales_performance", return_value=[]) as mock_fn:
            authed_client.get(
                "/api/v1/reports/sales-performance/"
                "?start_date=2026-01-01&end_date=2026-06-30"
            )

        mock_fn.assert_called_once()
        call_kwargs = mock_fn.call_args
        assert call_kwargs[1]["start_date"] == date(2026, 1, 1)
        assert call_kwargs[1]["end_date"] == date(2026, 6, 30)

    def test_requires_authentication(self, api_client):
        response = api_client.get("/api/v1/reports/sales-performance/")
        assert response.status_code == 401


class TestCustomerAnalysisEndpoint:
    """Test GET /api/v1/reports/customer-analysis/"""

    def test_returns_customer_analysis(self, authed_client):
        """Should return customer distribution by level, industry, source."""
        mock_data = {
            "by_level": [{"value": "important", "label": "Important", "count": 10}],
            "by_industry": [{"value": "technology", "label": "Technology", "count": 8}],
            "by_source": [{"value": "self_developed", "label": "Self Developed", "count": 12}],
        }
        with patch("apps.reports.views.aggregate_customer_analysis", return_value=mock_data):
            response = authed_client.get("/api/v1/reports/customer-analysis/")

        assert response.status_code == 200
        assert "by_level" in response.data
        assert "by_industry" in response.data
        assert "by_source" in response.data


class TestBidAnalysisEndpoint:
    """Test GET /api/v1/reports/bid-analysis/"""

    def test_returns_bid_analysis(self, authed_client):
        """Should return bid win-rate analysis."""
        mock_data = {
            "overall_win_rate": 45.0,
            "total_bids": 20,
            "won_bids": 9,
            "lost_bids": 11,
            "by_member": [
                {"username": "sales1", "won": 5, "lost": 3, "win_rate": 62.5}
            ],
        }
        with patch("apps.reports.views.aggregate_bid_analysis", return_value=mock_data):
            response = authed_client.get("/api/v1/reports/bid-analysis/")

        assert response.status_code == 200
        assert response.data["overall_win_rate"] == 45.0
        assert response.data["total_bids"] == 20
        assert len(response.data["by_member"]) == 1

    def test_accepts_date_range_filter(self, authed_client):
        """Should accept start_date and end_date query parameters."""
        with patch("apps.reports.views.aggregate_bid_analysis", return_value={
            "overall_win_rate": 0, "total_bids": 0, "won_bids": 0, "lost_bids": 0, "by_member": []
        }) as mock_fn:
            authed_client.get(
                "/api/v1/reports/bid-analysis/"
                "?start_date=2026-01-01&end_date=2026-06-30"
            )

        mock_fn.assert_called_once()
        call_kwargs = mock_fn.call_args
        assert call_kwargs[1]["start_date"] == date(2026, 1, 1)
        assert call_kwargs[1]["end_date"] == date(2026, 6, 30)
