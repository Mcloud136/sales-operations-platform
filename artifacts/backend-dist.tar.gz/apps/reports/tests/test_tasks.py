from decimal import Decimal
from unittest.mock import patch, MagicMock
import pytest

from apps.reports.tasks import refresh_dashboard_kpis


pytestmark = pytest.mark.django_db


class TestRefreshDashboardKpis:
    """Test the Celery Beat KPI pre-aggregation task."""

    def test_task_stores_kpis_in_valkey(self):
        """refresh_dashboard_kpis should aggregate KPIs and store in Valkey."""
        mock_kpis = {
            "new_leads_count": 5,
            "won_amount": "300000.00",
            "contracts_signed_count": 3,
            "expiring_contracts_count": 1,
        }
        mock_conn = MagicMock()

        with (
            patch("apps.reports.tasks.aggregate_dashboard_kpis", return_value=mock_kpis),
            patch("apps.reports.tasks.get_valkey_connection", return_value=mock_conn),
            patch("apps.reports.tasks.msetex_with_ttl") as mock_msetex,
        ):
            result = refresh_dashboard_kpis()

        assert result == mock_kpis
        mock_msetex.assert_called_once()
        # Verify TTL is 900 seconds (15 minutes)
        call_args = mock_msetex.call_args
        assert call_args[0][1] == mock_conn  # connection
        assert call_args[0][3] == 900  # TTL

    def test_task_returns_aggregated_data(self):
        """refresh_dashboard_kpis should return the aggregated KPI dict."""
        mock_kpis = {
            "new_leads_count": 0,
            "won_amount": "0.00",
            "contracts_signed_count": 0,
            "expiring_contracts_count": 0,
        }

        with (
            patch("apps.reports.tasks.aggregate_dashboard_kpis", return_value=mock_kpis),
            patch("apps.reports.tasks.get_valkey_connection"),
            patch("apps.reports.tasks.msetex_with_ttl"),
        ):
            result = refresh_dashboard_kpis()

        assert result["new_leads_count"] == 0
        assert result["won_amount"] == "0.00"

    def test_task_uses_isolated_queryset(self):
        """Task should call aggregate_dashboard_kpis which uses isolated_queryset."""
        with (
            patch("apps.reports.tasks.aggregate_dashboard_kpis", return_value={}) as mock_agg,
            patch("apps.reports.tasks.get_valkey_connection"),
            patch("apps.reports.tasks.msetex_with_ttl"),
        ):
            refresh_dashboard_kpis()

        mock_agg.assert_called_once()
