import json
from unittest.mock import patch, MagicMock
import pytest
from django.core.cache import cache
from apps.reports.cache import msetex_with_ttl, get_cached_kpis, KPI_CACHE_PREFIX


pytestmark = pytest.mark.django_db


class TestMsetexWithTtl:
    """Test the Valkey MSETEX wrapper."""

    def test_msetex_calls_msetex_command(self):
        """msetex_with_ttl should call the Valkey MSETEX pipeline command."""
        mapping = {
            f"{KPI_CACHE_PREFIX}new_leads_count": 42,
            f"{KPI_CACHE_PREFIX}won_amount": "150000.00",
        }
        ttl = 900
        mock_conn = MagicMock()
        with patch("apps.reports.cache.get_valkey_connection", return_value=mock_conn):
            msetex_with_ttl(mock_conn, mapping, ttl)
        mock_conn.msetex.assert_called_once_with(ttl, *[])
        # The wrapper should set each key individually if MSETEX is not available
        # and fall back to pipeline SETEX
        assert mock_conn.pipeline.return_value.setex.call_count == len(mapping)

    def test_msetex_with_empty_mapping(self):
        """msetex_with_ttl with empty mapping should do nothing."""
        mock_conn = MagicMock()
        with patch("apps.reports.cache.get_valkey_connection", return_value=mock_conn):
            msetex_with_ttl(mock_conn, {}, 900)
        mock_conn.pipeline.assert_not_called()


class TestGetCachedKpis:
    """Test reading pre-aggregated KPIs from Valkey."""

    def test_get_cached_kpis_returns_dict(self):
        """get_cached_kpis should return a dict with all KPI fields."""
        mock_values = {
            f"{KPI_CACHE_PREFIX}new_leads_count": "12",
            f"{KPI_CACHE_PREFIX}won_amount": "250000.00",
            f"{KPI_CACHE_PREFIX}contracts_signed_count": "8",
            f"{KPI_CACHE_PREFIX}expiring_contracts_count": "3",
        }
        mock_conn = MagicMock()
        mock_conn.mget.return_value = list(mock_values.values())

        kpi_keys = [
            f"{KPI_CACHE_PREFIX}new_leads_count",
            f"{KPI_CACHE_PREFIX}won_amount",
            f"{KPI_CACHE_PREFIX}contracts_signed_count",
            f"{KPI_CACHE_PREFIX}expiring_contracts_count",
        ]
        with patch("apps.reports.cache.get_valkey_connection", return_value=mock_conn):
            result = get_cached_kpis()

        assert isinstance(result, dict)
        assert result["new_leads_count"] == "12"
        assert result["won_amount"] == "250000.00"
        assert result["contracts_signed_count"] == "8"
        assert result["expiring_contracts_count"] == "3"

    def test_get_cached_kpis_returns_none_on_miss(self):
        """get_cached_kpis should return None when keys are missing (cache miss)."""
        mock_conn = MagicMock()
        mock_conn.mget.return_value = [None, None, None, None]

        with patch("apps.reports.cache.get_valkey_connection", return_value=mock_conn):
            result = get_cached_kpis()

        assert result is None
