from datetime import date, timedelta
from decimal import Decimal
from unittest.mock import patch
import pytest
from django.utils import timezone

from apps.users.models import User
from apps.customers.models import Customer
from apps.leads.models import Lead
from apps.contracts.models import Contract
from apps.reports.services import aggregate_dashboard_kpis


pytestmark = pytest.mark.django_db


@pytest.fixture
def system_user():
    return User.objects.create_user(
        username="system",
        email="system@example.com",
        role="system_admin",
    )


@pytest.fixture
def sales_user():
    return User.objects.create_user(
        username="sales1",
        email="sales1@example.com",
        role="sales_rep",
    )


@pytest.fixture
def customer(sales_user):
    return Customer.objects.create(
        name="Test Corp",
        industry="technology",
        contact_person="Jane Doe",
        contact_phone="13800000001",
        contact_email="jane@testcorp.com",
        address="Test Street 1",
        level="important",
        source="self_developed",
        assigned_to=sales_user,
    )


@pytest.fixture
def today():
    return timezone.now().date()


class TestAggregateDashboardKpis:
    """Test the ORM aggregation service for dashboard KPIs."""

    def test_new_leads_count_this_month(self, customer, sales_user, today):
        """Should count leads created in the current month."""
        Lead.objects.create(
            customer=customer,
            title="New Project A",
            stage="initial_contact",
            estimated_amount=Decimal("100000"),
            probability=30,
            expected_close_date=today + timedelta(days=30),
            assigned_to=sales_user,
        )
        result = aggregate_dashboard_kpis()
        assert result["new_leads_count"] == 1

    def test_won_amount_this_month(self, customer, sales_user, today):
        """Should sum estimated_amount of leads with stage='won' this month."""
        lead = Lead.objects.create(
            customer=customer,
            title="Won Deal",
            stage="initial_contact",
            estimated_amount=Decimal("500000"),
            probability=100,
            expected_close_date=today - timedelta(days=5),
            assigned_to=sales_user,
        )
        lead.mark_won()
        lead.save()
        result = aggregate_dashboard_kpis()
        assert result["won_amount"] == "500000.00"

    def test_contracts_signed_this_month(self, customer, sales_user, today):
        """Should count contracts with status='signed' whose start_date is this month."""
        Contract.objects.create(
            contract_no="HT-2026-001",
            customer=customer,
            title="Signed Contract",
            amount=Decimal("200000"),
            sign_date=today,
            start_date=today,
            end_date=today + timedelta(days=365),
            status="signed",
            assigned_to=sales_user,
        )
        result = aggregate_dashboard_kpis()
        assert result["contracts_signed_count"] == 1

    def test_expiring_contracts_count(self, customer, sales_user, today):
        """Should count active/signed contracts expiring within 30 days."""
        Contract.objects.create(
            contract_no="HT-2026-002",
            customer=customer,
            title="Expiring Contract",
            amount=Decimal("100000"),
            sign_date=today - timedelta(days=300),
            start_date=today - timedelta(days=300),
            end_date=today + timedelta(days=15),  # expires in 15 days
            status="active",
            assigned_to=sales_user,
        )
        result = aggregate_dashboard_kpis()
        assert result["expiring_contracts_count"] == 1

    def test_excludes_contracts_expiring_after_30_days(self, customer, sales_user, today):
        """Should NOT count contracts expiring more than 30 days from now."""
        Contract.objects.create(
            contract_no="HT-2026-003",
            customer=customer,
            title="Far Future Contract",
            amount=Decimal("100000"),
            sign_date=today - timedelta(days=300),
            start_date=today - timedelta(days=300),
            end_date=today + timedelta(days=90),  # expires in 90 days
            status="active",
            assigned_to=sales_user,
        )
        result = aggregate_dashboard_kpis()
        assert result["expiring_contracts_count"] == 0

    def test_excludes_soft_deleted_records(self, customer, sales_user, today):
        """Should NOT count soft-deleted leads or contracts."""
        lead = Lead.objects.create(
            customer=customer,
            title="Deleted Lead",
            stage="initial_contact",
            estimated_amount=Decimal("100000"),
            probability=30,
            expected_close_date=today + timedelta(days=30),
            assigned_to=sales_user,
        )
        lead.soft_delete()

        result = aggregate_dashboard_kpis()
        assert result["new_leads_count"] == 0

    def test_zero_values_when_no_data(self):
        """Should return zeros when no data exists."""
        result = aggregate_dashboard_kpis()
        assert result["new_leads_count"] == 0
        assert result["won_amount"] == "0.00"
        assert result["contracts_signed_count"] == 0
        assert result["expiring_contracts_count"] == 0
