"""
Dashboard and Report API views.

All views use sync def per Iron Rule 5: complex ORM aggregation,
report generation, and cache reads require synchronous execution.
Cache-only endpoints (KPI read from Valkey) could technically be async,
but are kept sync for simplicity and consistency.
"""

import logging
from datetime import date

from rest_framework import status as http_status, views as api_views, permissions
from rest_framework.response import Response

from apps.reports.cache import get_cached_kpis
from apps.reports.services import (
    aggregate_dashboard_kpis,
    aggregate_monthly_trends,
    aggregate_sales_funnel,
    aggregate_pending_todos,
    aggregate_sales_performance,
    aggregate_customer_analysis,
    aggregate_bid_analysis,
)
from apps.reports.export import export_report
from apps.reports.serializers import (
    DashboardKpiSerializer,
    DashboardTrendSerializer,
    DashboardFunnelSerializer,
    DashboardTodoSerializer,
    SalesPerformanceSerializer,
    CustomerAnalysisSerializer,
    BidAnalysisSerializer,
    ReportDateRangeSerializer,
    ExportRequestSerializer,
)

logger = logging.getLogger(__name__)


# --- Dashboard Views ---

class DashboardKpiView(api_views.APIView):
    """
    GET /api/v1/dashboard/kpis/

    Returns pre-aggregated dashboard KPI metrics from Valkey cache.
    Falls back to real-time aggregation on cache miss.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        cached = get_cached_kpis()
        if cached is not None:
            return Response(DashboardKpiSerializer(cached).data)

        # Cache miss: fall back to real-time aggregation
        logger.warning("Dashboard KPI cache miss -- falling back to real-time query")
        kpis = aggregate_dashboard_kpis()
        return Response(DashboardKpiSerializer(kpis).data)


class DashboardTrendView(api_views.APIView):
    """
    GET /api/v1/dashboard/trends/

    Returns monthly trend data (leads/won/contracts) for the last 6 months.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        trends = aggregate_monthly_trends(months=6)
        serializer = DashboardTrendSerializer({"trends": trends})
        return Response(serializer.data)


class DashboardFunnelView(api_views.APIView):
    """
    GET /api/v1/dashboard/funnel/

    Returns sales funnel data (lead count by stage).
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        funnel = aggregate_sales_funnel()
        serializer = DashboardFunnelSerializer({"funnel": funnel})
        return Response(serializer.data)


class DashboardTodoView(api_views.APIView):
    """
    GET /api/v1/dashboard/todos/

    Returns pending action item counts:
    - pending_followups: leads without recent follow-up
    - pending_approvals: pending approval step instances
    - upcoming_bid_deadlines: bids with deadline within 7 days
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        todos = aggregate_pending_todos()
        serializer = DashboardTodoSerializer(todos)
        return Response(serializer.data)


# --- Report Views ---

class SalesPerformanceView(api_views.APIView):
    """
    GET /api/v1/reports/sales-performance/

    Per-person sales performance: won amount and count.
    Supports optional start_date and end_date query parameters.
    Uses sync def per Iron Rule 5 (complex ORM aggregation).
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        params = ReportDateRangeSerializer(data=request.query_params)
        params.is_valid(raise_exception=True)

        results = aggregate_sales_performance(
            start_date=params.validated_data.get("start_date"),
            end_date=params.validated_data.get("end_date"),
        )
        serializer = SalesPerformanceSerializer({"results": results})
        return Response(serializer.data)


class CustomerAnalysisView(api_views.APIView):
    """
    GET /api/v1/reports/customer-analysis/

    Customer distribution by level, industry, and source.
    Uses sync def per Iron Rule 5 (complex ORM aggregation).
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        data = aggregate_customer_analysis()
        serializer = CustomerAnalysisSerializer(data)
        return Response(serializer.data)


class BidAnalysisView(api_views.APIView):
    """
    GET /api/v1/reports/bid-analysis/

    Bid win-rate analysis: overall and per team member.
    Supports optional start_date and end_date query parameters.
    Uses sync def per Iron Rule 5 (complex ORM aggregation).
    """
    permission_classes = [permissions.IsAuthenticated]

    def get(self, request):
        params = ReportDateRangeSerializer(data=request.query_params)
        params.is_valid(raise_exception=True)

        data = aggregate_bid_analysis(
            start_date=params.validated_data.get("start_date"),
            end_date=params.validated_data.get("end_date"),
        )
        serializer = BidAnalysisSerializer(data)
        return Response(serializer.data)


class ExportReportView(api_views.APIView):
    """
    POST /api/v1/reports/export/

    Trigger an async Excel export via Celery.
    Accepts: {"report_type": "sales_performance|customer_analysis|bid_analysis",
              "start_date": "YYYY-MM-DD", "end_date": "YYYY-MM-DD"}
    Returns: {"task_id": "..."} with HTTP 202 Accepted.
    """
    permission_classes = [permissions.IsAuthenticated]

    def post(self, request):
        serializer = ExportRequestSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        task = export_report.delay(
            report_type=serializer.validated_data["report_type"],
            user_id=str(request.user.id),
            start_date=str(serializer.validated_data.get("start_date") or ""),
            end_date=str(serializer.validated_data.get("end_date") or ""),
        )

        return Response(
            {"task_id": task.id, "status": "processing"},
            status=http_status.HTTP_202_ACCEPTED,
        )
