import pytest
from rest_framework.test import APIClient
from apps.common.models import set_isolation_user, reset_isolation_user
from apps.users.models import User
from apps.customers.models import Customer
from apps.leads.models import Lead, FollowUp, StageChoices


@pytest.fixture
def admin_user():
    return User.objects.create_user(
        username="leadview_admin", email="lva@example.com", role="system_admin", password="pass123"
    )


@pytest.fixture
def sales_rep():
    return User.objects.create_user(
        username="leadview_rep", email="lvr@example.com", role="sales_rep", password="pass123"
    )


@pytest.fixture
def admin_token(admin_user):
    client = APIClient()
    resp = client.post("/api/v1/auth/login/", {"username": "leadview_admin", "password": "pass123"})
    return resp.data["access"]


@pytest.fixture
def rep_token(sales_rep):
    client = APIClient()
    resp = client.post("/api/v1/auth/login/", {"username": "leadview_rep", "password": "pass123"})
    return resp.data["access"]


@pytest.fixture
def customer(admin_user):
    set_isolation_user(admin_user)
    return Customer.objects.create(name="View Customer", assigned_to=admin_user)


@pytest.fixture(autouse=True)
def _isolation(admin_user):
    set_isolation_user(admin_user)
    yield
    reset_isolation_user()


# ---------------------------------------------------------------------------
# Create tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_create_lead(admin_token, customer):
    """POST /api/v1/leads/ should create a lead."""
    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.post(
        "/api/v1/leads/",
        {
            "customer": str(customer.id),
            "title": "New Lead",
            "stage": "initial_contact",
            "estimated_amount": "50000.00",
            "probability": 60,
            "expected_close_date": "2026-12-31",
        },
    )
    assert resp.status_code == 201
    assert resp.data["title"] == "New Lead"
    assert resp.data["stage"] == "initial_contact"
    assert "id" in resp.data


@pytest.mark.django_db
def test_create_lead_probability_validation(admin_token, customer):
    """Creating a lead with probability > 100 should fail."""
    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.post(
        "/api/v1/leads/",
        {
            "customer": str(customer.id),
            "title": "Bad Probability",
            "probability": 150,
        },
    )
    assert resp.status_code == 400


# ---------------------------------------------------------------------------
# List tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_list_leads(admin_token, admin_user, customer):
    """GET /api/v1/leads/ should return a paginated list."""
    set_isolation_user(admin_user)
    Lead.objects.create(
        customer=customer, title="Lead A",
        stage=StageChoices.INITIAL_CONTACT, assigned_to=admin_user,
    )

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.get("/api/v1/leads/")
    assert resp.status_code == 200
    assert resp.data["results"] is not None


# ---------------------------------------------------------------------------
# Stage transition tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_patch_stage_forward(admin_token, admin_user, customer):
    """PATCH /api/v1/leads/{id}/stage/ should advance the stage."""
    set_isolation_user(admin_user)
    lead = Lead.objects.create(
        customer=customer, title="Stage Lead",
        stage=StageChoices.INITIAL_CONTACT, assigned_to=admin_user,
    )

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.patch(
        f"/api/v1/leads/{lead.id}/stage/",
        {"stage": "needs_confirmation"},
    )
    assert resp.status_code == 200
    assert resp.data["stage"] == "needs_confirmation"


@pytest.mark.django_db
def test_patch_stage_to_won(admin_token, admin_user, customer):
    """PATCH /api/v1/leads/{id}/stage/ to 'won' should succeed."""
    set_isolation_user(admin_user)
    lead = Lead.objects.create(
        customer=customer, title="Win Lead",
        stage=StageChoices.NEGOTIATION, assigned_to=admin_user,
    )

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.patch(f"/api/v1/leads/{lead.id}/stage/", {"stage": "won"})
    assert resp.status_code == 200
    assert resp.data["stage"] == "won"


@pytest.mark.django_db
def test_patch_stage_invalid_transition(admin_token, admin_user, customer):
    """PATCH /api/v1/leads/{id}/stage/ with invalid transition should fail."""
    set_isolation_user(admin_user)
    lead = Lead.objects.create(
        customer=customer, title="Bad Trans Lead",
        stage=StageChoices.INITIAL_CONTACT, assigned_to=admin_user,
    )

    # Cannot jump from initial_contact directly to negotiation
    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.patch(f"/api/v1/leads/{lead.id}/stage/", {"stage": "negotiation"})
    assert resp.status_code == 400


@pytest.mark.django_db
def test_patch_stage_from_won_fails(admin_token, admin_user, customer):
    """PATCH /api/v1/leads/{id}/stage/ from 'won' should fail."""
    set_isolation_user(admin_user)
    lead = Lead.objects.create(
        customer=customer, title="Won Lead",
        stage=StageChoices.NEGOTIATION, assigned_to=admin_user,
    )
    lead.mark_won()
    lead.save(update_fields=["stage", "updated_at"])

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.patch(f"/api/v1/leads/{lead.id}/stage/", {"stage": "proposal"})
    assert resp.status_code == 400


# ---------------------------------------------------------------------------
# FollowUp nested tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_create_followup(admin_token, admin_user, customer):
    """POST /api/v1/leads/{id}/followups/ should create a follow-up."""
    set_isolation_user(admin_user)
    lead = Lead.objects.create(
        customer=customer, title="Follow Lead",
        stage=StageChoices.NEEDS_CONFIRMATION, assigned_to=admin_user,
    )

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.post(
        f"/api/v1/leads/{lead.id}/followups/",
        {"type": "phone", "content": "Discussed timeline with client."},
    )
    assert resp.status_code == 201
    assert resp.data["type"] == "phone"
    assert resp.data["content"] == "Discussed timeline with client."


@pytest.mark.django_db
def test_list_followups(admin_token, admin_user, customer):
    """GET /api/v1/leads/{id}/followups/ should return follow-ups for a lead."""
    set_isolation_user(admin_user)
    lead = Lead.objects.create(
        customer=customer, title="List Follow Lead",
        stage=StageChoices.PROPOSAL, assigned_to=admin_user,
    )
    FollowUp.objects.create(
        lead=lead, type="email", content="Sent proposal", created_by=admin_user,
    )

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.get(f"/api/v1/leads/{lead.id}/followups/")
    assert resp.status_code == 200


# ---------------------------------------------------------------------------
# Stats endpoint tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_lead_stats(admin_token, admin_user, customer):
    """GET /api/v1/leads/stats/ should return stage counts."""
    set_isolation_user(admin_user)
    Lead.objects.create(
        customer=customer, title="Stat Lead 1",
        stage=StageChoices.INITIAL_CONTACT, assigned_to=admin_user,
    )
    Lead.objects.create(
        customer=customer, title="Stat Lead 2",
        stage=StageChoices.INITIAL_CONTACT, assigned_to=admin_user,
    )
    Lead.objects.create(
        customer=customer, title="Stat Lead 3",
        stage=StageChoices.PROPOSAL, assigned_to=admin_user,
    )

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.get("/api/v1/leads/stats/")
    assert resp.status_code == 200
    stages = {item["stage"]: item["count"] for item in resp.data}
    assert stages.get("initial_contact") == 2
    assert stages.get("proposal") == 1


# ---------------------------------------------------------------------------
# Delete (soft) tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_delete_lead_soft(admin_token, admin_user, customer):
    """DELETE /api/v1/leads/{id}/ should soft-delete."""
    set_isolation_user(admin_user)
    lead = Lead.objects.create(
        customer=customer, title="Del Lead",
        stage=StageChoices.INITIAL_CONTACT, assigned_to=admin_user,
    )

    client = APIClient()
    client.credentials(HTTP_AUTHORIZATION=f"Bearer {admin_token}")
    resp = client.delete(f"/api/v1/leads/{lead.id}/")
    assert resp.status_code == 204


# ---------------------------------------------------------------------------
# Unauthenticated tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_unauthenticated_leads_denied():
    """Requests without JWT should return 401."""
    client = APIClient()
    resp = client.get("/api/v1/leads/")
    assert resp.status_code == 401
