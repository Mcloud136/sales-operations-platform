import pytest
from django.db import IntegrityError
from apps.common.models import set_isolation_user, reset_isolation_user
from apps.users.models import User
from apps.customers.models import Customer
from apps.leads.models import Lead, FollowUp, StageChoices


@pytest.fixture
def admin_user():
    return User.objects.create_user(
        username="lead_admin", email="lead_admin@example.com", role="system_admin"
    )


@pytest.fixture
def sales_rep():
    return User.objects.create_user(
        username="lead_rep", email="lead_rep@example.com", role="sales_rep"
    )


@pytest.fixture
def customer(admin_user):
    set_isolation_user(admin_user)
    return Customer.objects.create(name="Lead Customer", assigned_to=admin_user)


@pytest.fixture(autouse=True)
def _set_isolation(admin_user):
    set_isolation_user(admin_user)
    yield
    reset_isolation_user()


# ---------------------------------------------------------------------------
# Lead model tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_lead_has_uuidv7_pk(admin_user, customer):
    """Lead primary key should be UUIDv7."""
    lead = Lead.objects.create(
        customer=customer,
        title="Test Lead",
        stage=StageChoices.INITIAL_CONTACT,
        assigned_to=admin_user,
    )
    assert lead.id is not None
    assert str(lead.id)[0] in "01234567"


@pytest.mark.django_db
def test_lead_soft_delete(admin_user, customer):
    """Soft-deleting a lead should hide it from default queryset."""
    lead = Lead.objects.create(
        customer=customer,
        title="Delete Lead",
        stage=StageChoices.INITIAL_CONTACT,
        assigned_to=admin_user,
    )
    lead.soft_delete()
    assert lead not in Lead.objects.all()
    assert lead in Lead.all_objects.all()


@pytest.mark.django_db
def test_lead_stage_fsm_initial(admin_user, customer):
    """A new lead should start in initial_contact stage."""
    lead = Lead.objects.create(
        customer=customer,
        title="FSM Lead",
        stage=StageChoices.INITIAL_CONTACT,
        assigned_to=admin_user,
    )
    assert lead.stage == StageChoices.INITIAL_CONTACT


@pytest.mark.django_db
def test_lead_stage_transition_forward(admin_user, customer):
    """Lead should transition forward through allowed stages."""
    lead = Lead.objects.create(
        customer=customer,
        title="Forward Lead",
        stage=StageChoices.INITIAL_CONTACT,
        assigned_to=admin_user,
    )
    lead.advance_stage()
    assert lead.stage == StageChoices.NEEDS_CONFIRMATION

    lead.advance_stage()
    assert lead.stage == StageChoices.PROPOSAL

    lead.advance_stage()
    assert lead.stage == StageChoices.NEGOTIATION

    lead.mark_won()
    assert lead.stage == StageChoices.WON


@pytest.mark.django_db
def test_lead_stage_transition_to_lost(admin_user, customer):
    """Lead should be able to transition to lost from any active stage."""
    lead = Lead.objects.create(
        customer=customer,
        title="Lose Lead",
        stage=StageChoices.NEGOTIATION,
        assigned_to=admin_user,
    )
    lead.mark_lost()
    assert lead.stage == StageChoices.LOST


@pytest.mark.django_db
def test_lead_cannot_transition_from_won(admin_user, customer):
    """A won lead should not be able to advance further."""
    lead = Lead.objects.create(
        customer=customer,
        title="Won Lead",
        stage=StageChoices.NEGOTIATION,
        assigned_to=admin_user,
    )
    lead.mark_won()
    with pytest.raises(Exception):  # TransitionNotAllowed from django-fsm
        lead.advance_stage()


@pytest.mark.django_db
def test_lead_cannot_transition_from_lost(admin_user, customer):
    """A lost lead should not be able to advance further."""
    lead = Lead.objects.create(
        customer=customer,
        title="Lost Lead",
        stage=StageChoices.INITIAL_CONTACT,
        assigned_to=admin_user,
    )
    lead.mark_lost()
    with pytest.raises(Exception):
        lead.advance_stage()


@pytest.mark.django_db
def test_lead_isolation(admin_user, sales_rep, customer):
    """A sales_rep should only see their own leads."""
    set_isolation_user(admin_user)
    Lead.objects.create(
        customer=customer,
        title="Admin Lead",
        stage=StageChoices.INITIAL_CONTACT,
        assigned_to=admin_user,
    )
    set_isolation_user(sales_rep)
    customer2 = Customer.objects.create(name="Rep Customer", assigned_to=sales_rep)
    Lead.objects.create(
        customer=customer2,
        title="Rep Lead",
        stage=StageChoices.INITIAL_CONTACT,
        assigned_to=sales_rep,
    )

    # rep should only see their own
    visible = list(Lead.objects.values_list("title", flat=True))
    assert visible == ["Rep Lead"]


@pytest.mark.django_db
def test_lead_string_representation(admin_user, customer):
    """Lead __str__ should return the title."""
    lead = Lead.objects.create(
        customer=customer,
        title="String Lead",
        stage=StageChoices.INITIAL_CONTACT,
        assigned_to=admin_user,
    )
    assert str(lead) == "String Lead"


# ---------------------------------------------------------------------------
# FollowUp model tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_create_followup(admin_user, customer):
    """FollowUp should be creatable with lead, type, content, and created_by."""
    lead = Lead.objects.create(
        customer=customer,
        title="Follow Lead",
        stage=StageChoices.NEEDS_CONFIRMATION,
        assigned_to=admin_user,
    )
    followup = FollowUp.objects.create(
        lead=lead,
        type="phone",
        content="Called to discuss requirements",
        created_by=admin_user,
    )
    assert followup.id is not None
    assert followup.lead == lead
    assert followup.type == "phone"
    assert followup.created_by == admin_user


@pytest.mark.django_db
def test_followup_string_representation(admin_user, customer):
    """FollowUp __str__ should show lead title and type."""
    lead = Lead.objects.create(
        customer=customer,
        title="Follow Lead",
        stage=StageChoices.NEEDS_CONFIRMATION,
        assigned_to=admin_user,
    )
    followup = FollowUp.objects.create(
        lead=lead,
        type="visit",
        content="Site visit",
        created_by=admin_user,
    )
    assert "Follow Lead" in str(followup)
    assert "visit" in str(followup)
