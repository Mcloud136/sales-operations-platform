import pytest
from apps.common.models import set_isolation_user, reset_isolation_user
from apps.users.models import User
from apps.customers.models import Customer
from apps.leads.models import Lead, StageChoices


@pytest.fixture(autouse=True)
def _isolation():
    admin = User.objects.create_user(
        username="lfilter_admin", email="lfa@example.com", role="system_admin"
    )
    set_isolation_user(admin)
    yield
    reset_isolation_user()


@pytest.mark.django_db
def test_filter_by_stage():
    """Filtering by stage should return only leads in that stage."""
    admin = User.objects.get(username="lfilter_admin")
    set_isolation_user(admin)
    customer = Customer.objects.create(name="Filter Cust", assigned_to=admin)
    Lead.objects.create(customer=customer, title="IC Lead", stage=StageChoices.INITIAL_CONTACT, assigned_to=admin)
    Lead.objects.create(customer=customer, title="Prop Lead", stage=StageChoices.PROPOSAL, assigned_to=admin)

    from apps.leads.filters import LeadFilter

    qs = Lead.objects.all()
    f = LeadFilter(data={"stage": "initial_contact"}, queryset=qs)
    result = list(f.qs.values_list("title", flat=True))
    assert result == ["IC Lead"]


@pytest.mark.django_db
def test_filter_by_customer():
    """Filtering by customer should return only leads for that customer."""
    admin = User.objects.get(username="lfilter_admin")
    set_isolation_user(admin)
    cust1 = Customer.objects.create(name="Cust1", assigned_to=admin)
    cust2 = Customer.objects.create(name="Cust2", assigned_to=admin)
    Lead.objects.create(customer=cust1, title="C1 Lead", stage=StageChoices.INITIAL_CONTACT, assigned_to=admin)
    Lead.objects.create(customer=cust2, title="C2 Lead", stage=StageChoices.INITIAL_CONTACT, assigned_to=admin)

    from apps.leads.filters import LeadFilter

    qs = Lead.objects.all()
    f = LeadFilter(data={"customer": str(cust1.id)}, queryset=qs)
    result = list(f.qs.values_list("title", flat=True))
    assert result == ["C1 Lead"]


@pytest.mark.django_db
def test_filter_by_expected_close_date():
    """Filtering by expected_close_after should return leads closing after that date."""
    admin = User.objects.get(username="lfilter_admin")
    set_isolation_user(admin)
    customer = Customer.objects.create(name="Date Cust", assigned_to=admin)
    Lead.objects.create(
        customer=customer, title="Late Lead", stage=StageChoices.PROPOSAL,
        assigned_to=admin, expected_close_date="2026-12-31",
    )
    Lead.objects.create(
        customer=customer, title="Early Lead", stage=StageChoices.PROPOSAL,
        assigned_to=admin, expected_close_date="2026-03-01",
    )

    from apps.leads.filters import LeadFilter
    from datetime import date

    qs = Lead.objects.all()
    f = LeadFilter(data={"expected_close_after": "2026-07-01"}, queryset=qs)
    result = list(f.qs.values_list("title", flat=True))
    assert result == ["Late Lead"]
