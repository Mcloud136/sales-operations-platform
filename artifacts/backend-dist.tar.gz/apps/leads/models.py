"""
Lead and FollowUp models.

Lead represents a sales opportunity with FSM-governed stage transitions.
FollowUp records track activities (calls, visits, emails) on a lead.
"""

from django.db import models
from django_fsm import FSMField, transition

from apps.common.models import (
    UUIDv7ModelMixin,
    TimestampMixin,
    SoftDeleteModel,
    DataIsolationManager,
    ActiveManager,
)


class StageChoices(models.TextChoices):
    INITIAL_CONTACT = "initial_contact", "Initial Contact"
    NEEDS_CONFIRMATION = "needs_confirmation", "Needs Confirmation"
    PROPOSAL = "proposal", "Proposal"
    NEGOTIATION = "negotiation", "Negotiation"
    WON = "won", "Won"
    LOST = "lost", "Lost"


class FollowUpTypeChoices(models.TextChoices):
    PHONE = "phone", "Phone"
    VISIT = "visit", "Visit"
    EMAIL = "email", "Email"
    OTHER = "other", "Other"


# ---------------------------------------------------------------------------
# Stage transition helpers
# ---------------------------------------------------------------------------

_STAGE_ORDER = [
    StageChoices.INITIAL_CONTACT,
    StageChoices.NEEDS_CONFIRMATION,
    StageChoices.PROPOSAL,
    StageChoices.NEGOTIATION,
]


def _next_stage(current_stage):
    """Return the next stage in the pipeline, or None if at the end."""
    try:
        idx = _STAGE_ORDER.index(current_stage)
    except ValueError:
        return None
    if idx + 1 < len(_STAGE_ORDER):
        return _STAGE_ORDER[idx + 1]
    return None


def _is_active_stage(stage):
    """Return True if the stage is not won or lost (terminal)."""
    return stage not in (StageChoices.WON, StageChoices.LOST)


# ---------------------------------------------------------------------------
# Managers
# ---------------------------------------------------------------------------

class LeadManager(DataIsolationManager):
    """Manager for Lead that combines soft-delete filtering and data isolation."""
    pass


class FollowUpManager(models.Manager):
    """Default manager for FollowUp (no isolation needed -- accessed via lead FK)."""
    pass


# ---------------------------------------------------------------------------
# Lead Model
# ---------------------------------------------------------------------------

class Lead(UUIDv7ModelMixin, TimestampMixin, SoftDeleteModel):
    """Sales Opportunity (Lead).

    Inherits:
    - UUIDv7ModelMixin: timestamp-ordered UUID primary key
    - TimestampMixin: created_at / updated_at
    - SoftDeleteModel: is_deleted / deleted_at

    Stage transitions are enforced by django-fsm.
    """

    customer = models.ForeignKey(
        "customers.Customer",
        on_delete=models.PROTECT,
        related_name="leads",
        db_index=True,
    )
    title = models.CharField(max_length=255)
    stage = FSMField(
        max_length=30,
        choices=StageChoices.choices,
        default=StageChoices.INITIAL_CONTACT,
        protected=True,
    )
    estimated_amount = models.DecimalField(
        max_digits=14, decimal_places=2, null=True, blank=True
    )
    probability = models.IntegerField(
        null=True, blank=True,
        help_text="Probability of winning (0-100)",
    )
    expected_close_date = models.DateField(null=True, blank=True, db_index=True)
    assigned_to = models.ForeignKey(
        "users.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="assigned_leads",
        db_index=True,
    )
    description = models.TextField(blank=True, default="")

    objects = LeadManager()
    all_objects = ActiveManager()

    _isolation_field = "assigned_to"

    # -----------------------------------------------------------------------
    # FSM transitions
    # -----------------------------------------------------------------------

    @transition(
        field=stage,
        source=[*[_is_active_stage(s) for s in _STAGE_ORDER]],
        target=_next_stage,
    )
    def advance_stage(self):
        """Advance to the next stage in the pipeline."""
        pass

    @transition(
        field=stage,
        source=_is_active_stage,
        target=StageChoices.WON,
    )
    def mark_won(self):
        """Mark this lead as won."""
        pass

    @transition(
        field=stage,
        source=_is_active_stage,
        target=StageChoices.LOST,
    )
    def mark_lost(self):
        """Mark this lead as lost."""
        pass

    class Meta(UUIDv7ModelMixin.Meta, TimestampMixin.Meta, SoftDeleteModel.Meta):
        db_table = "leads_lead"
        verbose_name = "Lead"
        verbose_name_plural = "Leads"
        ordering = ["-created_at"]

    def __str__(self):
        return self.title


# ---------------------------------------------------------------------------
# FollowUp Model
# ---------------------------------------------------------------------------

class FollowUp(UUIDv7ModelMixin, TimestampMixin):
    """Activity record for a Lead (call, visit, email, other).

    Does NOT inherit SoftDeleteModel -- follow-ups are permanent records.
    """

    lead = models.ForeignKey(
        Lead,
        on_delete=models.CASCADE,
        related_name="followups",
        db_index=True,
    )
    type = models.CharField(
        max_length=20,
        choices=FollowUpTypeChoices.choices,
        default=FollowUpTypeChoices.OTHER,
    )
    content = models.TextField()
    created_by = models.ForeignKey(
        "users.User",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="created_followups",
    )

    objects = FollowUpManager()

    class Meta(UUIDv7ModelMixin.Meta, TimestampMixin.Meta):
        db_table = "leads_followup"
        verbose_name = "Follow-Up"
        verbose_name_plural = "Follow-Ups"
        ordering = ["-created_at"]

    def __str__(self):
        return f"[{self.type}] {self.lead.title}"
