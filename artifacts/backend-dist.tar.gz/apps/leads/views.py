"""
Lead and FollowUp API views.

LeadViewSet provides CRUD with FSM-guarded stage transitions.
FollowUpViewSet is nested under a lead.
Lead stats endpoint provides stage counts for dashboard/Kanban.
"""

from django.db import models
from rest_framework import viewsets, status, permissions
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError

from apps.common.mixins import DataIsolationMixin
from apps.common.permissions import IsRoleAllowed
from apps.leads.models import Lead, FollowUp, StageChoices
from apps.leads.serializers import (
    LeadListSerializer,
    LeadDetailSerializer,
    LeadCreateSerializer,
    LeadUpdateSerializer,
    LeadStageSerializer,
    FollowUpSerializer,
    FollowUpCreateSerializer,
)
from apps.leads.filters import LeadFilter


class LeadViewSet(DataIsolationMixin, viewsets.ModelViewSet):
    """
    Lead CRUD API.

    - List: GET /api/v1/leads/
    - Create: POST /api/v1/leads/
    - Detail: GET /api/v1/leads/{id}/
    - Update: PUT /api/v1/leads/{id}/
    - Delete: DELETE /api/v1/leads/{id}/
    - Stage transition: PATCH /api/v1/leads/{id}/stage/
    - Follow-ups: GET/POST /api/v1/leads/{id}/followups/
    - Stats: GET /api/v1/leads/stats/

    Permissions: system_admin, sales_manager, sales_rep can CRUD.
    admin_staff has no access to leads.
    """

    permission_classes = [permissions.IsAuthenticated, IsRoleAllowed]
    allowed_roles = ["system_admin", "sales_manager", "sales_rep"]

    queryset = Lead.objects.select_related("customer", "assigned_to").all()
    filterset_class = LeadFilter
    search_fields = ("title", "customer__name")
    ordering_fields = ("title", "stage", "estimated_amount", "expected_close_date", "created_at")
    ordering = ("-created_at",)

    def get_serializer_class(self):
        if self.action == "list":
            return LeadListSerializer
        if self.action == "retrieve":
            return LeadDetailSerializer
        if self.action == "create":
            return LeadCreateSerializer
        if self.action in ("update", "partial_update"):
            return LeadUpdateSerializer
        if self.action == "change_stage":
            return LeadStageSerializer
        if self.action == "followups":
            return FollowUpSerializer
        return LeadDetailSerializer

    def perform_create(self, serializer):
        """Set assigned_to to current user if not provided."""
        if serializer.validated_data.get("assigned_to") is None:
            serializer.validated_data["assigned_to"] = self.request.user
        serializer.save()

    def destroy(self, request, *args, **kwargs):
        """Soft-delete the lead."""
        lead = self.get_object()
        lead.soft_delete()
        return Response(
            {"detail": "Lead deleted successfully."},
            status=status.HTTP_204_NO_CONTENT,
        )

    # -----------------------------------------------------------------------
    # Stage transition endpoint (sync def -- django-fsm is synchronous)
    # -----------------------------------------------------------------------

    @action(detail=True, methods=["patch"], url_path="stage")
    def change_stage(self, request, pk=None):
        """PATCH /api/v1/leads/{id}/stage/

        Transition a lead to a new stage. Uses django-fsm guarded transitions.
        Returns 400 if the transition is not allowed.
        """
        lead = self.get_object()
        serializer = LeadStageSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        new_stage = serializer.validated_data["stage"]
        current_stage = lead.stage

        if new_stage == current_stage:
            return Response(
                {"detail": "Lead is already in this stage."},
                status=status.HTTP_200_OK,
            )

        # Determine which transition method to call
        transition_map = {
            StageChoices.WON: "mark_won",
            StageChoices.LOST: "mark_lost",
        }

        method_name = transition_map.get(new_stage)

        if method_name:
            # Terminal state transition (won/lost)
            method = getattr(lead, method_name, None)
            if method is None:
                raise ValidationError(
                    f"Cannot transition to '{new_stage}' from '{current_stage}'."
                )
            try:
                method()
            except Exception as exc:
                raise ValidationError(
                    f"Transition to '{new_stage}' failed: {exc}"
                ) from exc
        else:
            # Forward pipeline transition
            try:
                lead.advance_stage()
            except Exception as exc:
                raise ValidationError(
                    f"Cannot advance from '{current_stage}' to '{new_stage}'. "
                    f"Allowed transitions: forward to next stage, or mark as won/lost."
                ) from exc

        lead.save(update_fields=["stage", "updated_at"])

        return Response(
            {
                "id": str(lead.id),
                "stage": lead.stage,
                "stage_display": lead.get_stage_display(),
            },
            status=status.HTTP_200_OK,
        )

    # -----------------------------------------------------------------------
    # Follow-ups nested endpoint
    # -----------------------------------------------------------------------

    @action(detail=True, methods=["get", "post"], url_path="followups")
    def followups(self, request, pk=None):
        """GET/POST /api/v1/leads/{id}/followups/"""

        lead = self.get_object()

        if request.method == "GET":
            followups = lead.followups.select_related("created_by").all()
            page = self.paginate_queryset(followups)
            if page is not None:
                serializer = FollowUpSerializer(page, many=True)
                return self.get_paginated_response(serializer.data)
            serializer = FollowUpSerializer(followups, many=True)
            return Response(serializer.data)

        elif request.method == "POST":
            serializer = FollowUpCreateSerializer(data=request.data)
            serializer.is_valid(raise_exception=True)
            serializer.save(lead=lead, created_by=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)

    # -----------------------------------------------------------------------
    # Stats endpoint (for dashboard/Kanban)
    # -----------------------------------------------------------------------

    @action(detail=False, methods=["get"], url_path="stats")
    def stats(self, request):
        """GET /api/v1/leads/stats/

        Returns lead count grouped by stage for the current user's data scope.
        """
        qs = self.get_queryset()
        stats_data = (
            qs.values("stage")
            .order_by("stage")
            .annotate(count=models.Count("id"))
        )
        return Response(list(stats_data))
