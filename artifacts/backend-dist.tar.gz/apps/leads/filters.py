"""
Django-filter filterset for Lead model.
"""

import django_filters
from django_filters import rest_framework as filters
from apps.leads.models import Lead, StageChoices


class LeadFilter(filters.FilterSet):
    """Filter set for the Lead list endpoint."""

    search = filters.CharFilter(
        method="filter_search",
        help_text="Search by title or customer name",
    )
    stage = filters.ChoiceFilter(
        choices=StageChoices.choices,
        null_label="All",
        empty_label="All",
    )
    assigned_to = django_filters.UUIDFilter(field_name="assigned_to_id")
    customer = django_filters.UUIDFilter(field_name="customer_id")
    expected_close_after = filters.DateFilter(field_name="expected_close_date", lookup_expr="gte")
    expected_close_before = filters.DateFilter(field_name="expected_close_date", lookup_expr="lte")
    created_after = filters.DateTimeFilter(field_name="created_at", lookup_expr="gte")
    created_before = filters.DateTimeFilter(field_name="created_at", lookup_expr="lte")

    class Meta:
        model = Lead
        fields = (
            "stage",
            "assigned_to",
            "customer",
            "search",
            "expected_close_after",
            "expected_close_before",
            "created_after",
            "created_before",
        )

    def filter_search(self, queryset, name, value):
        """Search across title and customer name."""
        if not value:
            return queryset
        lookup = (
            django_filters.Q(title__icontains=value)
            | django_filters.Q(customer__name__icontains=value)
        )
        return queryset.filter(lookup)
