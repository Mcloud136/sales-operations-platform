"""
Serializers for Lead and FollowUp models.
"""

from rest_framework import serializers
from apps.leads.models import Lead, FollowUp, StageChoices, FollowUpTypeChoices


class FollowUpSerializer(serializers.ModelSerializer):
    """Serializer for FollowUp records."""

    created_by_name = serializers.CharField(
        source="created_by.name", read_only=True, default=""
    )

    class Meta:
        model = FollowUp
        fields = (
            "id",
            "lead",
            "type",
            "content",
            "created_by",
            "created_by_name",
            "created_at",
        )
        read_only_fields = ("id", "created_by_name", "created_at")

    def validate_content(self, value):
        if not value or not value.strip():
            raise serializers.ValidationError("Follow-up content cannot be empty.")
        return value.strip()


class FollowUpCreateSerializer(FollowUpSerializer):
    """Serializer for creating follow-ups -- auto-sets created_by from request."""

    class Meta(FollowUpSerializer.Meta):
        read_only_fields = ("id", "created_by", "created_by_name", "created_at")


class LeadListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for lead list views."""

    customer_name = serializers.CharField(
        source="customer.name", read_only=True
    )
    assigned_to_name = serializers.CharField(
        source="assigned_to.name", read_only=True, default=""
    )
    stage_display = serializers.CharField(
        source="get_stage_display", read_only=True
    )
    followup_count = serializers.IntegerField(read_only=True, default=0)

    class Meta:
        model = Lead
        fields = (
            "id",
            "customer",
            "customer_name",
            "title",
            "stage",
            "stage_display",
            "estimated_amount",
            "probability",
            "expected_close_date",
            "assigned_to",
            "assigned_to_name",
            "followup_count",
            "created_at",
            "updated_at",
        )
        read_only_fields = ("id", "created_at", "updated_at")


class LeadDetailSerializer(LeadListSerializer):
    """Full serializer for lead detail views."""

    followups = FollowUpSerializer(many=True, read_only=True)

    class Meta(LeadListSerializer.Meta):
        fields = LeadListSerializer.Meta.fields + (
            "description",
            "followups",
        )


class LeadCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating new leads."""

    class Meta:
        model = Lead
        fields = (
            "customer",
            "title",
            "stage",
            "estimated_amount",
            "probability",
            "expected_close_date",
            "assigned_to",
            "description",
        )

    def validate_probability(self, value):
        if value is not None and (value < 0 or value > 100):
            raise serializers.ValidationError("Probability must be between 0 and 100.")
        return value

    def validate_title(self, value):
        if not value or not value.strip():
            raise serializers.ValidationError("Lead title cannot be empty.")
        return value.strip()


class LeadUpdateSerializer(LeadCreateSerializer):
    """Serializer for updating existing leads. All fields optional."""

    class Meta(LeadCreateSerializer.Meta):
        extra_kwargs = {
            "customer": {"required": False},
            "title": {"required": False, "allow_blank": False},
        }


class LeadStageSerializer(serializers.Serializer):
    """Serializer for PATCH /leads/{id}/stage/ endpoint."""

    stage = serializers.ChoiceField(choices=StageChoices.choices)
