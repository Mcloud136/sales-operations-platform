from django.contrib import admin
from apps.leads.models import Lead, FollowUp


@admin.register(Lead)
class LeadAdmin(admin.ModelAdmin):
    """Django Admin for Lead model."""

    list_display = (
        "title",
        "customer",
        "stage",
        "estimated_amount",
        "probability",
        "assigned_to",
        "expected_close_date",
        "is_deleted",
        "created_at",
    )
    list_filter = ("stage", "assigned_to", "is_deleted")
    search_fields = ("title", "customer__name")
    readonly_fields = ("id", "created_at", "updated_at", "deleted_at")
    date_hierarchy = "created_at"


@admin.register(FollowUp)
class FollowUpAdmin(admin.ModelAdmin):
    """Django Admin for FollowUp model."""

    list_display = (
        "lead",
        "type",
        "content_preview",
        "created_by",
        "created_at",
    )
    list_filter = ("type",)
    search_fields = ("content", "lead__title")
    readonly_fields = ("id", "created_at", "updated_at")

    @admin.display(description="Content")
    def content_preview(self, obj):
        return obj.content[:80] + ("..." if len(obj.content) > 80 else "")
