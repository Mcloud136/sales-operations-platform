import django_filters
from django_filters import rest_framework as filters

from apps.contracts.models import Contract


class ContractFilter(filters.FilterSet):
    """Filters for the ContractViewSet."""

    status = filters.CharFilter(field_name='status', lookup_expr='exact')
    customer = filters.UUIDFilter(field_name='customer__id', lookup_expr='exact')
    customer_name = filters.CharFilter(
        field_name='customer__name', lookup_expr='icontains',
    )
    assigned_to = filters.UUIDFilter(
        field_name='assigned_to__id', lookup_expr='exact',
    )
    date_from = filters.DateFilter(
        field_name='start_date', lookup_expr='gte',
    )
    date_to = filters.DateFilter(
        field_name='end_date', lookup_expr='lte',
    )
    amount_min = filters.NumberFilter(
        field_name='amount', lookup_expr='gte',
    )
    amount_max = filters.NumberFilter(
        field_name='amount', lookup_expr='lte',
    )
    search = filters.CharFilter(
        method='filter_search',
    )
    expiring_soon = filters.NumberFilter(
        method='filter_expiring_soon',
        help_text='Filter contracts expiring within N days',
    )

    class Meta:
        model = Contract
        fields = [
            'status', 'customer', 'assigned_to',
        ]

    def filter_search(self, queryset, name, value):
        """Search by contract number, title, or customer name."""
        from django.db import models as django_models
        if not value:
            return queryset
        return queryset.filter(
            django_models.Q(contract_no__icontains=value)
            | django_models.Q(title__icontains=value)
            | django_models.Q(customer__name__icontains=value)
        )

    def filter_expiring_soon(self, queryset, name, value):
        """Filter contracts expiring within N days."""
        from django.utils import timezone
        from django.db import models as django_models
        from django.db.models import F, Value
        from django.db.models.functions import Cast, DateField

        today = timezone.now().date()
        return queryset.annotate(
            days_until_expiry=ExpressionWrapper(
                F('end_date') - Value(today, output_field=DateField()),
                output_field=django_models.DurationField(),
            ),
        ).filter(days_until_expiry__lte=Value(value, output_field=django_models.DurationField()))


# Import at module level to avoid circular imports in filter methods
from django.db import models as django_models
from django.db.models import ExpressionWrapper, Value
