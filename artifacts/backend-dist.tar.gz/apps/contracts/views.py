from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from rest_framework.filters import SearchFilter, OrderingFilter

from apps.common.permissions import IsRoleAllowed
from apps.common.pagination import CursorPagination
from apps.contracts.filters import ContractFilter
from apps.contracts.models import Contract
from apps.contracts.serializers import (
    ContractCreateUpdateSerializer,
    ContractDetailSerializer,
    ContractListSerializer,
    SubmitApprovalSerializer,
)


class ContractViewSet(
    mixins.CreateModelMixin,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.UpdateModelMixin,
    mixins.DestroyModelMixin,
    viewsets.GenericViewSet,
):
    """
    Contract CRUD + approval submission.

    Actions:
    - list: List contracts (filtered by data isolation)
    - retrieve: Get contract detail with approval status
    - create: Create a new contract (auto-generates contract_no)
    - update/partial_update: Update contract fields
    - destroy: Soft-delete contract
    - submit_approval: Submit contract for approval workflow
    """

    queryset = Contract.objects.with_expiry_warning().select_related(
        'customer', 'assigned_to', 'related_bid',
    )
    filter_backends = [DjangoFilterBackend, SearchFilter, OrderingFilter]
    filterset_class = ContractFilter
    search_fields = ['contract_no', 'title', 'customer__name']
    ordering_fields = [
        'created_at', 'amount', 'start_date', 'end_date', 'status',
    ]
    ordering = ['-created_at']
    pagination_class = CursorPagination

    def get_serializer_class(self):
        if self.action == 'list':
            return ContractListSerializer
        if self.action in ('create', 'update', 'partial_update'):
            return ContractCreateUpdateSerializer
        if self.action == 'submit_approval':
            return SubmitApprovalSerializer
        return ContractDetailSerializer

    def get_permissions(self):
        if self.action in ('create', 'update', 'partial_update', 'destroy'):
            return [IsAuthenticated(), IsRoleAllowed(['system_admin', 'sales_rep', 'admin_staff'])]
        return [IsAuthenticated()]

    def perform_create(self, serializer):
        """Create contract with auto-generated contract_no."""
        contract = serializer.save()
        # contract_no is auto-generated in the model's save() method
        return contract

    @action(detail=True, methods=['post'], url_path='submit-approval')
    def submit_approval(self, request, pk=None):
        """
        Submit a draft contract for approval.

        Creates an ApprovalInstance via WorkflowEngineService,
        updates contract status to 'in_approval'.
        """
        contract = self.get_object()

        if contract.status != Contract.STATUS_DRAFT:
            return Response(
                {
                    'error': (
                        f'Only draft contracts can be submitted for approval. '
                        f'Current status: {contract.get_status_display()}'
                    )
                },
                status=status.HTTP_400_BAD_REQUEST,
            )

        from apps.approvals.services import WorkflowEngineService

        engine = WorkflowEngineService()
        try:
            approval_instance = engine.instantiate_workflow(
                obj=contract,
                initiated_by=request.user,
                workflow_type='contract_approval',
            )
            contract.status = Contract.STATUS_IN_APPROVAL
            contract.save(update_fields=['status', 'updated_at'])

            from apps.approvals.serializers import ApprovalInstanceSerializer
            return Response(
                {
                    'detail': 'Contract submitted for approval successfully.',
                    'approval_instance': ApprovalInstanceSerializer(
                        approval_instance,
                    ).data,
                },
                status=status.HTTP_201_CREATED,
            )
        except Exception as e:
            return Response(
                {'error': f'Failed to start approval workflow: {str(e)}'},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR,
            )
