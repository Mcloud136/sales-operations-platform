from decimal import Decimal

from django.db import models
from django.db.models import F, ExpressionWrapper, Value
from django.db.models.functions import ExtractYear
from simple_history.models import HistoricalRecords
from uuid7 import uuid7

from apps.common.models import SoftDeleteModel, DataIsolationManager


class ContractManager(DataIsolationManager):
    """Manager for Contract with data isolation and contract number generation."""

    def with_expiry_warning(self):
        """Annotate queryset with days_until_expiry for active contracts."""
        from django.db.models.functions import Cast
        from django.db.models import DateField
        from django.utils import timezone

        today = timezone.now().date()
        return self.annotate(
            days_until_expiry=ExpressionWrapper(
                F('end_date') - Value(today, output_field=DateField()),
                output_field=models.DurationField(),
            ),
        )


class Contract(SoftDeleteModel):
    """Contract model with soft delete, data isolation, and auto-generated number."""

    _isolation_field = 'assigned_to'
    objects = ContractManager()

    STATUS_DRAFT = 'draft'
    STATUS_IN_APPROVAL = 'in_approval'
    STATUS_SIGNED = 'signed'
    STATUS_ACTIVE = 'active'
    STATUS_COMPLETED = 'completed'
    STATUS_TERMINATED = 'terminated'

    STATUS_CHOICES = [
        (STATUS_DRAFT, 'Draft'),
        (STATUS_IN_APPROVAL, 'In Approval'),
        (STATUS_SIGNED, 'Signed'),
        (STATUS_ACTIVE, 'Active'),
        (STATUS_COMPLETED, 'Completed'),
        (STATUS_TERMINATED, 'Terminated'),
    ]

    id = models.UUIDField(primary_key=True, default=uuid7, editable=False)
    contract_no = models.CharField(
        max_length=50,
        unique=False,
        db_index=True,
        help_text='Auto-generated: HT-YYYY-NNN',
    )
    customer = models.ForeignKey(
        'customers.Customer',
        on_delete=models.PROTECT,
        related_name='contracts',
        db_index=True,
    )
    title = models.CharField(max_length=500)
    amount = models.DecimalField(
        max_digits=14,
        decimal_places=2,
        default=Decimal('0'),
    )
    sign_date = models.DateField(blank=True, null=True)
    start_date = models.DateField()
    end_date = models.DateField()
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_DRAFT,
        db_index=True,
    )
    related_bid = models.ForeignKey(
        'bids.BidProject',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='contracts',
    )
    assigned_to = models.ForeignKey(
        'users.User',
        on_delete=models.PROTECT,
        related_name='assigned_contracts',
    )
    notes = models.TextField(blank=True, default='')

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    history = HistoricalRecords()

    class Meta:
        ordering = ['-created_at']
        constraints = [
            models.UniqueConstraint(
                fields=['contract_no'],
                condition=models.Q(is_deleted=False),
                name='unique_active_contract_no',
            ),
        ]
        verbose_name = 'Contract'

    def __str__(self) -> str:
        return f"{self.contract_no} - {self.title}"

    def save(self, *args, **kwargs):
        """Auto-generate contract_no on first save if not set."""
        if not self.contract_no:
            self.contract_no = self.generate_contract_no()
        super().save(*args, **kwargs)

    @classmethod
    def generate_contract_no(cls) -> str:
        """
        Generate contract number in format HT-YYYY-NNN.

        NNN is a sequential number per year, padded to 3 digits.
        Thread-safe via database-level query inside atomic transaction.
        """
        from django.db import transaction
        from django.utils import timezone

        with transaction.atomic():
            year = timezone.now().year
            prefix = f'HT-{year}-'

            # Find the highest existing number for this year (including soft-deleted)
            last_contract = (
                cls.all_objects.filter(contract_no__startswith=prefix)
                .order_by('-contract_no')
                .first()
            )

            if last_contract and last_contract.contract_no.startswith(prefix):
                # Extract the NNN part
                num_part = last_contract.contract_no[len(prefix):]
                try:
                    next_num = int(num_part) + 1
                except ValueError:
                    next_num = 1
            else:
                next_num = 1

            return f'{prefix}{next_num:03d}'
