from rest_framework import serializers

from apps.contracts.models import Contract


class ContractListSerializer(serializers.ModelSerializer):
    """Compact serializer for list views."""

    customer_name = serializers.CharField(
        source='customer.name', read_only=True,
    )
    assigned_to_name = serializers.CharField(
        source='assigned_to.name', read_only=True,
    )
    days_until_expiry = serializers.IntegerField(
        read_only=True,
        default=None,
    )
    related_bid_title = serializers.CharField(
        source='related_bid.title', read_only=True, default=None,
    )

    class Meta:
        model = Contract
        fields = [
            'id', 'contract_no', 'title', 'customer', 'customer_name',
            'amount', 'sign_date', 'start_date', 'end_date', 'status',
            'related_bid', 'related_bid_title', 'assigned_to',
            'assigned_to_name', 'days_until_expiry', 'created_at',
        ]
        read_only_fields = [
            'id', 'contract_no', 'created_at', 'days_until_expiry',
        ]


class ContractDetailSerializer(ContractListSerializer):
    """Full serializer for detail views with approval instance info."""

    notes = serializers.CharField(read_only=True)

    class Meta(ContractListSerializer.Meta):
        fields = ContractListSerializer.Meta.fields + ['notes', 'updated_at']


class ContractCreateUpdateSerializer(serializers.ModelSerializer):
    """Serializer for creating and updating contracts."""

    class Meta:
        model = Contract
        fields = [
            'title', 'customer', 'amount', 'sign_date', 'start_date',
            'end_date', 'status', 'related_bid', 'assigned_to', 'notes',
        ]

    def validate(self, attrs):
        """Validate date ordering."""
        start_date = attrs.get('start_date')
        end_date = attrs.get('end_date')

        if start_date and end_date and end_date <= start_date:
            raise serializers.ValidationError(
                "End date must be after start date."
            )

        if start_date and end_date and attrs.get('sign_date'):
            sign_date = attrs['sign_date']
            if sign_date > end_date:
                raise serializers.ValidationError(
                    "Sign date cannot be after end date."
                )

        return attrs


class SubmitApprovalSerializer(serializers.Serializer):
    """Serializer for the submit_approval action (no fields required)."""

    pass
