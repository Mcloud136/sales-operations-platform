from django.contrib import admin

from apps.contracts.models import Contract


@admin.register(Contract)
class ContractAdmin(admin.ModelAdmin):
    list_display = [
        'contract_no', 'title', 'customer', 'amount',
        'status', 'start_date', 'end_date', 'assigned_to',
    ]
    list_filter = ['status', 'assigned_to']
    search_fields = ['contract_no', 'title', 'customer__name']
    readonly_fields = ['id', 'contract_no', 'created_at', 'updated_at']
    date_hierarchy = 'created_at'
