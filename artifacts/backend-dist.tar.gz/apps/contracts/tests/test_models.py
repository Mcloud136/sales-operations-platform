from datetime import date, timedelta
from decimal import Decimal
from django.test import TestCase

from apps.contracts.models import Contract
from apps.customers.tests.factories import CustomerFactory
from apps.users.tests.factories import UserFactory


class ContractModelTest(TestCase):
    """Tests for the Contract model."""

    def setUp(self):
        self.customer = CustomerFactory()
        self.user = UserFactory(role='sales_rep')

    def test_create_contract_auto_generates_number(self):
        contract = Contract.objects.create(
            customer=self.customer,
            title='Test Contract',
            amount=Decimal('100000'),
            start_date=date(2026, 1, 1),
            end_date=date(2027, 1, 1),
            assigned_to=self.user,
        )
        self.assertTrue(contract.contract_no.startswith('HT-'))
        self.assertEqual(len(contract.contract_no), 12)  # HT-YYYY-NNN

    def test_contract_number_sequential(self):
        today = date.today()
        c1 = Contract.objects.create(
            customer=self.customer,
            title='Contract 1',
            amount=Decimal('100000'),
            start_date=today,
            end_date=today + timedelta(days=365),
            assigned_to=self.user,
        )
        c2 = Contract.objects.create(
            customer=self.customer,
            title='Contract 2',
            amount=Decimal('200000'),
            start_date=today,
            end_date=today + timedelta(days=365),
            assigned_to=self.user,
        )
        year = today.year
        self.assertEqual(c1.contract_no, f'HT-{year}-001')
        self.assertEqual(c2.contract_no, f'HT-{year}-002')

    def test_contract_number_includes_year(self):
        contract = Contract.objects.create(
            customer=self.customer,
            title='Year Test',
            amount=Decimal('50000'),
            start_date=date(2026, 6, 1),
            end_date=date(2027, 6, 1),
            assigned_to=self.user,
        )
        self.assertIn('2026', contract.contract_no)

    def test_default_status_is_draft(self):
        contract = Contract.objects.create(
            customer=self.customer,
            title='Draft Contract',
            amount=Decimal('50000'),
            start_date=date(2026, 1, 1),
            end_date=date(2027, 1, 1),
            assigned_to=self.user,
        )
        self.assertEqual(contract.status, Contract.STATUS_DRAFT)

    def test_soft_delete(self):
        contract = Contract.objects.create(
            customer=self.customer,
            title='To Delete',
            amount=Decimal('100000'),
            start_date=date(2026, 1, 1),
            end_date=date(2027, 1, 1),
            assigned_to=self.user,
        )
        contract.soft_delete()

        self.assertTrue(contract.is_deleted)
        self.assertIsNotNone(contract.deleted_at)
        self.assertNotIn(contract, list(Contract.objects.all()))

    def test_partial_unique_contract_no(self):
        """Soft-deleted contract numbers should not block reuse."""
        today = date.today()
        c1 = Contract.objects.create(
            customer=self.customer,
            title='Contract Alpha',
            amount=Decimal('100000'),
            start_date=today,
            end_date=today + timedelta(days=365),
            assigned_to=self.user,
        )
        original_no = c1.contract_no
        c1.soft_delete()

        # Create a new contract -- should not fail due to the soft-deleted one
        c2 = Contract.objects.create(
            customer=self.customer,
            title='Contract Beta',
            amount=Decimal('200000'),
            start_date=today,
            end_date=today + timedelta(days=365),
            assigned_to=self.user,
        )
        # The new contract gets a new sequential number, not a duplicate
        self.assertNotEqual(c2.contract_no, original_no)
        # And creating another with the same number should fail for active contracts
        with self.assertRaises(Exception):
            Contract.objects.create(
                customer=self.customer,
                title='Duplicate Number',
                amount=Decimal('300000'),
                start_date=today,
                end_date=today + timedelta(days=365),
                assigned_to=self.user,
                contract_no=c2.contract_no,
            )

    def test_str_representation(self):
        contract = Contract.objects.create(
            customer=self.customer,
            title='String Test Contract',
            amount=Decimal('100000'),
            start_date=date(2026, 1, 1),
            end_date=date(2027, 1, 1),
            assigned_to=self.user,
        )
        self.assertIn(contract.contract_no, str(contract))
        self.assertIn('String Test Contract', str(contract))


class ContractExpiryAnnotationTest(TestCase):
    """Tests for the days_until_expiry annotation."""

    def setUp(self):
        self.customer = CustomerFactory()
        self.user = UserFactory(role='sales_rep')

    def test_expiry_warning_annotation(self):
        today = date.today()
        contract = Contract.objects.create(
            customer=self.customer,
            title='Expiring Contract',
            amount=Decimal('100000'),
            start_date=today - timedelta(days=300),
            end_date=today + timedelta(days=30),
            assigned_to=self.user,
        )
        qs = Contract.objects.with_expiry_warning()
        annotated = qs.get(id=contract.id)
        # Should be approximately 30 days
        self.assertIsNotNone(annotated.days_until_expiry)
        self.assertGreaterEqual(annotated.days_until_expiry.days, 29)
        self.assertLessEqual(annotated.days_until_expiry.days, 31)
