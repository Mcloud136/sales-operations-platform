from datetime import date, timedelta
from decimal import Decimal
from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework_simplejwt.tokens import AccessToken

from apps.contracts.models import Contract
from apps.customers.tests.factories import CustomerFactory
from apps.users.tests.factories import UserFactory


class ContractViewSetTest(TestCase):
    """Tests for the ContractViewSet CRUD + approval submission."""

    def setUp(self):
        self.client = APIClient()
        self.customer = CustomerFactory()
        self.user = UserFactory(role='sales_rep')
        self.other_user = UserFactory(role='sales_rep')

    def _auth_as(self, user):
        token = AccessToken.for_user(user)
        self.client.credentials(HTTP_AUTHORIZATION=f'Bearer {token}')

    def _create_contract_data(self):
        today = date.today()
        return {
            'title': 'Test Contract',
            'customer': str(self.customer.id),
            'amount': '100000.00',
            'start_date': str(today),
            'end_date': str(today + timedelta(days=365)),
            'assigned_to': str(self.user.id),
        }

    def test_create_contract_auto_number(self):
        self._auth_as(self.user)
        data = self._create_contract_data()

        response = self.client.post('/api/v1/contracts/', data, format='json')
        self.assertEqual(response.status_code, 201)
        self.assertIn('contract_no', response.data)
        self.assertTrue(response.data['contract_no'].startswith('HT-'))

    def test_list_contracts(self):
        self._auth_as(self.user)
        Contract.objects.create(
            customer=self.customer,
            title='List Test',
            amount=Decimal('100000'),
            start_date=date.today(),
            end_date=date.today() + timedelta(days=365),
            assigned_to=self.user,
        )

        response = self.client.get('/api/v1/contracts/')
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(len(response.data['results']), 1)

    def test_retrieve_contract_detail(self):
        self._auth_as(self.user)
        contract = Contract.objects.create(
            customer=self.customer,
            title='Detail Test',
            amount=Decimal('100000'),
            start_date=date.today(),
            end_date=date.today() + timedelta(days=365),
            assigned_to=self.user,
        )

        response = self.client.get(f'/api/v1/contracts/{contract.id}/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['id'], str(contract.id))

    def test_update_contract(self):
        self._auth_as(self.user)
        contract = Contract.objects.create(
            customer=self.customer,
            title='Before Update',
            amount=Decimal('100000'),
            start_date=date.today(),
            end_date=date.today() + timedelta(days=365),
            assigned_to=self.user,
        )

        response = self.client.patch(
            f'/api/v1/contracts/{contract.id}/',
            {'title': 'After Update'},
            format='json',
        )
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['title'], 'After Update')

    def test_soft_delete_contract(self):
        self._auth_as(self.user)
        contract = Contract.objects.create(
            customer=self.customer,
            title='To Delete',
            amount=Decimal('100000'),
            start_date=date.today(),
            end_date=date.today() + timedelta(days=365),
            assigned_to=self.user,
        )

        response = self.client.delete(f'/api/v1/contracts/{contract.id}/')
        self.assertEqual(response.status_code, 204)

        contract.refresh_from_db()
        self.assertTrue(contract.is_deleted)

        # Should not appear in list
        response = self.client.get('/api/v1/contracts/')
        self.assertEqual(len(response.data['results']), 0)

    def test_submit_approval_on_draft(self):
        """Submitting a draft contract for approval should succeed if workflow exists."""
        from apps.approvals.models import ApprovalWorkflowDefinition, ApprovalStepDefinition
        from apps.users.models import User

        self._auth_as(self.user)

        # Create a default workflow definition
        manager = UserFactory(role='sales_manager')
        definition = ApprovalWorkflowDefinition.objects.create(
            name='Default Contract Approval',
            workflow_type='contract_approval',
            is_default=True,
        )
        ApprovalStepDefinition.objects.create(
            workflow_def=definition,
            step_order=1,
            step_name='Manager Review',
            assignee_role='sales_manager',
        )

        contract = Contract.objects.create(
            customer=self.customer,
            title='Submit Test',
            amount=Decimal('100000'),
            start_date=date.today(),
            end_date=date.today() + timedelta(days=365),
            assigned_to=self.user,
        )

        response = self.client.post(
            f'/api/v1/contracts/{contract.id}/submit-approval/',
        )
        self.assertEqual(response.status_code, 201)
        self.assertIn('approval_instance', response.data)

        contract.refresh_from_db()
        self.assertEqual(contract.status, Contract.STATUS_IN_APPROVAL)

    def test_submit_approval_on_non_draft_fails(self):
        self._auth_as(self.user)
        contract = Contract.objects.create(
            customer=self.customer,
            title='Already Approved',
            amount=Decimal('100000'),
            start_date=date.today(),
            end_date=date.today() + timedelta(days=365),
            assigned_to=self.user,
            status=Contract.STATUS_SIGNED,
        )

        response = self.client.post(
            f'/api/v1/contracts/{contract.id}/submit-approval/',
        )
        self.assertEqual(response.status_code, 400)

    def test_filter_by_status(self):
        self._auth_as(self.user)
        today = date.today()
        Contract.objects.create(
            customer=self.customer,
            title='Draft One',
            amount=Decimal('50000'),
            start_date=today,
            end_date=today + timedelta(days=365),
            assigned_to=self.user,
            status=Contract.STATUS_DRAFT,
        )
        Contract.objects.create(
            customer=self.customer,
            title='Active One',
            amount=Decimal('200000'),
            start_date=today,
            end_date=today + timedelta(days=365),
            assigned_to=self.user,
            status=Contract.STATUS_ACTIVE,
        )

        response = self.client.get(
            '/api/v1/contracts/', {'status': 'active'},
        )
        results = response.data['results']
        self.assertTrue(all(r['status'] == 'active' for r in results))

    def test_unauthenticated_access_fails(self):
        response = self.client.get('/api/v1/contracts/')
        self.assertEqual(response.status_code, 401)
