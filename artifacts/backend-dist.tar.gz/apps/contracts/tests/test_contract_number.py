from datetime import date, timedelta
from decimal import Decimal
from django.test import TestCase

from apps.contracts.models import Contract
from apps.customers.tests.factories import CustomerFactory
from apps.users.tests.factories import UserFactory


class ContractNumberGenerationTest(TestCase):
    """Tests for auto-generation of contract numbers (HT-YYYY-NNN)."""

    def setUp(self):
        self.customer = CustomerFactory()
        self.user = UserFactory(role='sales_rep')

    def test_first_contract_of_year(self):
        """First contract of the year should be HT-YYYY-001."""
        contract = Contract.objects.create(
            customer=self.customer,
            title='First of Year',
            amount=Decimal('100000'),
            start_date=date.today(),
            end_date=date.today() + timedelta(days=365),
            assigned_to=self.user,
        )
        year = date.today().year
        self.assertEqual(contract.contract_no, f'HT-{year}-001')

    def test_sequential_numbers(self):
        """Each subsequent contract gets the next number."""
        today = date.today()
        contracts = []
        for i in range(5):
            c = Contract.objects.create(
                customer=self.customer,
                title=f'Contract {i}',
                amount=Decimal('100000'),
                start_date=today,
                end_date=today + timedelta(days=365),
                assigned_to=self.user,
            )
            contracts.append(c)

        year = date.today().year
        for i, c in enumerate(contracts):
            expected = f'HT-{year}-{i+1:03d}'
            self.assertEqual(c.contract_no, expected)

    def test_soft_delete_then_new_contract(self):
        """After soft-delete, new contract gets a new sequential number (not duplicate)."""
        today = date.today()
        c1 = Contract.objects.create(
            customer=self.customer,
            title='Before Delete',
            amount=Decimal('100000'),
            start_date=today,
            end_date=today + timedelta(days=365),
            assigned_to=self.user,
        )
        c1.soft_delete()

        c2 = Contract.objects.create(
            customer=self.customer,
            title='After Delete',
            amount=Decimal('200000'),
            start_date=today,
            end_date=today + timedelta(days=365),
            assigned_to=self.user,
        )
        self.assertNotEqual(c2.contract_no, c1.contract_no)

    def test_number_padded_to_three_digits(self):
        """Numbers are zero-padded to 3 digits."""
        contract = Contract.objects.create(
            customer=self.customer,
            title='Padding Test',
            amount=Decimal('100000'),
            start_date=date.today(),
            end_date=date.today() + timedelta(days=365),
            assigned_to=self.user,
        )
        parts = contract.contract_no.split('-')
        self.assertEqual(len(parts[2]), 3)

    def test_format_is_HT_YYYY_NNN(self):
        """Contract number format is exactly HT-YYYY-NNN."""
        contract = Contract.objects.create(
            customer=self.customer,
            title='Format Test',
            amount=Decimal('100000'),
            start_date=date.today(),
            end_date=date.today() + timedelta(days=365),
            assigned_to=self.user,
        )
        import re
        self.assertRegex(
            contract.contract_no,
            r'^HT-\d{4}-\d{3}$',
        )
