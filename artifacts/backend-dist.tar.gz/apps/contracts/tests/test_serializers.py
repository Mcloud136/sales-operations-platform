from datetime import date, timedelta
from decimal import Decimal
from django.test import TestCase

from apps.contracts.serializers import ContractCreateUpdateSerializer
from apps.customers.tests.factories import CustomerFactory
from apps.users.tests.factories import UserFactory


class ContractSerializerTest(TestCase):
    """Tests for ContractCreateUpdateSerializer validation."""

    def setUp(self):
        self.customer = CustomerFactory()
        self.user = UserFactory(role='sales_rep')

    def test_valid_contract_data(self):
        data = {
            'title': 'Valid Contract',
            'customer': str(self.customer.id),
            'amount': '100000.00',
            'start_date': '2026-01-01',
            'end_date': '2027-01-01',
            'assigned_to': str(self.user.id),
        }
        serializer = ContractCreateUpdateSerializer(data=data)
        self.assertTrue(serializer.is_valid())

    def test_end_date_before_start_date_fails(self):
        data = {
            'title': 'Invalid Dates',
            'customer': str(self.customer.id),
            'amount': '100000.00',
            'start_date': '2027-01-01',
            'end_date': '2026-01-01',
            'assigned_to': str(self.user.id),
        }
        serializer = ContractCreateUpdateSerializer(data=data)
        self.assertFalse(serializer.is_valid())
        self.assertIn('non_field_errors', serializer.errors)

    def test_sign_date_after_end_date_fails(self):
        data = {
            'title': 'Bad Sign Date',
            'customer': str(self.customer.id),
            'amount': '100000.00',
            'start_date': '2026-01-01',
            'end_date': '2026-06-01',
            'sign_date': '2026-12-01',
            'assigned_to': str(self.user.id),
        }
        serializer = ContractCreateUpdateSerializer(data=data)
        self.assertFalse(serializer.is_valid())
        self.assertIn('non_field_errors', serializer.errors)
