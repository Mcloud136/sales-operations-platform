from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from apps.users.models import User


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    """Django Admin integration for custom User model."""

    list_display = ("username", "email", "name", "role", "is_active", "is_staff", "created_at")
    list_filter = ("role", "is_active", "is_staff", "department")
    search_fields = ("username", "email", "name")
    ordering = ("username",)

    fieldsets = BaseUserAdmin.fieldsets + (
        ("Extra Info", {"fields": ("name", "phone", "role", "department")}),
    )

    add_fieldsets = BaseUserAdmin.add_fieldsets + (
        ("Extra Info", {"fields": ("name", "phone", "role")}),
    )

    readonly_fields = ("id", "created_at", "updated_at")
