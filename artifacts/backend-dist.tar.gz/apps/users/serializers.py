from rest_framework import serializers
from apps.users.models import User


class LoginSerializer(serializers.Serializer):
    """Serializer for login request validation."""

    username = serializers.CharField()
    password = serializers.CharField(write_only=True)


class UserSerializer(serializers.ModelSerializer):
    """Serializer for user profile data (excludes password)."""

    class Meta:
        model = User
        fields = (
            "id",
            "username",
            "email",
            "name",
            "phone",
            "role",
            "department",
            "is_active",
            "is_staff",
            "created_at",
            "updated_at",
        )
        read_only_fields = fields
