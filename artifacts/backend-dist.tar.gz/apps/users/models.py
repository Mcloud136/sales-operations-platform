"""
Custom User model with UUIDv7 primary key and role-based access.
"""

from django.contrib.auth.models import AbstractBaseUser, BaseUserManager, PermissionsMixin
from django.db import models

from apps.common.models import UUIDv7ModelMixin, TimestampMixin


class RoleChoices(models.TextChoices):
    SYSTEM_ADMIN = "system_admin", "System Admin"
    SALES_MANAGER = "sales_manager", "Sales Manager"
    SALES_REP = "sales_rep", "Sales Representative"
    ADMIN_STAFF = "admin_staff", "Admin Staff"


class UserManager(BaseUserManager):
    """Custom manager for User model with UUIDv7 and role support."""

    def create_user(self, username, email, role="sales_rep", password=None, **extra_fields):
        """Create and return a regular user."""
        if not username:
            raise ValueError("Users must have a username")
        if not email:
            raise ValueError("Users must have an email address")
        email = self.normalize_email(email)

        user = self.model(
            username=username,
            email=email,
            role=role,
            **extra_fields,
        )
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, username, email, password=None, **extra_fields):
        """Create and return a superuser."""
        extra_fields.setdefault("is_staff", True)
        extra_fields.setdefault("is_superuser", True)
        extra_fields.setdefault("role", "system_admin")

        if extra_fields.get("is_staff") is not True:
            raise ValueError("Superuser must have is_staff=True.")
        if extra_fields.get("is_superuser") is not True:
            raise ValueError("Superuser must have is_superuser=True.")

        return self.create_user(
            username=username,
            email=email,
            password=password,
            **extra_fields,
        )


class User(UUIDv7ModelMixin, TimestampMixin, AbstractBaseUser, PermissionsMixin):
    """Custom User model.

    - UUIDv7 primary key (index-friendly, timestamp-ordered)
    - Role field for business access control
    - Optional department FK (nullable self-referential for org tree)
    """

    username = models.CharField(max_length=150, unique=True)
    email = models.EmailField(unique=True)
    name = models.CharField(max_length=200, blank=True)
    phone = models.CharField(max_length=30, blank=True)
    role = models.CharField(
        max_length=20,
        choices=RoleChoices.choices,
        default=RoleChoices.SALES_REP,
    )
    department = models.ForeignKey(
        "self",
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="department_members",
    )
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    objects = UserManager()

    USERNAME_FIELD = "username"
    REQUIRED_FIELDS = ["email"]

    class Meta:
        db_table = "users_user"
        verbose_name = "User"
        verbose_name_plural = "Users"

    def __str__(self):
        return self.username
