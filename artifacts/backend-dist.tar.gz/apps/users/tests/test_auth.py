import pytest
from rest_framework.test import APIClient


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def user_data():
    return {
        "username": "testuser",
        "password": "testpass123",
    }


@pytest.mark.django_db
def test_login_returns_tokens(api_client, user_data):
    """POST /api/v1/auth/login/ should return access and refresh tokens."""
    from apps.users.models import User

    User.objects.create_user(
        username="testuser",
        email="test@example.com",
        role="sales_rep",
        password="testpass123",
    )

    response = api_client.post("/api/v1/auth/login/", user_data)
    assert response.status_code == 200
    assert "access" in response.data
    assert "refresh" in response.data


@pytest.mark.django_db
def test_login_invalid_credentials(api_client, user_data):
    """POST /api/v1/auth/login/ with wrong password should return 401."""
    from apps.users.models import User

    User.objects.create_user(
        username="testuser",
        email="test@example.com",
        role="sales_rep",
        password="testpass123",
    )

    response = api_client.post(
        "/api/v1/auth/login/",
        {"username": "testuser", "password": "wrongpass"},
    )
    assert response.status_code == 401


@pytest.mark.django_db
def test_login_inactive_user(api_client):
    """Login with an inactive user should return 401."""
    from apps.users.models import User

    user = User.objects.create_user(
        username="inactive",
        email="inactive@example.com",
        role="sales_rep",
        password="testpass123",
    )
    user.is_active = False
    user.save()

    response = api_client.post(
        "/api/v1/auth/login/",
        {"username": "inactive", "password": "testpass123"},
    )
    assert response.status_code == 401


@pytest.mark.django_db
def test_refresh_token(api_client, user_data):
    """POST /api/v1/auth/refresh/ should return a new access token."""
    from apps.users.models import User

    User.objects.create_user(
        username="testuser",
        email="test@example.com",
        role="sales_rep",
        password="testpass123",
    )

    login_resp = api_client.post("/api/v1/auth/login/", user_data)
    refresh_token = login_resp.data["refresh"]

    response = api_client.post("/api/v1/auth/refresh/", {"refresh": refresh_token})
    assert response.status_code == 200
    assert "access" in response.data


@pytest.mark.django_db
def test_me_endpoint_returns_user_profile(api_client, user_data):
    """GET /api/v1/auth/me/ should return current user data when authenticated."""
    from apps.users.models import User

    User.objects.create_user(
        username="testuser",
        email="test@example.com",
        role="sales_rep",
        password="testpass123",
    )

    login_resp = api_client.post("/api/v1/auth/login/", user_data)
    access_token = login_resp.data["access"]

    api_client.credentials(HTTP_AUTHORIZATION=f"Bearer {access_token}")
    response = api_client.get("/api/v1/auth/me/")
    assert response.status_code == 200
    assert response.data["username"] == "testuser"
    assert response.data["role"] == "sales_rep"
    assert "password" not in response.data


@pytest.mark.django_db
def test_me_endpoint_unauthenticated(api_client):
    """GET /api/v1/auth/me/ without token should return 401."""
    response = api_client.get("/api/v1/auth/me/")
    assert response.status_code == 401


@pytest.mark.django_db
def test_me_endpoint_invalid_token(api_client):
    """GET /api/v1/auth/me/ with invalid token should return 401."""
    api_client.credentials(HTTP_AUTHORIZATION="Bearer invalidtoken123")
    response = api_client.get("/api/v1/auth/me/")
    assert response.status_code == 401
