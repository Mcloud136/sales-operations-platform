"""Lightweight UserFactory for tests (no factory_boy dependency)."""

import factory


class UserFactory(factory.django.DjangoModelFactory):
    """Factory for creating User instances in tests."""

    class Meta:
        model = 'users.User'
        django_get_or_create = ('username',)

    username = factory.Sequence(lambda n: f'user{n}')
    email = factory.LazyAttribute(lambda obj: f'{obj.username}@example.com')
    name = factory.LazyAttribute(lambda obj: f'Test {obj.username}')
    role = 'sales_rep'
    password = factory.PostGenerationMethodCall('set_password', 'testpass123')
    is_active = True
