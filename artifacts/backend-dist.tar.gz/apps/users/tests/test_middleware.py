import pytest
from django.test import RequestFactory
from django.contrib.auth.models import AnonymousUser

from config.settings.middleware import IsolationContextMiddleware
from apps.common.models import _isolation_user


@pytest.fixture
def factory():
    return RequestFactory()


@pytest.fixture
def middleware():
    return IsolationContextMiddleware(get_response=lambda request: None)


@pytest.mark.django_db
def test_middleware_sets_isolation_user_for_authenticated_user(middleware, factory):
    """Middleware should set isolation user when request.user is authenticated."""
    from apps.users.models import User

    user = User.objects.create_user(
        username="mwuser",
        email="mw@example.com",
        role="sales_rep",
    )

    request = factory.get("/")
    request.user = user

    middleware(request)

    assert _isolation_user.get() is user


@pytest.mark.django_db
def test_middleware_resets_on_exit(middleware, factory):
    """Middleware should reset isolation user after request processing."""
    from apps.users.models import User

    user = User.objects.create_user(
        username="resetuser",
        email="reset@example.com",
        role="sales_rep",
    )

    request = factory.get("/")
    request.user = user

    middleware(request)

    # After middleware processes, context should be reset
    assert _isolation_user.get() is None


@pytest.mark.django_db
def test_middleware_resets_for_anonymous_user(middleware, factory):
    """Middleware should reset isolation for anonymous users."""
    request = factory.get("/")
    request.user = AnonymousUser()

    middleware(request)

    assert _isolation_user.get() is None
