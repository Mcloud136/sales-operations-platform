import pytest
from django.db import IntegrityError
from apps.users.models import User


@pytest.mark.django_db
def test_create_user_with_required_fields():
    """User should be creatable with username, email, role."""
    user = User.objects.create_user(
        username="jdoe",
        email="jdoe@example.com",
        role="sales_rep",
    )
    assert user.username == "jdoe"
    assert user.email == "jdoe@example.com"
    assert user.role == "sales_rep"
    assert user.is_active is True
    assert user.is_staff is False
    assert user.id is not None  # UUIDv7 assigned


@pytest.mark.django_db
def test_create_superuser():
    """create_superuser should set is_staff=True and is_superuser=True."""
    admin = User.objects.create_superuser(
        username="admin",
        email="admin@example.com",
        password="adminpass123",
    )
    assert admin.is_staff is True
    assert admin.is_superuser is True
    assert admin.role == "system_admin"


@pytest.mark.django_db
def test_user_has_uuidv7_pk():
    """User primary key should be UUIDv7."""
    user = User.objects.create_user(
        username="testuser",
        email="test@example.com",
        role="admin_staff",
    )
    # UUIDv7 starts with 0-7
    assert str(user.id)[0] in "01234567"


@pytest.mark.django_db
def test_user_role_choices():
    """User role must be one of the defined choices."""
    user = User.objects.create_user(
        username="manager1",
        email="manager@example.com",
        role="sales_manager",
    )
    user.full_clean()  # Should not raise
    assert user.role == "sales_manager"


@pytest.mark.django_db
def test_user_string_representation():
    """User __str__ should return the username."""
    user = User.objects.create_user(
        username="displayuser",
        email="display@example.com",
        role="sales_rep",
    )
    assert str(user) == "displayuser"


@pytest.mark.django_db
def test_user_email_normalization():
    """UserManager.create_user should normalize email to lowercase."""
    user = User.objects.create_user(
        username="caps",
        email="CAPS@Example.COM",
        role="sales_rep",
    )
    assert user.email == "caps@example.com"


@pytest.mark.django_db
def test_user_timestamp_fields():
    """User should have created_at and updated_at from TimestampMixin."""
    user = User.objects.create_user(
        username="timeuser",
        email="time@example.com",
        role="sales_rep",
    )
    assert user.created_at is not None
    assert user.updated_at is not None


@pytest.mark.django_db
def test_duplicate_username_raises():
    """Creating two users with the same username should raise IntegrityError."""
    User.objects.create_user(
        username="dupuser",
        email="dup1@example.com",
        role="sales_rep",
    )
    with pytest.raises(IntegrityError):
        User.objects.create_user(
            username="dupuser",
            email="dup2@example.com",
            role="sales_rep",
        )
