"""Celery tasks for user management."""
import logging
from datetime import timedelta

from celery import shared_task
from django.utils import timezone

logger = logging.getLogger(__name__)


@shared_task
def cleanup_expired_tokens():
    """Remove expired outstanding tokens (and their blacklist entries cascade).

    Runs daily to prevent the outstandingtoken table from growing unbounded.
    """
    from rest_framework_simplejwt.token_blacklist.models import OutstandingToken

    cutoff = timezone.now() - timedelta(days=1)
    expired = OutstandingToken.objects.filter(expires_at__lt=cutoff)
    count = expired.count()
    expired.delete()
    logger.info("Cleaned up %d expired JWT tokens", count)
    return count
