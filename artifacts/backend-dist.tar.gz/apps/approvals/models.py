from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django_fsm import FSMField, transition
from simple_history.models import HistoricalRecords
from uuid7 import uuid7


class ApprovalWorkflowDefinition(models.Model):
    """Template defining an approval workflow chain."""

    id = models.UUIDField(primary_key=True, default=uuid7, editable=False)
    name = models.CharField(max_length=200)
    workflow_type = models.CharField(
        max_length=50,
        choices=[
            ('contract_approval', 'Contract Approval'),
            ('bid_review', 'Bid Review'),
        ],
        db_index=True,
    )
    conditions = models.JSONField(
        default=dict,
        blank=True,
        help_text=(
            "JSON conditions for template selection. "
            "Example: {\"amount_threshold\": 1000000, \"op\": \"gte\"}"
        ),
    )
    is_default = models.BooleanField(
        default=False,
        help_text="Fallback template when no conditions match",
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    history = HistoricalRecords()

    class Meta:
        ordering = ['name']
        verbose_name = 'Approval Workflow Definition'

    def __str__(self) -> str:
        return self.name


class ApprovalStepDefinition(models.Model):
    """A single step within a workflow template."""

    id = models.UUIDField(primary_key=True, default=uuid7, editable=False)
    workflow_def = models.ForeignKey(
        ApprovalWorkflowDefinition,
        on_delete=models.CASCADE,
        related_name='step_definitions',
    )
    step_order = models.IntegerField()
    step_name = models.CharField(max_length=200)
    assignee_role = models.CharField(
        max_length=50,
        choices=[
            ('sales_manager', 'Sales Manager'),
            ('legal', 'Legal'),
            ('gm', 'General Manager'),
            ('vp', 'Vice President'),
            ('team_lead', 'Team Lead'),
        ],
    )
    assignee_dynamic = models.CharField(
        max_length=200,
        blank=True,
        null=True,
        help_text=(
            "Dynamic assignment expression resolved at instantiation. "
            "Example: 'object.assigned_to.department_head'"
        ),
    )
    is_conditional = models.BooleanField(default=False)
    condition_expr = models.JSONField(
        blank=True,
        null=True,
        help_text=(
            "JSON condition for this step to be included. "
            "Example: {\"field\": \"amount\", \"op\": \"gt\", \"value\": 1000000}"
        ),
    )
    rejection_target = models.CharField(
        max_length=50,
        choices=[
            ('reject_to_originator', 'Reject to Originator'),
            ('reject_to_previous', 'Reject to Previous Step'),
            ('reject_to_specific_step', 'Reject to Specific Step'),
        ],
        default='reject_to_originator',
    )
    rejection_target_step = models.IntegerField(
        blank=True,
        null=True,
        help_text="Step order to route to when rejection_target is reject_to_specific_step",
    )
    require_all = models.BooleanField(
        default=False,
        help_text="If True, all assignees must approve (countersign)",
    )

    history = HistoricalRecords()

    class Meta:
        ordering = ['workflow_def', 'step_order']
        unique_together = ['workflow_def', 'step_order']
        verbose_name = 'Approval Step Definition'

    def __str__(self) -> str:
        return f"{self.workflow_def.name} - Step {self.step_order}: {self.step_name}"


class ApprovalInstance(models.Model):
    """Runtime instance of an approval workflow attached to a business object."""

    id = models.UUIDField(primary_key=True, default=uuid7, editable=False)
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.UUIDField()
    content_object = GenericForeignKey('content_type', 'object_id')
    workflow_def = models.ForeignKey(
        ApprovalWorkflowDefinition,
        on_delete=models.PROTECT,
        related_name='instances',
    )

    # FSM states
    STATUS_PENDING = 'pending'
    STATUS_IN_REVIEW = 'in_review'
    STATUS_APPROVED = 'approved'
    STATUS_REJECTED = 'rejected'
    STATUS_CANCELLED = 'cancelled'

    STATUS_CHOICES = [
        (STATUS_PENDING, 'Pending'),
        (STATUS_IN_REVIEW, 'In Review'),
        (STATUS_APPROVED, 'Approved'),
        (STATUS_REJECTED, 'Rejected'),
        (STATUS_CANCELLED, 'Cancelled'),
    ]

    status = FSMField(
        max_length=20,
        choices=STATUS_CHOICES,
        default=STATUS_PENDING,
        protected=True,
        db_index=True,
    )

    current_step = models.IntegerField(default=0)
    initiated_by = models.ForeignKey(
        'users.User',
        on_delete=models.PROTECT,
        related_name='initiated_approvals',
    )
    initiated_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    history = HistoricalRecords()

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['content_type', 'object_id']),
            models.Index(fields=['status', 'initiated_by']),
        ]
        verbose_name = 'Approval Instance'

    def __str__(self) -> str:
        return f"Approval {self.id} [{self.get_status_display()}]"

    @transition(
        field=status,
        source=STATUS_PENDING,
        target=STATUS_IN_REVIEW,
    )
    def start_review(self) -> None:
        """First step assignee begins review."""
        pass

    @transition(
        field=status,
        source=[STATUS_PENDING, STATUS_IN_REVIEW],
        target=STATUS_CANCELLED,
    )
    def cancel(self) -> None:
        """Initiator cancels the workflow."""
        from django.utils import timezone
        self.completed_at = timezone.now()

    @transition(
        field=status,
        source=STATUS_IN_REVIEW,
        target=STATUS_APPROVED,
    )
    def approve(self) -> None:
        """All steps completed successfully."""
        from django.utils import timezone
        self.completed_at = timezone.now()

    @transition(
        field=status,
        source=STATUS_IN_REVIEW,
        target=STATUS_REJECTED,
    )
    def reject(self) -> None:
        """Any step rejection."""
        from django.utils import timezone
        self.completed_at = timezone.now()


class ApprovalStepInstance(models.Model):
    """Runtime instance of a single approval step."""

    id = models.UUIDField(primary_key=True, default=uuid7, editable=False)
    instance = models.ForeignKey(
        ApprovalInstance,
        on_delete=models.CASCADE,
        related_name='step_instances',
    )
    step_def = models.ForeignKey(
        ApprovalStepDefinition,
        on_delete=models.PROTECT,
        related_name='step_instances',
    )
    assignee = models.ForeignKey(
        'users.User',
        on_delete=models.PROTECT,
        related_name='approval_step_assignments',
    )

    # FSM states for individual step
    ACTION_PENDING = 'pending'
    ACTION_APPROVED = 'approved'
    ACTION_REJECTED = 'rejected'
    ACTION_SKIPPED = 'skipped'

    ACTION_CHOICES = [
        (ACTION_PENDING, 'Pending'),
        (ACTION_APPROVED, 'Approved'),
        (ACTION_REJECTED, 'Rejected'),
        (ACTION_SKIPPED, 'Skipped'),
    ]

    action = FSMField(
        max_length=20,
        choices=ACTION_CHOICES,
        default=ACTION_PENDING,
        protected=True,
    )

    comment = models.TextField(blank=True)
    acted_at = models.DateTimeField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    history = HistoricalRecords()

    class Meta:
        ordering = ['instance', 'step_def__step_order']
        verbose_name = 'Approval Step Instance'

    def __str__(self) -> str:
        return (
            f"Step {self.step_def.step_order}: {self.step_def.step_name} "
            f"[{self.get_action_display()}] -> {self.assignee}"
        )

    @transition(
        field=action,
        source=ACTION_PENDING,
        target=ACTION_APPROVED,
    )
    def do_approve(self) -> None:
        """Assignee approves this step."""
        from django.utils import timezone
        self.acted_at = timezone.now()

    @transition(
        field=action,
        source=ACTION_PENDING,
        target=ACTION_REJECTED,
    )
    def do_reject(self) -> None:
        """Assignee rejects this step."""
        from django.utils import timezone
        self.acted_at = timezone.now()

    @transition(
        field=action,
        source=ACTION_PENDING,
        target=ACTION_SKIPPED,
    )
    def do_skip(self) -> None:
        """Step is skipped (conditional step not applicable)."""
        from django.utils import timezone
        self.acted_at = timezone.now()
