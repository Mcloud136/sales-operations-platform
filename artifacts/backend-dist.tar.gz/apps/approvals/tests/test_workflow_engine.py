from django.test import TestCase

from apps.approvals.models import (
    ApprovalInstance,
    ApprovalStepDefinition,
    ApprovalWorkflowDefinition,
)
from apps.approvals.services import (
    ConditionEvaluationError,
    WorkflowEngineService,
)
from apps.users.tests.factories import UserFactory


class ConditionEvaluationTest(TestCase):
    """Tests for condition evaluation in WorkflowEngineService."""

    def setUp(self):
        self.service = WorkflowEngineService()

    def test_empty_condition_returns_true(self):
        self.assertTrue(self.service._evaluate_conditions({}, {}))

    def test_single_gt_condition(self):
        condition = {'field': 'amount', 'op': 'gt', 'value': 1000000}
        context = {'amount': 1500000}
        self.assertTrue(self.service._evaluate_single_condition(condition, context))

    def test_single_gt_condition_false(self):
        condition = {'field': 'amount', 'op': 'gt', 'value': 1000000}
        context = {'amount': 500000}
        self.assertFalse(self.service._evaluate_single_condition(condition, context))

    def test_gte_condition(self):
        condition = {'field': 'amount', 'op': 'gte', 'value': 1000000}
        context = {'amount': 1000000}
        self.assertTrue(self.service._evaluate_single_condition(condition, context))

    def test_lt_condition(self):
        condition = {'field': 'amount', 'op': 'lt', 'value': 500000}
        context = {'amount': 300000}
        self.assertTrue(self.service._evaluate_single_condition(condition, context))

    def test_eq_condition(self):
        condition = {'field': 'customer_level', 'op': 'eq', 'value': 'strategic'}
        context = {'customer_level': 'strategic'}
        self.assertTrue(self.service._evaluate_single_condition(condition, context))

    def test_ne_condition(self):
        condition = {'field': 'customer_level', 'op': 'ne', 'value': 'normal'}
        context = {'customer_level': 'strategic'}
        self.assertTrue(self.service._evaluate_single_condition(condition, context))

    def test_in_condition(self):
        condition = {'field': 'industry', 'op': 'in', 'value': ['tech', 'finance']}
        context = {'industry': 'tech'}
        self.assertTrue(self.service._evaluate_single_condition(condition, context))

    def test_in_condition_not_found(self):
        condition = {'field': 'industry', 'op': 'in', 'value': ['tech', 'finance']}
        context = {'industry': 'healthcare'}
        self.assertFalse(self.service._evaluate_single_condition(condition, context))

    def test_and_condition(self):
        conditions = {
            'and': [
                {'field': 'amount', 'op': 'gt', 'value': 500000},
                {'field': 'customer_level', 'op': 'eq', 'value': 'strategic'},
            ]
        }
        context = {'amount': 1000000, 'customer_level': 'strategic'}
        self.assertTrue(self.service._evaluate_conditions(conditions, context))

    def test_and_condition_partial_fail(self):
        conditions = {
            'and': [
                {'field': 'amount', 'op': 'gt', 'value': 500000},
                {'field': 'customer_level', 'op': 'eq', 'value': 'strategic'},
            ]
        }
        context = {'amount': 1000000, 'customer_level': 'normal'}
        self.assertFalse(self.service._evaluate_conditions(conditions, context))

    def test_or_condition(self):
        conditions = {
            'or': [
                {'field': 'amount', 'op': 'gt', 'value': 1000000},
                {'field': 'customer_level', 'op': 'eq', 'value': 'strategic'},
            ]
        }
        context = {'amount': 500000, 'customer_level': 'strategic'}
        self.assertTrue(self.service._evaluate_conditions(conditions, context))

    def test_or_condition_all_false(self):
        conditions = {
            'or': [
                {'field': 'amount', 'op': 'gt', 'value': 1000000},
                {'field': 'customer_level', 'op': 'eq', 'value': 'strategic'},
            ]
        }
        context = {'amount': 500000, 'customer_level': 'normal'}
        self.assertFalse(self.service._evaluate_conditions(conditions, context))

    def test_unknown_operator_raises(self):
        condition = {'field': 'amount', 'op': 'unknown_op', 'value': 100}
        context = {'amount': 200}
        with self.assertRaises(ConditionEvaluationError):
            self.service._evaluate_single_condition(condition, context)

    def test_missing_field_raises(self):
        condition = {'op': 'gt', 'value': 100}
        context = {}
        with self.assertRaises(ConditionEvaluationError):
            self.service._evaluate_single_condition(condition, context)


class TemplateSelectionTest(TestCase):
    """Tests for workflow template selection."""

    def setUp(self):
        self.service = WorkflowEngineService()
        self.default_def = ApprovalWorkflowDefinition.objects.create(
            name='Default Contract Approval',
            workflow_type='contract_approval',
            is_default=True,
        )
        self.high_value_def = ApprovalWorkflowDefinition.objects.create(
            name='High-Value Contract Approval',
            workflow_type='contract_approval',
            conditions={'amount_threshold': 1000000, 'op': 'gte'},
            is_default=False,
        )

    def test_selects_high_value_template(self):
        template = self.service.select_template(
            'contract_approval',
            {'amount': 1500000},
        )
        self.assertEqual(template.id, self.high_value_def.id)

    def test_selects_default_for_low_value(self):
        template = self.service.select_template(
            'contract_approval',
            {'amount': 500000},
        )
        self.assertEqual(template.id, self.default_def.id)

    def test_raises_when_no_template(self):
        # Remove all templates
        ApprovalWorkflowDefinition.objects.all().delete()
        with self.assertRaises(ApprovalWorkflowDefinition.DoesNotExist):
            self.service.select_template('contract_approval', {})

    def test_empty_conditions_always_match(self):
        always_match = ApprovalWorkflowDefinition.objects.create(
            name='Always Match',
            workflow_type='contract_approval',
            conditions={},
            is_default=False,
        )
        template = self.service.select_template('contract_approval', {})
        self.assertEqual(template.id, always_match.id)


class AssigneeMaterializationTest(TestCase):
    """Tests for one-time assignee resolution (Iron Rule 7)."""

    def setUp(self):
        self.service = WorkflowEngineService()
        self.manager = UserFactory(role='sales_manager')
        self.sales_rep = UserFactory(role='sales_rep')

    def test_role_based_assignment(self):
        definition = ApprovalWorkflowDefinition.objects.create(
            name='Test Workflow',
            workflow_type='contract_approval',
        )
        step_def = ApprovalStepDefinition.objects.create(
            workflow_def=definition,
            step_order=1,
            step_name='Manager Review',
            assignee_role='sales_manager',
        )

        # Create a mock context object with assigned_to
        class MockObj:
            assigned_to = self.sales_rep

        assignee = self.service._resolve_assignee(step_def, MockObj(), {})
        self.assertEqual(assignee.id, self.manager.id)
