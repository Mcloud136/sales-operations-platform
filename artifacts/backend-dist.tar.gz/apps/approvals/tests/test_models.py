from django.test import TestCase
from django_fsm import TransitionNotAllowed

from apps.approvals.models import (
    ApprovalInstance,
    ApprovalStepDefinition,
    ApprovalStepInstance,
    ApprovalWorkflowDefinition,
)
from apps.users.tests.factories import UserFactory


class ApprovalWorkflowDefinitionModelTest(TestCase):
    """Tests for ApprovalWorkflowDefinition model."""

    def test_create_workflow_definition(self):
        definition = ApprovalWorkflowDefinition.objects.create(
            name='Standard Contract Approval',
            workflow_type='contract_approval',
            conditions={'amount_threshold': 1000000, 'op': 'gte'},
            is_default=False,
        )
        self.assertEqual(definition.name, 'Standard Contract Approval')
        self.assertEqual(definition.workflow_type, 'contract_approval')
        self.assertEqual(definition.conditions['amount_threshold'], 1000000)
        self.assertFalse(definition.is_default)

    def test_str_representation(self):
        definition = ApprovalWorkflowDefinition.objects.create(
            name='Test Workflow',
            workflow_type='contract_approval',
        )
        self.assertEqual(str(definition), 'Test Workflow')


class ApprovalStepDefinitionModelTest(TestCase):
    """Tests for ApprovalStepDefinition model."""

    def setUp(self):
        self.definition = ApprovalWorkflowDefinition.objects.create(
            name='Test Workflow',
            workflow_type='contract_approval',
        )

    def test_create_step_definition(self):
        step = ApprovalStepDefinition.objects.create(
            workflow_def=self.definition,
            step_order=1,
            step_name='Sales Manager Review',
            assignee_role='sales_manager',
            rejection_target='reject_to_originator',
            require_all=False,
        )
        self.assertEqual(step.step_order, 1)
        self.assertEqual(step.assignee_role, 'sales_manager')
        self.assertFalse(step.require_all)

    def test_unique_step_order_per_definition(self):
        ApprovalStepDefinition.objects.create(
            workflow_def=self.definition,
            step_order=1,
            step_name='Step 1',
            assignee_role='sales_manager',
        )
        with self.assertRaises(Exception):
            ApprovalStepDefinition.objects.create(
                workflow_def=self.definition,
                step_order=1,
                step_name='Step 1 Duplicate',
                assignee_role='sales_manager',
            )


class ApprovalInstanceModelTest(TestCase):
    """Tests for ApprovalInstance FSM transitions."""

    def setUp(self):
        self.definition = ApprovalWorkflowDefinition.objects.create(
            name='Test Workflow',
            workflow_type='contract_approval',
        )
        self.user = UserFactory(role='sales_rep')

    def test_initial_status_is_pending(self):
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.user,
        )
        self.assertEqual(instance.status, ApprovalInstance.STATUS_PENDING)

    def test_pending_to_in_review(self):
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.user,
        )
        instance.start_review()
        instance.save()
        self.assertEqual(instance.status, ApprovalInstance.STATUS_IN_REVIEW)

    def test_in_review_to_approved(self):
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.user,
        )
        instance.start_review()
        instance.save()
        instance.approve()
        instance.save()
        self.assertEqual(instance.status, ApprovalInstance.STATUS_APPROVED)

    def test_in_review_to_rejected(self):
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.user,
        )
        instance.start_review()
        instance.save()
        instance.reject()
        instance.save()
        self.assertEqual(instance.status, ApprovalInstance.STATUS_REJECTED)

    def test_pending_to_cancelled(self):
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.user,
        )
        instance.cancel()
        instance.save()
        self.assertEqual(instance.status, ApprovalInstance.STATUS_CANCELLED)

    def test_cannot_approve_from_pending_directly(self):
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.user,
        )
        with self.assertRaises(TransitionNotAllowed):
            instance.approve()

    def test_cannot_double_approve(self):
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.user,
        )
        instance.start_review()
        instance.save()
        instance.approve()
        instance.save()
        with self.assertRaises(TransitionNotAllowed):
            instance.approve()


class ApprovalStepInstanceModelTest(TestCase):
    """Tests for ApprovalStepInstance FSM transitions."""

    def setUp(self):
        self.definition = ApprovalWorkflowDefinition.objects.create(
            name='Test Workflow',
            workflow_type='contract_approval',
        )
        self.step_def = ApprovalStepDefinition.objects.create(
            workflow_def=self.definition,
            step_order=1,
            step_name='Manager Review',
            assignee_role='sales_manager',
        )
        self.user = UserFactory(role='sales_manager')
        self.initiator = UserFactory(role='sales_rep')
        self.instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.initiator,
        )
        self.step_instance = ApprovalStepInstance.objects.create(
            instance=self.instance,
            step_def=self.step_def,
            assignee=self.user,
        )

    def test_initial_action_is_pending(self):
        self.assertEqual(
            self.step_instance.action, ApprovalStepInstance.ACTION_PENDING
        )

    def test_pending_to_approved(self):
        self.step_instance.do_approve()
        self.step_instance.save()
        self.assertEqual(
            self.step_instance.action, ApprovalStepInstance.ACTION_APPROVED
        )
        self.assertIsNotNone(self.step_instance.acted_at)

    def test_pending_to_rejected(self):
        self.step_instance.do_reject()
        self.step_instance.save()
        self.assertEqual(
            self.step_instance.action, ApprovalStepInstance.ACTION_REJECTED
        )
        self.assertIsNotNone(self.step_instance.acted_at)

    def test_cannot_approve_twice(self):
        self.step_instance.do_approve()
        self.step_instance.save()
        with self.assertRaises(TransitionNotAllowed):
            self.step_instance.do_approve()
