from django.test import TestCase
from rest_framework.test import APIClient
from rest_framework_simplejwt.tokens import AccessToken

from apps.approvals.models import (
    ApprovalInstance,
    ApprovalStepDefinition,
    ApprovalStepInstance,
    ApprovalWorkflowDefinition,
)
from apps.users.tests.factories import UserFactory


class ApprovalAPITest(TestCase):
    """Tests for the Approval API endpoints."""

    def setUp(self):
        self.client = APIClient()

        self.initiator = UserFactory(role='sales_rep')
        self.manager = UserFactory(role='sales_manager')
        self.gm = UserFactory(role='gm')
        self.other_user = UserFactory(role='sales_rep')

        self.definition = ApprovalWorkflowDefinition.objects.create(
            name='Standard Approval',
            workflow_type='contract_approval',
        )
        self.step1 = ApprovalStepDefinition.objects.create(
            workflow_def=self.definition,
            step_order=1,
            step_name='Manager Review',
            assignee_role='sales_manager',
        )
        self.step2 = ApprovalStepDefinition.objects.create(
            workflow_def=self.definition,
            step_order=2,
            step_name='GM Review',
            assignee_role='gm',
        )

    def _auth_as(self, user):
        token = AccessToken.for_user(user)
        self.client.credentials(HTTP_AUTHORIZATION=f'Bearer {token}')

    def _create_workflow(self):
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.initiator,
            status=ApprovalInstance.STATUS_IN_REVIEW,
            current_step=1,
        )
        ApprovalStepInstance.objects.create(
            instance=instance,
            step_def=self.step1,
            assignee=self.manager,
            action=ApprovalStepInstance.ACTION_PENDING,
        )
        ApprovalStepInstance.objects.create(
            instance=instance,
            step_def=self.step2,
            assignee=self.gm,
            action=ApprovalStepInstance.ACTION_PENDING,
        )
        return instance

    def test_list_approvals_visible_to_assignee(self):
        self._auth_as(self.manager)
        self._create_workflow()

        response = self.client.get('/api/v1/approvals/')
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(len(response.data['results']), 1)

    def test_list_approvals_visible_to_initiator(self):
        self._auth_as(self.initiator)
        self._create_workflow()

        response = self.client.get('/api/v1/approvals/')
        self.assertEqual(response.status_code, 200)
        self.assertGreaterEqual(len(response.data['results']), 1)

    def test_list_approvals_hidden_from_unrelated_user(self):
        self._auth_as(self.other_user)
        self._create_workflow()

        response = self.client.get('/api/v1/approvals/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.data['results']), 0)

    def test_retrieve_approval_detail(self):
        self._auth_as(self.manager)
        instance = self._create_workflow()

        response = self.client.get(f'/api/v1/approvals/{instance.id}/')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data['id'], str(instance.id))
        self.assertEqual(len(response.data['steps']), 2)

    def test_act_approve_success(self):
        self._auth_as(self.manager)
        instance = self._create_workflow()

        response = self.client.post(
            f'/api/v1/approvals/{instance.id}/act/',
            {'action': 'approve', 'comment': 'Approved'},
            format='json',
        )
        self.assertEqual(response.status_code, 200)
        instance.refresh_from_db()
        self.assertEqual(instance.current_step, 2)

    def test_act_reject_success(self):
        self._auth_as(self.manager)
        instance = self._create_workflow()

        response = self.client.post(
            f'/api/v1/approvals/{instance.id}/act/',
            {'action': 'reject', 'comment': 'Needs revision'},
            format='json',
        )
        self.assertEqual(response.status_code, 200)
        instance.refresh_from_db()
        self.assertEqual(instance.status, ApprovalInstance.STATUS_REJECTED)

    def test_act_without_comment_on_reject_fails(self):
        self._auth_as(self.manager)
        instance = self._create_workflow()

        response = self.client.post(
            f'/api/v1/approvals/{instance.id}/act/',
            {'action': 'reject', 'comment': ''},
            format='json',
        )
        self.assertEqual(response.status_code, 400)

    def test_act_by_non_assignee_fails(self):
        self._auth_as(self.other_user)
        instance = self._create_workflow()

        response = self.client.post(
            f'/api/v1/approvals/{instance.id}/act/',
            {'action': 'approve', 'comment': 'Trying to hack'},
            format='json',
        )
        self.assertEqual(response.status_code, 403)

    def test_cancel_workflow_by_initiator(self):
        self._auth_as(self.initiator)
        instance = self._create_workflow()

        response = self.client.post(
            f'/api/v1/approvals/{instance.id}/cancel/',
        )
        self.assertEqual(response.status_code, 200)
        instance.refresh_from_db()
        self.assertEqual(instance.status, ApprovalInstance.STATUS_CANCELLED)

    def test_cancel_workflow_by_non_initiator_fails(self):
        self._auth_as(self.other_user)
        instance = self._create_workflow()

        response = self.client.post(
            f'/api/v1/approvals/{instance.id}/cancel/',
        )
        self.assertEqual(response.status_code, 403)

    def test_unauthenticated_access_fails(self):
        response = self.client.get('/api/v1/approvals/')
        self.assertEqual(response.status_code, 401)
