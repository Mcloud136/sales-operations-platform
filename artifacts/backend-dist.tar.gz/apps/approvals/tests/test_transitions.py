from django.test import TestCase
from django.core.exceptions import PermissionDenied

from apps.approvals.models import (
    ApprovalInstance,
    ApprovalStepDefinition,
    ApprovalStepInstance,
    ApprovalWorkflowDefinition,
)
from apps.approvals.services import TransitionService
from apps.users.tests.factories import UserFactory


class TransitionServiceTest(TestCase):
    """Tests for approval workflow transitions."""

    def setUp(self):
        self.service = TransitionService()
        self.initiator = UserFactory(role='sales_rep')
        self.manager = UserFactory(role='sales_manager')
        self.gm = UserFactory(role='gm')

        self.definition = ApprovalWorkflowDefinition.objects.create(
            name='Standard Contract Approval',
            workflow_type='contract_approval',
        )
        self.step1 = ApprovalStepDefinition.objects.create(
            workflow_def=self.definition,
            step_order=1,
            step_name='Sales Manager Review',
            assignee_role='sales_manager',
            rejection_target='reject_to_originator',
        )
        self.step2 = ApprovalStepDefinition.objects.create(
            workflow_def=self.definition,
            step_order=2,
            step_name='GM Approval',
            assignee_role='gm',
            rejection_target='reject_to_originator',
        )

    def _create_two_step_workflow(self):
        """Helper to create an in-review workflow with two pending steps."""
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.initiator,
            status=ApprovalInstance.STATUS_IN_REVIEW,
            current_step=1,
        )
        step1_instance = ApprovalStepInstance.objects.create(
            instance=instance,
            step_def=self.step1,
            assignee=self.manager,
            action=ApprovalStepInstance.ACTION_PENDING,
        )
        step2_instance = ApprovalStepInstance.objects.create(
            instance=instance,
            step_def=self.step2,
            assignee=self.gm,
            action=ApprovalStepInstance.ACTION_PENDING,
        )
        return instance, step1_instance, step2_instance

    def test_advance_single_step(self):
        """After one step is approved, current_step moves to next."""
        instance, step1, step2 = self._create_two_step_workflow()

        result = self.service.advance_step(step1, self.manager, 'Looks good')
        self.assertEqual(result.current_step, 2)
        self.assertEqual(step1.action, ApprovalStepInstance.ACTION_APPROVED)
        self.assertEqual(step1.comment, 'Looks good')
        self.assertIsNotNone(step1.acted_at)
        self.assertEqual(instance.status, ApprovalInstance.STATUS_IN_REVIEW)

    def test_advance_final_step_completes_workflow(self):
        """After the last step is approved, workflow status becomes approved."""
        instance, step1, step2 = self._create_two_step_workflow()

        self.service.advance_step(step1, self.manager, 'Approved')
        result = self.service.advance_step(step2, self.gm, 'Final approval')

        self.assertEqual(result.status, ApprovalInstance.STATUS_APPROVED)
        self.assertIsNotNone(result.completed_at)

    def test_advance_non_assignee_raises(self):
        """Only the assigned user can approve a step."""
        instance, step1, step2 = self._create_two_step_workflow()

        other_user = UserFactory(role='sales_rep')
        with self.assertRaises(PermissionDenied):
            self.service.advance_step(step1, other_user, 'Hacking')

    def test_advance_already_acted_step_raises(self):
        """Cannot approve a step that is not pending."""
        instance, step1, step2 = self._create_two_step_workflow()

        self.service.advance_step(step1, self.manager, 'Approved')
        with self.assertRaises(ValueError):
            self.service.advance_step(step1, self.manager, 'Double approve')

    def test_reject_step_rejects_workflow(self):
        """Rejecting a step transitions the workflow to rejected."""
        instance, step1, step2 = self._create_two_step_workflow()

        result = self.service.reject_step(step1, self.manager, 'Not good enough')
        self.assertEqual(result.status, ApprovalInstance.STATUS_REJECTED)
        self.assertEqual(step1.action, ApprovalStepInstance.ACTION_REJECTED)
        self.assertIsNotNone(result.completed_at)

    def test_reject_without_comment_raises(self):
        """Rejection requires a comment."""
        instance, step1, step2 = self._create_two_step_workflow()

        with self.assertRaises(ValueError):
            self.service.reject_step(step1, self.manager, '')

    def test_reject_non_assignee_raises(self):
        """Only the assigned user can reject a step."""
        instance, step1, step2 = self._create_two_step_workflow()

        other_user = UserFactory(role='sales_rep')
        with self.assertRaises(PermissionDenied):
            self.service.reject_step(step1, other_user, 'Not my call')

    def test_cancel_workflow(self):
        """Initiator can cancel an active workflow."""
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.initiator,
            status=ApprovalInstance.STATUS_IN_REVIEW,
        )
        ApprovalStepInstance.objects.create(
            instance=instance,
            step_def=self.step1,
            assignee=self.manager,
        )

        result = self.service.cancel_workflow(instance, self.initiator)
        self.assertEqual(result.status, ApprovalInstance.STATUS_CANCELLED)

    def test_cancel_non_initiator_raises(self):
        """Only the initiator can cancel a workflow."""
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.initiator,
            status=ApprovalInstance.STATUS_IN_REVIEW,
        )

        other_user = UserFactory(role='sales_rep')
        with self.assertRaises(PermissionDenied):
            self.service.cancel_workflow(instance, other_user)

    def test_reject_to_specific_step_resets_step(self):
        """When rejection_target is reject_to_specific_step, target step resets to pending."""
        self.step1.rejection_target = 'reject_to_specific_step'
        self.step1.rejection_target_step = 1
        self.step1.save()

        instance, step1, step2 = self._create_two_step_workflow()

        result = self.service.reject_step(step1, self.manager, 'Need more info')
        self.assertEqual(result.status, ApprovalInstance.STATUS_REJECTED)


class CountersignTest(TestCase):
    """Tests for require_all (countersign) step behavior."""

    def setUp(self):
        self.service = TransitionService()
        self.initiator = UserFactory(role='sales_rep')
        self.manager1 = UserFactory(role='sales_manager')
        self.manager2 = UserFactory(role='sales_manager')

        self.definition = ApprovalWorkflowDefinition.objects.create(
            name='Countersign Workflow',
            workflow_type='contract_approval',
        )
        self.step_def = ApprovalStepDefinition.objects.create(
            workflow_def=self.definition,
            step_order=1,
            step_name='Manager Countersign',
            assignee_role='sales_manager',
            require_all=True,
        )

    def test_countersign_all_must_approve(self):
        """In countersign, all assignees must approve to advance."""
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.initiator,
            status=ApprovalInstance.STATUS_IN_REVIEW,
            current_step=1,
        )
        step_instance1 = ApprovalStepInstance.objects.create(
            instance=instance,
            step_def=self.step_def,
            assignee=self.manager1,
            action=ApprovalStepInstance.ACTION_PENDING,
        )
        step_instance2 = ApprovalStepInstance.objects.create(
            instance=instance,
            step_def=self.step_def,
            assignee=self.manager2,
            action=ApprovalStepInstance.ACTION_PENDING,
        )

        # First manager approves
        self.service.advance_step(step_instance1, self.manager1, 'Approved')
        instance.refresh_from_db()
        self.assertEqual(instance.status, ApprovalInstance.STATUS_IN_REVIEW)

        # Second manager approves -> workflow completes
        self.service.advance_step(step_instance2, self.manager2, 'Also approved')
        instance.refresh_from_db()
        self.assertEqual(instance.status, ApprovalInstance.STATUS_APPROVED)

    def test_countersign_one_reject_blocks(self):
        """In countersign, one rejection rejects the entire workflow."""
        instance = ApprovalInstance.objects.create(
            workflow_def=self.definition,
            initiated_by=self.initiator,
            status=ApprovalInstance.STATUS_IN_REVIEW,
            current_step=1,
        )
        step_instance1 = ApprovalStepInstance.objects.create(
            instance=instance,
            step_def=self.step_def,
            assignee=self.manager1,
            action=ApprovalStepInstance.ACTION_PENDING,
        )
        step_instance2 = ApprovalStepInstance.objects.create(
            instance=instance,
            step_def=self.step_def,
            assignee=self.manager2,
            action=ApprovalStepInstance.ACTION_PENDING,
        )

        # First manager rejects
        self.service.reject_step(
            step_instance1, self.manager1, 'I do not approve'
        )
        instance.refresh_from_db()
        self.assertEqual(instance.status, ApprovalInstance.STATUS_REJECTED)
