from django.contrib import admin

from apps.approvals.models import (
    ApprovalInstance,
    ApprovalStepDefinition,
    ApprovalStepInstance,
    ApprovalWorkflowDefinition,
)


class ApprovalStepDefinitionInline(admin.TabularInline):
    model = ApprovalStepDefinition
    extra = 1
    ordering = ['step_order']
    fields = [
        'step_order', 'step_name', 'assignee_role', 'assignee_dynamic',
        'is_conditional', 'condition_expr', 'rejection_target',
        'rejection_target_step', 'require_all',
    ]


@admin.register(ApprovalWorkflowDefinition)
class ApprovalWorkflowDefinitionAdmin(admin.ModelAdmin):
    list_display = ['name', 'workflow_type', 'is_default', 'created_at']
    list_filter = ['workflow_type', 'is_default']
    search_fields = ['name']
    inlines = [ApprovalStepDefinitionInline]


class ApprovalStepInstanceInline(admin.TabularInline):
    model = ApprovalStepInstance
    extra = 0
    readonly_fields = ['assignee', 'action', 'comment', 'acted_at']
    ordering = ['step_def__step_order']


@admin.register(ApprovalInstance)
class ApprovalInstanceAdmin(admin.ModelAdmin):
    list_display = [
        'id', 'content_type', 'object_id', 'workflow_def',
        'status', 'current_step', 'initiated_by', 'initiated_at',
    ]
    list_filter = ['status', 'workflow_def', 'initiated_by']
    readonly_fields = ['content_type', 'object_id', 'status', 'current_step']
    inlines = [ApprovalStepInstanceInline]
