from rest_framework import mixins, status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.exceptions import PermissionDenied

from apps.common.permissions import IsRoleAllowed
from apps.approvals.models import ApprovalInstance, ApprovalStepInstance
from apps.approvals.serializers import (
    ApprovalActionSerializer,
    ApprovalInstanceSerializer,
)
from apps.approvals.services import TransitionService


class ApprovalViewSet(
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    viewsets.GenericViewSet,
):
    """
    ViewSet for viewing approval workflows assigned to the current user.
    """

    queryset = ApprovalInstance.objects.select_related(
        'workflow_def', 'initiated_by', 'content_type',
    ).prefetch_related('step_instances__step_def', 'step_instances__assignee')
    serializer_class = ApprovalInstanceSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        """Return approvals where the current user is a step assignee or initiator."""
        qs = super().get_queryset()
        user = self.request.user

        # Approvals where user is a step assignee
        assigned_to_user = ApprovalStepInstance.objects.filter(
            assignee=user,
            action=ApprovalStepInstance.ACTION_PENDING,
        ).values_list('instance_id', flat=True)

        # Approvals initiated by user
        initiated_by_user = qs.filter(initiated_by=user)

        return (qs.filter(id__in=assigned_to_user) | initiated_by_user).distinct()

    @action(detail=True, methods=['post'], url_path='act')
    def act(self, request, pk=None):
        """
        Approve or reject a specific step in the workflow.

        The current user must be the assignee of a pending step.
        """
        instance = self.get_object()
        serializer = ApprovalActionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        action_type = serializer.validated_data['action']
        comment = serializer.validated_data.get('comment', '')

        # Find the pending step instance assigned to the current user
        step_instance = instance.step_instances.filter(
            assignee=request.user,
            action=ApprovalStepInstance.ACTION_PENDING,
        ).first()

        if step_instance is None:
            raise PermissionDenied(
                "You have no pending step to act on in this workflow."
            )

        service = TransitionService()

        if action_type == 'approve':
            instance = service.advance_step(step_instance, request.user, comment)
        elif action_type == 'reject':
            instance = service.reject_step(step_instance, request.user, comment)

        return Response(
            ApprovalInstanceSerializer(instance).data,
            status=status.HTTP_200_OK,
        )

    @action(detail=True, methods=['post'], url_path='cancel')
    def cancel(self, request, pk=None):
        """Cancel the workflow (initiator only)."""
        instance = self.get_object()
        service = TransitionService()
        instance = service.cancel_workflow(instance, request.user)
        return Response(
            ApprovalInstanceSerializer(instance).data,
            status=status.HTTP_200_OK,
        )
