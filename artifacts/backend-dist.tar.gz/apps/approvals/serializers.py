from rest_framework import serializers

from apps.approvals.models import (
    ApprovalInstance,
    ApprovalStepDefinition,
    ApprovalStepInstance,
    ApprovalWorkflowDefinition,
)


class ApprovalWorkflowDefinitionSerializer(serializers.ModelSerializer):
    """Read-only serializer for workflow definitions (admin use)."""

    class Meta:
        model = ApprovalWorkflowDefinition
        fields = [
            'id', 'name', 'workflow_type', 'conditions',
            'is_default', 'created_at', 'updated_at',
        ]
        read_only_fields = fields


class ApprovalStepDefinitionSerializer(serializers.ModelSerializer):
    """Read-only serializer for step definitions (admin use)."""

    class Meta:
        model = ApprovalStepDefinition
        fields = [
            'id', 'workflow_def', 'step_order', 'step_name',
            'assignee_role', 'assignee_dynamic', 'is_conditional',
            'condition_expr', 'rejection_target', 'rejection_target_step',
            'require_all',
        ]
        read_only_fields = fields


class ApprovalStepInstanceSerializer(serializers.ModelSerializer):
    """Serializer for runtime step instances with assignee details."""

    step_name = serializers.CharField(
        source='step_def.step_name', read_only=True,
    )
    step_order = serializers.IntegerField(
        source='step_def.step_order', read_only=True,
    )
    assignee_name = serializers.CharField(
        source='assignee.name', read_only=True,
    )
    assignee_role_display = serializers.CharField(
        source='step_def.get_assignee_role_display', read_only=True,
    )

    class Meta:
        model = ApprovalStepInstance
        fields = [
            'id', 'step_name', 'step_order', 'assignee',
            'assignee_name', 'assignee_role_display',
            'action', 'comment', 'acted_at', 'created_at',
        ]
        read_only_fields = fields


class ApprovalInstanceSerializer(serializers.ModelSerializer):
    """Serializer for approval instances with step details and related object info."""

    workflow_name = serializers.CharField(
        source='workflow_def.name', read_only=True,
    )
    initiated_by_name = serializers.CharField(
        source='initiated_by.name', read_only=True,
    )
    object_title = serializers.SerializerMethodField()
    object_type = serializers.CharField(
        source='content_type.model', read_only=True,
    )
    steps = ApprovalStepInstanceSerializer(
        many=True, read_only=True, source='step_instances',
    )

    class Meta:
        model = ApprovalInstance
        fields = [
            'id', 'content_type', 'object_id', 'object_title', 'object_type',
            'workflow_def', 'workflow_name', 'status', 'current_step',
            'initiated_by', 'initiated_by_name',
            'initiated_at', 'completed_at', 'created_at', 'updated_at',
            'steps',
        ]
        read_only_fields = fields

    def get_object_title(self, obj):
        """Get the title of the related content object."""
        try:
            content_obj = obj.content_object
            if hasattr(content_obj, 'title'):
                return content_obj.title
            return str(content_obj)
        except Exception:
            return '(deleted object)'


class ApprovalActionSerializer(serializers.Serializer):
    """Serializer for approve/reject action input."""

    action = serializers.ChoiceField(
        choices=['approve', 'reject'],
        required=True,
    )
    comment = serializers.CharField(
        required=False,
        default='',
        allow_blank=True,
    )
