"""Approval workflow engine: template selection, instantiation, and transitions."""

import logging
from datetime import datetime
from typing import Optional

from django.contrib.contenttypes.models import ContentType
from django.db import transaction
from django.utils import timezone

from apps.approvals.models import (
    ApprovalInstance,
    ApprovalStepDefinition,
    ApprovalStepInstance,
    ApprovalWorkflowDefinition,
)

logger = logging.getLogger(__name__)


class ConditionEvaluationError(Exception):
    """Raised when a condition expression cannot be evaluated."""


class WorkflowEngineService:
    """Service for selecting workflow templates and instantiating approval workflows."""

    def __init__(self):
        self._condition_ops = {
            'eq': lambda a, b: a == b,
            'ne': lambda a, b: a != b,
            'gt': lambda a, b: a > b,
            'gte': lambda a, b: a >= b,
            'lt': lambda a, b: a < b,
            'lte': lambda a, b: a <= b,
            'in': lambda a, b: a in b,
            'contains': lambda a, b: b in a if isinstance(a, str) else False,
        }

    def select_template(
        self,
        workflow_type: str,
        context: dict,
    ) -> ApprovalWorkflowDefinition:
        """
        Select the best matching workflow template based on context.

        Args:
            workflow_type: The type of workflow ('contract_approval', 'bid_review').
            context: Dictionary with object attributes used for condition matching.
                     Example: {"amount": 1500000, "customer_level": "strategic"}

        Returns:
            The matched ApprovalWorkflowDefinition.

        Raises:
            ApprovalWorkflowDefinition.DoesNotExist: If no template matches.
        """
        definitions = ApprovalWorkflowDefinition.objects.filter(
            workflow_type=workflow_type,
        ).order_by('-conditions')  # More specific (non-empty conditions) first

        default_def = None

        for definition in definitions:
            if definition.is_default:
                default_def = definition
                continue

            if self._evaluate_conditions(definition.conditions, context):
                logger.info(
                    "Selected workflow template '%s' (id=%s) for context %s",
                    definition.name,
                    definition.id,
                    context,
                )
                return definition

        if default_def:
            logger.info(
                "No conditions matched, using default template '%s' (id=%s)",
                default_def.name,
                default_def.id,
            )
            return default_def

        raise ApprovalWorkflowDefinition.DoesNotExist(
            f"No workflow template found for type '{workflow_type}' "
            f"and no default template exists."
        )

    def _evaluate_conditions(
        self,
        conditions: dict,
        context: dict,
    ) -> bool:
        """
        Evaluate a JSON condition expression against a context dict.

        Supports compound conditions:
          - Single: {"field": "amount", "op": "gt", "value": 1000000}
          - AND:   {"and": [<cond1>, <cond2>]}
          - OR:    {"or": [<cond1>, <cond2>]}
        """
        if not conditions:
            return True

        if 'and' in conditions:
            return all(
                self._evaluate_single_condition(c, context)
                for c in conditions['and']
            )

        if 'or' in conditions:
            return any(
                self._evaluate_single_condition(c, context)
                for c in conditions['or']
            )

        return self._evaluate_single_condition(conditions, context)

    def _evaluate_single_condition(
        self,
        condition: dict,
        context: dict,
    ) -> bool:
        """Evaluate a single condition: {field, op, value}."""
        field = condition.get('field')
        op = condition.get('op', 'eq')
        expected = condition.get('value')

        if field is None:
            raise ConditionEvaluationError(
                f"Condition missing 'field': {condition}"
            )

        # Resolve nested field paths: "assigned_to.department" -> context["assigned_to"]["department"]
        actual = self._resolve_field_path(field, context)

        op_func = self._condition_ops.get(op)
        if op_func is None:
            raise ConditionEvaluationError(
                f"Unknown operator '{op}' in condition: {condition}"
            )

        return op_func(actual, expected)

    def _resolve_field_path(self, path: str, context: dict):
        """Resolve a dotted field path against a dict or object."""
        parts = path.split('.')
        current = context
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            elif hasattr(current, part):
                current = getattr(current, part)
            else:
                return None
            if current is None:
                return None
        return current

    def _evaluate_step_condition(
        self,
        condition_expr: dict,
        context: dict,
    ) -> bool:
        """Evaluate whether a conditional step should be included."""
        return self._evaluate_conditions(condition_expr, context)

    def _resolve_assignee(
        self,
        step_def: ApprovalStepDefinition,
        obj,
        context: dict,
    ) -> Optional['User']:  # noqa: F821
        """
        Resolve the concrete User for a step definition.

        Priority:
        1. If assignee_dynamic is set, resolve the expression against the object.
        2. Otherwise, find a user matching assignee_role in the object's context.
        """
        from apps.users.models import User

        if step_def.assignee_dynamic:
            return self._resolve_dynamic_assignee(step_def.assignee_dynamic, obj, context)

        # Fall back to role-based assignment: find a user with the matching role
        # in the relevant department or globally
        role_field_map = {
            'sales_manager': 'sales_manager',
            'legal': 'legal',
            'gm': 'gm',
            'vp': 'vp',
            'team_lead': 'team_lead',
        }

        # Try to find the assigned user's manager/department head first
        assigned_to = getattr(obj, 'assigned_to', None)
        if assigned_to:
            department = getattr(assigned_to, 'department', None)
            if department:
                manager = User.objects.filter(
                    role=role_field_map.get(step_def.assignee_role, step_def.assignee_role),
                    department=department,
                ).first()
                if manager:
                    return manager

        # Fall back to any user with that role
        user = User.objects.filter(
            role=role_field_map.get(step_def.assignee_role, step_def.assignee_role),
        ).first()
        return user

    def _resolve_dynamic_assignee(
        self,
        expression: str,
        obj,
        context: dict,
    ) -> Optional['User']:  # noqa: F821
        """
        Resolve a dynamic assignee expression against the object.

        Supports:
        - "object.assigned_to.manager" -> resolves via object attribute chain
        - "object.department.head" -> resolves via object attribute chain
        """
        parts = expression.replace('object.', '', 1).split('.')
        current = obj
        for part in parts:
            if current is None:
                return None
            if hasattr(current, part):
                current = getattr(current, part)
            elif isinstance(current, dict):
                current = current.get(part)
            else:
                return None

        if isinstance(current, 'User'):  # noqa: F821
            return current

        return None

    @transaction.atomic
    def instantiate_workflow(
        self,
        obj,
        initiated_by: 'User',  # noqa: F821
        workflow_type: str,
    ) -> ApprovalInstance:
        """
        Instantiate a new approval workflow for a business object.

        1. Select the matching workflow template based on object attributes.
        2. Filter conditional steps based on object context.
        3. Materialize dynamic assignees (one-time resolution per Iron Rule 7).
        4. Create ApprovalStepInstance records with resolved assignees.
        5. If at least one step exists, transition instance to in_review if ready.

        Args:
            obj: The business object (Contract, BidProject) to attach the workflow to.
            initiated_by: The User initiating the workflow.
            workflow_type: Type of workflow ('contract_approval', 'bid_review').

        Returns:
            The created ApprovalInstance.
        """
        from apps.users.models import User

        # Build context from object for condition matching
        context = self._build_context(obj)

        # Select template
        workflow_def = self.select_template(workflow_type, context)

        # Create the ApprovalInstance
        content_type = ContentType.objects.get_for_model(obj)
        instance = ApprovalInstance.objects.create(
            content_type=content_type,
            object_id=obj.id,
            workflow_def=workflow_def,
            initiated_by=initiated_by,
            status=ApprovalInstance.STATUS_PENDING,
            current_step=0,
        )

        # Get step definitions, ordered by step_order
        step_defs = list(
            workflow_def.step_definitions.order_by('step_order')
        )

        created_count = 0
        for step_def in step_defs:
            # Evaluate conditional steps
            if step_def.is_conditional and step_def.condition_expr:
                if not self._evaluate_step_condition(step_def.condition_expr, context):
                    logger.info(
                        "Skipping conditional step '%s' (order=%d) -- condition not met",
                        step_def.step_name,
                        step_def.step_order,
                    )
                    continue

            # Resolve assignee -- one-time materialization (Iron Rule 7)
            assignee = self._resolve_assignee(step_def, obj, context)
            if assignee is None:
                logger.warning(
                    "Could not resolve assignee for step '%s' (order=%d) "
                    "with role='%s', dynamic='%s' -- skipping step",
                    step_def.step_name,
                    step_def.step_order,
                    step_def.assignee_role,
                    step_def.assignee_dynamic,
                )
                continue

            # Create the StepInstance with materialized assignee
            ApprovalStepInstance.objects.create(
                instance=instance,
                step_def=step_def,
                assignee=assignee,
                action=ApprovalStepInstance.ACTION_PENDING,
            )
            created_count += 1

        if created_count > 0:
            # Transition to in_review since at least one step was created
            instance.start_review()
            instance.current_step = 1
            instance.save(update_fields=['status', 'current_step'])
            logger.info(
                "Workflow instance %s created with %d steps, status=in_review",
                instance.id,
                created_count,
            )
        else:
            logger.warning(
                "Workflow instance %s created with 0 steps -- no reviewers assigned",
                instance.id,
            )

        # Trigger notification to first step assignee
        self._notify_first_assignee(instance)

        return instance

    def _build_context(self, obj) -> dict:
        """Build a context dictionary from a business object for condition evaluation."""
        context = {}
        # Copy simple field values
        for field in obj._meta.get_fields():
            if hasattr(field, 'attname'):
                val = getattr(obj, field.attname, None)
                if val is not None:
                    context[field.name] = val

        # Add common computed fields
        if hasattr(obj, 'amount'):
            context['amount'] = float(obj.amount)

        if hasattr(obj, 'customer'):
            customer = obj.customer
            context['customer_id'] = str(customer.id)
            context['customer_name'] = customer.name
            if hasattr(customer, 'level'):
                context['customer_level'] = customer.level

        if hasattr(obj, 'assigned_to'):
            context['assigned_to_id'] = str(obj.assigned_to.id)
            if hasattr(obj.assigned_to, 'department'):
                context['assigned_to_department'] = obj.assigned_to.department

        return context

    def _notify_first_assignee(self, instance: ApprovalInstance) -> None:
        """Create notification for the first step assignee."""
        try:
            first_step = instance.step_instances.filter(
                action=ApprovalStepInstance.ACTION_PENDING,
            ).order_by('step_def__step_order').first()

            if first_step:
                obj = instance.content_object
                title = f"Approval Required: {getattr(obj, 'title', 'Untitled')}"
                content = (
                    f"You have been assigned to review: {getattr(obj, 'title', 'Untitled')}. "
                    f"Step: {first_step.step_def.step_name}"
                )
                # Use create_notification service (Phase 5) with lazy import
                try:
                    from apps.notifications.services import create_notification
                    create_notification(
                        recipient=first_step.assignee,
                        type='approval_request',
                        title=title,
                        content=content,
                        related_object_type=instance.content_type.model,
                        related_object_id=str(instance.object_id),
                    )
                except ImportError:
                    logger.warning(
                        "Notification service not yet available (Phase 5 pending). "
                        "Skipping notification for workflow %s.",
                        instance.id,
                    )
        except Exception:
            logger.exception("Failed to create notification for first assignee")


class TransitionService:
    """Service for advancing and rejecting approval workflow steps."""

    @transaction.atomic
    def advance_step(
        self,
        step_instance: ApprovalStepInstance,
        user: 'User',  # noqa: F821
        comment: str = '',
    ) -> ApprovalInstance:
        """
        Approve a single step and advance the workflow.

        Args:
            step_instance: The step to approve.
            user: The user performing the approval (must be the assignee).
            comment: Optional approval comment.

        Returns:
            The updated ApprovalInstance.

        Raises:
            PermissionDenied: If user is not the assignee.
            TransitionNotAllowed: If FSM transition is invalid.
        """
        from django.core.exceptions import PermissionDenied

        if step_instance.assignee != user:
            raise PermissionDenied(
                f"User {user.id} is not the assignee of step {step_instance.id}. "
                f"Assignee is {step_instance.assignee.id}."
            )

        if step_instance.action != ApprovalStepInstance.ACTION_PENDING:
            raise ValueError(
                f"Step {step_instance.id} is not in pending state "
                f"(current: {step_instance.action})."
            )

        # Execute FSM transition on step
        step_instance.do_approve()
        step_instance.comment = comment
        step_instance.save()

        instance = step_instance.instance
        logger.info(
            "Step %d ('%s') approved by user %s in workflow %s",
            step_instance.step_def.step_order,
            step_instance.step_def.step_name,
            user.id,
            instance.id,
        )

        # Check if there are remaining pending steps
        remaining = instance.step_instances.filter(
            action=ApprovalStepInstance.ACTION_PENDING,
        ).exists()

        if not remaining:
            # All steps approved -- complete the workflow
            instance.approve()
            instance.save()
            self._on_workflow_approved(instance)
        else:
            # Advance current_step to the next pending step
            next_step = instance.step_instances.filter(
                action=ApprovalStepInstance.ACTION_PENDING,
            ).order_by('step_def__step_order').first()
            if next_step:
                instance.current_step = next_step.step_def.step_order
                instance.save(update_fields=['current_step'])
                self._notify_assignee(next_step)

        return instance

    @transaction.atomic
    def reject_step(
        self,
        step_instance: ApprovalStepInstance,
        user: 'User',  # noqa: F821
        comment: str = '',
    ) -> ApprovalInstance:
        """
        Reject a step and route per rejection_target configuration.

        Args:
            step_instance: The step being rejected.
            user: The user performing the rejection (must be the assignee).
            comment: Rejection reason (required for rejection).

        Returns:
            The updated ApprovalInstance.

        Raises:
            PermissionDenied: If user is not the assignee.
            ValueError: If comment is empty on rejection.
        """
        from django.core.exceptions import PermissionDenied

        if not comment.strip():
            raise ValueError("Rejection comment is required.")

        if step_instance.assignee != user:
            raise PermissionDenied(
                f"User {user.id} is not the assignee of step {step_instance.id}."
            )

        if step_instance.action != ApprovalStepInstance.ACTION_PENDING:
            raise ValueError(
                f"Step {step_instance.id} is not in pending state "
                f"(current: {step_instance.action})."
            )

        # Execute FSM transition on step
        step_instance.do_reject()
        step_instance.comment = comment
        step_instance.save()

        instance = step_instance.instance

        logger.info(
            "Step %d ('%s') rejected by user %s in workflow %s. Reason: %s",
            step_instance.step_def.step_order,
            step_instance.step_def.step_name,
            user.id,
            instance.id,
            comment,
        )

        # Route rejection per step_def.rejection_target
        rejection_target = step_instance.step_def.rejection_target

        if rejection_target == 'reject_to_originator':
            instance.reject()
            instance.save()
            self._notify_rejection_originator(instance, comment)
        elif rejection_target == 'reject_to_previous':
            instance.reject()
            instance.save()
            self._notify_rejection_originator(instance, comment)
        elif rejection_target == 'reject_to_specific_step':
            target_order = step_instance.step_def.rejection_target_step
            if target_order is not None:
                # Reset target step to pending
                self._reset_step_to_pending(instance, target_order)
                self._notify_rejection_originator(instance, comment)
            else:
                logger.warning(
                    "rejection_target is 'reject_to_specific_step' but "
                    "rejection_target_step is None for step %s",
                    step_instance.id,
                )
                instance.reject()
                instance.save()
                self._notify_rejection_originator(instance, comment)

        return instance

    def _reset_step_to_pending(
        self,
        instance: ApprovalInstance,
        target_step_order: int,
    ) -> None:
        """Reset a specific step back to pending for re-review."""
        target_step = instance.step_instances.filter(
            step_def__step_order=target_step_order,
        ).first()
        if target_step:
            target_step.action = ApprovalStepInstance.ACTION_PENDING
            target_step.acted_at = None
            target_step.comment = ''
            target_step.save()
            instance.current_step = target_step_order
            instance.save(update_fields=['current_step'])
            self._notify_assignee(target_step)

    def _on_workflow_approved(self, instance: ApprovalInstance) -> None:
        """Called when all steps in a workflow are approved."""
        obj = instance.content_object

        # Update related object status
        if hasattr(obj, 'status'):
            status_map = {
                'contract_approval': 'signed',
                'bid_review': 'approved',
            }
            new_status = status_map.get(instance.workflow_def.workflow_type)
            if new_status:
                obj.status = new_status
                obj.save(update_fields=['status', 'updated_at'])
                logger.info(
                    "Object %s (type=%s) status updated to '%s' "
                    "after workflow %s approval",
                    obj.id,
                    type(obj).__name__,
                    new_status,
                    instance.id,
                )

        # Notify initiator
        if instance.initiated_by:
            title = f"Approved: {getattr(obj, 'title', 'Untitled')}"
            content = (
                f"Your request for '{getattr(obj, 'title', 'Untitled')}' "
                f"has been fully approved."
            )
            try:
                from apps.notifications.services import create_notification
                create_notification(
                    recipient=instance.initiated_by,
                    type='approved',
                    title=title,
                    content=content,
                    related_object_type=instance.content_type.model,
                    related_object_id=str(instance.object_id),
                )
            except ImportError:
                logger.warning("Notification service not yet available. Skipping.")

    def _notify_rejection_originator(
        self,
        instance: ApprovalInstance,
        comment: str,
    ) -> None:
        """Notify the workflow initiator about rejection."""
        obj = instance.content_object

        # Update related object status back to draft
        if hasattr(obj, 'status'):
            obj.status = 'draft'
            obj.save(update_fields=['status', 'updated_at'])

        if instance.initiated_by:
            title = f"Rejected: {getattr(obj, 'title', 'Untitled')}"
            content = (
                f"Your request for '{getattr(obj, 'title', 'Untitled')}' "
                f"has been rejected. Reason: {comment}"
            )
            try:
                from apps.notifications.services import create_notification
                create_notification(
                    recipient=instance.initiated_by,
                    type='rejected',
                    title=title,
                    content=content,
                    related_object_type=instance.content_type.model,
                    related_object_id=str(instance.object_id),
                )
            except ImportError:
                logger.warning("Notification service not yet available. Skipping.")

    def _notify_assignee(
        self,
        step_instance: ApprovalStepInstance,
    ) -> None:
        """Notify a step assignee that their review is needed."""
        instance = step_instance.instance
        obj = instance.content_object

        if step_instance.assignee:
            title = f"Approval Required: {getattr(obj, 'title', 'Untitled')}"
            content = (
                f"Your review is needed for '{getattr(obj, 'title', 'Untitled')}'. "
                f"Step: {step_instance.step_def.step_name}"
            )
            try:
                from apps.notifications.services import create_notification
                create_notification(
                    recipient=step_instance.assignee,
                    type='approval_request',
                    title=title,
                    content=content,
                    related_object_type=instance.content_type.model,
                    related_object_id=str(instance.object_id),
                )
            except ImportError:
                logger.warning("Notification service not yet available. Skipping.")

    @transaction.atomic
    def cancel_workflow(
        self,
        instance: ApprovalInstance,
        user: 'User',  # noqa: F821
    ) -> ApprovalInstance:
        """
        Cancel an active workflow.

        Args:
            instance: The workflow instance to cancel.
            user: The user cancelling (must be the initiator).

        Returns:
            The updated ApprovalInstance.

        Raises:
            PermissionDenied: If user is not the initiator.
        """
        from django.core.exceptions import PermissionDenied

        if instance.initiated_by != user:
            raise PermissionDenied(
                f"User {user.id} is not the initiator of workflow {instance.id}."
            )

        instance.cancel()
        instance.save()

        # Update related object status back to draft
        obj = instance.content_object
        if hasattr(obj, 'status'):
            obj.status = 'draft'
            obj.save(update_fields=['status', 'updated_at'])

        logger.info(
            "Workflow %s cancelled by user %s",
            instance.id,
            user.id,
        )

        return instance
