from rest_framework import decorators, mixins, pagination, permissions, response, viewsets

from apps.notifications import filters, models, serializers


class NotificationPagination(pagination.PageNumberPagination):
    """Pagination for notifications: 50 items per page."""

    page_size = 50
    page_size_query_param = 'page_size'
    max_page_size = 100


class NotificationViewSet(
    mixins.ListModelMixin,
    viewsets.GenericViewSet,
):
    """
    Notifications for the current authenticated user.

    list:
        Return paginated notifications for request.user.
        Filters: is_read, type.
        Pagination: 50 items per page.

    mark_read:
        PATCH /notifications/{id}/read/
        Mark a single notification as read for the current user.

    mark_all_read:
        PATCH /notifications/mark-all-read/
        Mark all unread notifications as read for the current user.

    unread_count:
        GET /notifications/unread-count/
        Return the unread notification count for the current user.
    """

    serializer_class = serializers.NotificationSerializer
    permission_classes = [permissions.IsAuthenticated]
    pagination_class = NotificationPagination
    filterset_class = filters.NotificationFilter

    def get_queryset(self):
        """Only return notifications for the authenticated user."""
        return models.Notification.objects.filter(
            recipient=self.request.user,
        ).select_related('recipient')

    @decorators.action(
        detail=True,
        methods=['patch'],
        url_path='read',
        serializer_class=serializers.NotificationActionSerializer,
    )
    def mark_read(self, request, pk=None):
        """Mark a single notification as read."""
        notification = self.get_object()
        changed = notification.mark_as_read()
        return response.Response(
            {
                'status': 'ok',
                'changed': changed,
                'is_read': notification.is_read,
            },
        )

    @decorators.action(
        detail=False,
        methods=['patch'],
        url_path='mark-all-read',
        serializer_class=serializers.NotificationActionSerializer,
    )
    def mark_all_read(self, request):
        """Mark all unread notifications as read for the current user."""
        queryset = self.get_queryset().filter(is_read=False)
        updated_count = queryset.update(is_read=True)
        return response.Response(
            {
                'status': 'ok',
                'updated_count': updated_count,
            },
        )

    @decorators.action(
        detail=False,
        methods=['get'],
        url_path='unread-count',
        serializer_class=serializers.UnreadCountSerializer,
    )
    def unread_count(self, request):
        """Return the unread notification count for the current user."""
        count = self.get_queryset().filter(is_read=False).count()
        return response.Response({'unread_count': count})
