from rest_framework import serializers

from apps.notifications.models import Notification


class NotificationSerializer(serializers.ModelSerializer):
    """Serializer for notification list and detail."""

    type_display = serializers.CharField(
        source='get_type_display',
        read_only=True,
    )

    class Meta:
        model = Notification
        fields = [
            'id',
            'type',
            'type_display',
            'title',
            'content',
            'is_read',
            'related_object_type',
            'related_object_id',
            'created_at',
        ]
        read_only_fields = fields


class NotificationActionSerializer(serializers.Serializer):
    """Serializer for mark_read action -- intentionally empty body."""

    pass


class UnreadCountSerializer(serializers.Serializer):
    """Serializer for unread count response."""

    unread_count = serializers.IntegerField(read_only=True)
