import django_filters

from apps.notifications.models import Notification


class NotificationFilter(django_filters.FilterSet):
    """Filters for notification list endpoint."""

    is_read = django_filters.BooleanFilter(field_name='is_read')
    type = django_filters.CharFilter(field_name='type')

    class Meta:
        model = Notification
        fields = ['is_read', 'type']
