from django.db import models
from uuid7 import uuid7


class Notification(models.Model):
    """
    In-app notification for a user.

    Notifications are lightweight records. They do NOT use SoftDeleteModel
    because read notifications are archived periodically by a Celery Beat task
    (per Section 7.1 of the design doc). The related_object_type and
    related_object_id fields provide a cheap polymorphic link without
    ContentType/GenericForeignKey overhead.
    """

    id = models.UUIDField(primary_key=True, default=uuid7, editable=False)
    recipient = models.ForeignKey(
        'users.User',
        on_delete=models.CASCADE,
        related_name='notifications',
        db_index=True,
    )

    TYPE_APPROVAL_REQUEST = 'approval_request'
    TYPE_APPROVED = 'approved'
    TYPE_REJECTED = 'rejected'
    TYPE_EXPIRY_REMINDER = 'expiry_reminder'
    TYPE_TASK_ASSIGNED = 'task_assigned'
    TYPE_BID_DEADLINE = 'bid_deadline'

    TYPE_CHOICES = [
        (TYPE_APPROVAL_REQUEST, 'Approval Request'),
        (TYPE_APPROVED, 'Approved'),
        (TYPE_REJECTED, 'Rejected'),
        (TYPE_EXPIRY_REMINDER, 'Expiry Reminder'),
        (TYPE_TASK_ASSIGNED, 'Task Assigned'),
        (TYPE_BID_DEADLINE, 'Bid Deadline Reminder'),
    ]

    type = models.CharField(
        max_length=50,
        choices=TYPE_CHOICES,
        db_index=True,
    )
    title = models.CharField(max_length=300)
    content = models.TextField()
    is_read = models.BooleanField(default=False, db_index=True)
    related_object_type = models.CharField(
        max_length=50,
        blank=True,
        null=True,
        help_text=(
            "Polymorphic object type for deep-linking. "
            "Values: 'contract', 'bid', 'lead', 'approval'."
        ),
    )
    related_object_id = models.UUIDField(
        blank=True,
        null=True,
        help_text="UUID of the related object for deep-linking.",
    )
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['recipient', 'is_read']),
            models.Index(fields=['recipient', '-created_at']),
        ]
        verbose_name = 'Notification'

    def __str__(self) -> str:
        return f"Notification to {self.recipient_id}: {self.title}"

    def mark_as_read(self) -> bool:
        """Mark this notification as read. Returns True if state changed."""
        if not self.is_read:
            self.is_read = True
            self.save(update_fields=['is_read'])
            return True
        return False
