from django.test import TestCase

from apps.notifications.models import Notification
from apps.notifications.serializers import NotificationSerializer
from apps.users.tests.factories import UserFactory


class NotificationSerializerTest(TestCase):
    """Tests for NotificationSerializer."""

    def setUp(self):
        self.user = UserFactory()
        self.notification = Notification.objects.create(
            recipient=self.user,
            type=Notification.TYPE_APPROVAL_REQUEST,
            title='Contract Approval Required',
            content='Contract HT-2026-001 requires your approval.',
            related_object_type='contract',
            related_object_id='0190a1b2-c3d4-7e5f-8a6b-9c0d1e2f3a4b',
        )

    def test_serializer_outputs_all_fields(self):
        serializer = NotificationSerializer(self.notification)
        data = serializer.data
        self.assertIn('id', data)
        self.assertEqual(data['type'], 'approval_request')
        self.assertEqual(data['type_display'], 'Approval Request')
        self.assertEqual(data['title'], 'Contract Approval Required')
        self.assertEqual(data['content'], 'Contract HT-2026-001 requires your approval.')
        self.assertFalse(data['is_read'])
        self.assertEqual(data['related_object_type'], 'contract')
        self.assertEqual(data['related_object_id'], '0190a1b2-c3d4-7e5f-8a6b-9c0d1e2f3a4b')
        self.assertIn('created_at', data)

    def test_serializer_all_fields_are_read_only(self):
        """NotificationSerializer should not allow writes through it."""
        serializer = NotificationSerializer(data={})
        self.assertEqual(
            set(serializer.fields.keys()),
            {
                'id', 'type', 'type_display', 'title', 'content',
                'is_read', 'related_object_type', 'related_object_id',
                'created_at',
            },
        )
        for field_name, field in serializer.fields.items():
            self.assertTrue(
                field.read_only,
                f"Field '{field_name}' should be read-only",
            )

    def test_type_display_maps_correctly(self):
        for type_value, display_text in Notification.TYPE_CHOICES:
            n = Notification.objects.create(
                recipient=self.user,
                type=type_value,
                title='Test',
                content='Test content.',
            )
            serializer = NotificationSerializer(n)
            self.assertEqual(serializer.data['type_display'], display_text)
