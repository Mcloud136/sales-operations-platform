from uuid import uuid4

from django.test import TestCase

from apps.notifications.models import Notification
from apps.notifications.services import (
    create_notification,
    notify_approval_approved,
    notify_approval_rejected,
    notify_approval_request,
    notify_bid_deadline,
    notify_contract_expiry,
    notify_task_assigned,
)
from apps.users.tests.factories import UserFactory


class CreateNotificationServiceTest(TestCase):
    """Tests for the create_notification() service function."""

    def setUp(self):
        self.user = UserFactory()
        self.contract_id = uuid4()

    def test_create_basic_notification(self):
        notification = create_notification(
            recipient=self.user,
            type=Notification.TYPE_APPROVAL_REQUEST,
            title='Test Notification',
            content='Test content.',
        )
        self.assertIsNotNone(notification.id)
        self.assertEqual(notification.recipient, self.user)
        self.assertEqual(notification.type, Notification.TYPE_APPROVAL_REQUEST)
        self.assertEqual(notification.title, 'Test Notification')
        self.assertEqual(notification.content, 'Test content.')
        self.assertFalse(notification.is_read)
        self.assertIsNone(notification.related_object_type)
        self.assertIsNone(notification.related_object_id)

    def test_create_notification_with_related_object(self):
        notification = create_notification(
            recipient=self.user,
            type=Notification.TYPE_APPROVED,
            title='Contract Approved',
            content='Approved!',
            related_object_type='contract',
            related_object_id=self.contract_id,
        )
        self.assertEqual(notification.related_object_type, 'contract')
        self.assertEqual(notification.related_object_id, self.contract_id)

    def test_create_notification_is_saved_to_db(self):
        create_notification(
            recipient=self.user,
            type=Notification.TYPE_EXPIRY_REMINDER,
            title='Expiry',
            content='Expiring soon.',
        )
        self.assertEqual(Notification.objects.filter(recipient=self.user).count(), 1)

    def test_create_notification_all_types(self):
        """Verify create_notification works for every type constant."""
        for type_value, _ in Notification.TYPE_CHOICES:
            notification = create_notification(
                recipient=self.user,
                type=type_value,
                title=f'Test {type_value}',
                content='Content',
            )
            self.assertEqual(notification.type, type_value)


class NotifyApprovalRequestTest(TestCase):
    """Tests for notify_approval_request helper."""

    def setUp(self):
        self.user = UserFactory()
        self.contract_id = uuid4()

    def test_creates_approval_request_notification(self):
        notification = notify_approval_request(
            recipient=self.user,
            contract_title='HT-2026-001',
            contract_id=self.contract_id,
        )
        self.assertEqual(notification.type, Notification.TYPE_APPROVAL_REQUEST)
        self.assertIn('Approval Request', notification.title)
        self.assertIn('HT-2026-001', notification.title)
        self.assertEqual(notification.related_object_type, 'contract')
        self.assertEqual(notification.related_object_id, self.contract_id)


class NotifyApprovalApprovedTest(TestCase):
    """Tests for notify_approval_approved helper."""

    def setUp(self):
        self.user = UserFactory()
        self.contract_id = uuid4()

    def test_creates_approved_notification(self):
        notification = notify_approval_approved(
            recipient=self.user,
            contract_title='HT-2026-001',
            contract_id=self.contract_id,
        )
        self.assertEqual(notification.type, Notification.TYPE_APPROVED)
        self.assertIn('Approved', notification.title)
        self.assertEqual(notification.related_object_type, 'contract')
        self.assertEqual(notification.related_object_id, self.contract_id)


class NotifyApprovalRejectedTest(TestCase):
    """Tests for notify_approval_rejected helper."""

    def setUp(self):
        self.user = UserFactory()
        self.contract_id = uuid4()

    def test_creates_rejected_notification(self):
        notification = notify_approval_rejected(
            recipient=self.user,
            contract_title='HT-2026-001',
            contract_id=self.contract_id,
        )
        self.assertEqual(notification.type, Notification.TYPE_REJECTED)
        self.assertIn('Rejected', notification.title)
        self.assertEqual(notification.related_object_type, 'contract')
        self.assertEqual(notification.related_object_id, self.contract_id)


class NotifyContractExpiryTest(TestCase):
    """Tests for notify_contract_expiry helper."""

    def setUp(self):
        self.user = UserFactory()
        self.contract_id = uuid4()

    def test_expiry_urgent_when_7_days(self):
        notification = notify_contract_expiry(
            recipient=self.user,
            contract_title='HT-2026-001',
            contract_id=self.contract_id,
            days_until_expiry=7,
        )
        self.assertEqual(notification.type, Notification.TYPE_EXPIRY_REMINDER)
        self.assertIn('URGENT', notification.title)
        self.assertIn('7 days', notification.content)

    def test_expiry_warning_when_30_days(self):
        notification = notify_contract_expiry(
            recipient=self.user,
            contract_title='HT-2026-001',
            contract_id=self.contract_id,
            days_until_expiry=30,
        )
        self.assertIn('Warning', notification.title)
        self.assertIn('30 days', notification.content)

    def test_expiry_reminder_when_60_days(self):
        notification = notify_contract_expiry(
            recipient=self.user,
            contract_title='HT-2026-001',
            contract_id=self.contract_id,
            days_until_expiry=60,
        )
        self.assertIn('Reminder', notification.title)
        self.assertIn('60 days', notification.content)


class NotifyBidDeadlineTest(TestCase):
    """Tests for notify_bid_deadline helper."""

    def setUp(self):
        self.user = UserFactory()
        self.bid_id = uuid4()

    def test_creates_bid_deadline_notification(self):
        notification = notify_bid_deadline(
            recipient=self.user,
            bid_title='City Hospital Equipment Supply',
            bid_id=self.bid_id,
            days_until_deadline=3,
        )
        self.assertEqual(notification.type, Notification.TYPE_BID_DEADLINE)
        self.assertIn('Bid Deadline', notification.title)
        self.assertIn('3 days', notification.content)
        self.assertEqual(notification.related_object_type, 'bid')
        self.assertEqual(notification.related_object_id, self.bid_id)


class NotifyTaskAssignedTest(TestCase):
    """Tests for notify_task_assigned helper."""

    def setUp(self):
        self.user = UserFactory()
        self.lead_id = uuid4()

    def test_creates_task_assigned_notification(self):
        notification = notify_task_assigned(
            recipient=self.user,
            task_description='Please follow up with the client by Friday.',
            related_object_type='lead',
            related_object_id=self.lead_id,
        )
        self.assertEqual(notification.type, Notification.TYPE_TASK_ASSIGNED)
        self.assertEqual(notification.title, 'New Task Assigned')
        self.assertEqual(notification.related_object_type, 'lead')
        self.assertEqual(notification.related_object_id, self.lead_id)

    def test_task_assigned_without_related_object(self):
        notification = notify_task_assigned(
            recipient=self.user,
            task_description='General reminder.',
        )
        self.assertIsNone(notification.related_object_type)
        self.assertIsNone(notification.related_object_id)
