from django.test import TestCase

from apps.notifications.models import Notification
from apps.users.tests.factories import UserFactory


class NotificationModelTest(TestCase):
    """Tests for the Notification model."""

    def setUp(self):
        self.user = UserFactory()

    def test_create_notification(self):
        notification = Notification.objects.create(
            recipient=self.user,
            type=Notification.TYPE_APPROVAL_REQUEST,
            title='Contract Approval Required',
            content='Contract HT-2026-001 requires your approval.',
        )
        self.assertEqual(notification.recipient, self.user)
        self.assertEqual(notification.type, Notification.TYPE_APPROVAL_REQUEST)
        self.assertEqual(notification.title, 'Contract Approval Required')
        self.assertFalse(notification.is_read)
        self.assertIsNotNone(notification.id)

    def test_default_is_read_is_false(self):
        notification = Notification.objects.create(
            recipient=self.user,
            type=Notification.TYPE_APPROVED,
            title='Approved',
            content='Your contract has been approved.',
        )
        self.assertFalse(notification.is_read)

    def test_mark_as_read_changes_state(self):
        notification = Notification.objects.create(
            recipient=self.user,
            type=Notification.TYPE_REJECTED,
            title='Rejected',
            content='Your contract was rejected.',
        )
        changed = notification.mark_as_read()
        self.assertTrue(changed)
        self.assertTrue(notification.is_read)
        notification.refresh_from_db()
        self.assertTrue(notification.is_read)

    def test_mark_as_read_idempotent(self):
        notification = Notification.objects.create(
            recipient=self.user,
            type=Notification.TYPE_EXPIRY_REMINDER,
            title='Expiring Soon',
            content='Contract expires in 7 days.',
            is_read=True,
        )
        changed = notification.mark_as_read()
        self.assertFalse(changed)

    def test_related_object_fields_optional(self):
        notification = Notification.objects.create(
            recipient=self.user,
            type=Notification.TYPE_BID_DEADLINE,
            title='Bid Deadline Approaching',
            content='Bid deadline is tomorrow.',
            related_object_type='bid',
        )
        self.assertIsNone(notification.related_object_id)
        self.assertEqual(notification.related_object_type, 'bid')

    def test_str_representation(self):
        notification = Notification.objects.create(
            recipient=self.user,
            type=Notification.TYPE_TASK_ASSIGNED,
            title='Task Assigned',
            content='You have been assigned a task.',
        )
        expected = f"Notification to {self.user.id}: Task Assigned"
        self.assertEqual(str(notification), expected)

    def test_uuid7_primary_key(self):
        """Ensure notification ID is a UUIDv7 (timestamp-ordered)."""
        notification = Notification.objects.create(
            recipient=self.user,
            type=Notification.TYPE_APPROVAL_REQUEST,
            title='UUID7 Test',
            content='Testing UUIDv7 ordering.',
        )
        # UUIDv7 starts with a timestamp prefix; check version bits
        self.assertEqual(notification.id.version, 7)

    def test_type_choices(self):
        """Ensure all type constants are valid choices."""
        for choice_value, _ in Notification.TYPE_CHOICES:
            notification = Notification.objects.create(
                recipient=self.user,
                type=choice_value,
                title=f'Test {choice_value}',
                content='Content',
            )
            self.assertEqual(notification.type, choice_value)

    def test_ordering_by_created_at_desc(self):
        n1 = Notification.objects.create(
            recipient=self.user,
            type=Notification.TYPE_APPROVAL_REQUEST,
            title='First',
            content='First notification.',
        )
        n2 = Notification.objects.create(
            recipient=self.user,
            type=Notification.TYPE_APPROVED,
            title='Second',
            content='Second notification.',
        )
        qs = list(Notification.objects.filter(recipient=self.user))
        self.assertEqual(qs[0].id, n2.id)
        self.assertEqual(qs[1].id, n1.id)
