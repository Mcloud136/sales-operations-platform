from django.test import TestCase
from django.urls import reverse
from rest_framework import status
from rest_framework.test import APIClient, APITestCase

from apps.notifications.models import Notification
from apps.users.tests.factories import UserFactory


class NotificationViewSetTest(APITestCase):
    """Tests for the NotificationViewSet API endpoints."""

    def setUp(self):
        self.user_a = UserFactory(username='alice')
        self.user_b = UserFactory(username='bob')

        # Create notifications for user A
        self.notif_a1 = Notification.objects.create(
            recipient=self.user_a,
            type=Notification.TYPE_APPROVAL_REQUEST,
            title='Approval Required',
            content='Please review contract HT-2026-001.',
            related_object_type='contract',
        )
        self.notif_a2 = Notification.objects.create(
            recipient=self.user_a,
            type=Notification.TYPE_APPROVED,
            title='Contract Approved',
            content='Contract HT-2026-002 has been approved.',
            related_object_type='contract',
        )
        self.notif_a_read = Notification.objects.create(
            recipient=self.user_a,
            type=Notification.TYPE_REJECTED,
            title='Contract Rejected',
            content='Contract HT-2026-003 was rejected.',
            is_read=True,
        )

        # Create notification for user B
        self.notif_b1 = Notification.objects.create(
            recipient=self.user_b,
            type=Notification.TYPE_TASK_ASSIGNED,
            title='Task Assigned',
            content='You have a new task.',
        )

        self.client = APIClient()

    def _auth_as(self, user):
        """Authenticate the API client as the given user."""
        self.client.force_authenticate(user=user)

    # --- List tests ---

    def test_list_returns_own_notifications_only(self):
        """User A should only see their own notifications, not User B's."""
        self._auth_as(self.user_a)
        url = reverse('notifications:notification-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        notification_ids = [n['id'] for n in response.data['results']]
        self.assertIn(str(self.notif_a1.id), notification_ids)
        self.assertIn(str(self.notif_a2.id), notification_ids)
        self.assertIn(str(self.notif_a_read.id), notification_ids)
        self.assertNotIn(str(self.notif_b1.id), notification_ids)

    def test_list_unauthenticated_returns_401(self):
        url = reverse('notifications:notification-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_list_pagination_default_50(self):
        self._auth_as(self.user_a)
        url = reverse('notifications:notification-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('results', response.data)
        # 3 notifications for user_a, all fit in one page
        self.assertEqual(len(response.data['results']), 3)

    # --- Filter tests ---

    def test_filter_is_read_true(self):
        self._auth_as(self.user_a)
        url = reverse('notifications:notification-list')
        response = self.client.get(url, {'is_read': 'true'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['id'], str(self.notif_a_read.id))

    def test_filter_is_read_false(self):
        self._auth_as(self.user_a)
        url = reverse('notifications:notification-list')
        response = self.client.get(url, {'is_read': 'false'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 2)

    def test_filter_by_type(self):
        self._auth_as(self.user_a)
        url = reverse('notifications:notification-list')
        response = self.client.get(url, {'type': 'approval_request'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 1)
        self.assertEqual(results[0]['type'], 'approval_request')

    def test_filter_combined_is_read_and_type(self):
        self._auth_as(self.user_a)
        url = reverse('notifications:notification-list')
        # User A has no read notifications of type approval_request
        response = self.client.get(url, {'is_read': 'true', 'type': 'approval_request'})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        results = response.data['results']
        self.assertEqual(len(results), 0)

    # --- mark_read action tests ---

    def test_mark_read_success(self):
        self._auth_as(self.user_a)
        url = reverse(
            'notifications:notification-mark-read',
            kwargs={'pk': self.notif_a1.id},
        )
        response = self.client.patch(url, {})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertEqual(data['status'], 'ok')
        self.assertTrue(data['changed'])
        self.assertTrue(data['is_read'])
        self.notif_a1.refresh_from_db()
        self.assertTrue(self.notif_a1.is_read)

    def test_mark_read_idempotent(self):
        """Marking an already-read notification returns changed=False."""
        self._auth_as(self.user_a)
        url = reverse(
            'notifications:notification-mark-read',
            kwargs={'pk': self.notif_a_read.id},
        )
        response = self.client.patch(url, {})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertFalse(response.json()['changed'])

    def test_mark_read_other_users_notification_returns_404(self):
        """User A cannot mark User B's notification as read."""
        self._auth_as(self.user_a)
        url = reverse(
            'notifications:notification-mark-read',
            kwargs={'pk': self.notif_b1.id},
        )
        response = self.client.patch(url, {})
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    # --- mark_all_read action tests ---

    def test_mark_all_read_success(self):
        self._auth_as(self.user_a)
        # Verify initial unread count
        unread = Notification.objects.filter(
            recipient=self.user_a, is_read=False,
        ).count()
        self.assertEqual(unread, 2)

        url = reverse('notifications:notification-mark-all-read')
        response = self.client.patch(url, {})
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        data = response.json()
        self.assertEqual(data['status'], 'ok')
        self.assertEqual(data['updated_count'], 2)

        # Verify all are now read
        remaining_unread = Notification.objects.filter(
            recipient=self.user_a, is_read=False,
        ).count()
        self.assertEqual(remaining_unread, 0)

    def test_mark_all_read_does_not_affect_other_users(self):
        """mark_all_read only affects the authenticated user's notifications."""
        self._auth_as(self.user_a)
        url = reverse('notifications:notification-mark-all-read')
        self.client.patch(url, {})

        # User B's notification should remain unread
        self.notif_b1.refresh_from_db()
        self.assertFalse(self.notif_b1.is_read)

    # --- unread_count action tests ---

    def test_unread_count(self):
        self._auth_as(self.user_a)
        url = reverse('notifications:notification-unread-count')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        # 2 unread for user_a
        self.assertEqual(response.json()['unread_count'], 2)

    def test_unread_count_after_mark_all_read(self):
        self._auth_as(self.user_a)
        url = reverse('notifications:notification-mark-all-read')
        self.client.patch(url, {})

        url = reverse('notifications:notification-unread-count')
        response = self.client.get(url)
        self.assertEqual(response.json()['unread_count'], 0)

    # --- Isolation / security tests ---

    def test_cannot_retrieve_other_users_notification(self):
        """User A cannot GET User B's notification detail."""
        self._auth_as(self.user_a)
        # NotificationViewSet only has list, no retrieve -- so this is
        # implicitly tested by list filtering, but let's confirm 404 via mark_read
        url = reverse(
            'notifications:notification-mark-read',
            kwargs={'pk': self.notif_b1.id},
        )
        response = self.client.patch(url, {})
        self.assertEqual(response.status_code, status.HTTP_404_NOT_FOUND)

    def test_no_create_or_destroy_endpoints(self):
        """Notifications are system-generated only. No create/destroy."""
        self._auth_as(self.user_a)
        list_url = reverse('notifications:notification-list')

        # POST should not be allowed
        response = self.client.post(list_url, {
            'type': 'approval_request',
            'title': 'Hacked',
            'content': 'Should not work',
        })
        self.assertIn(
            response.status_code,
            [status.HTTP_405_METHOD_NOT_ALLOWED, status.HTTP_403_FORBIDDEN],
        )

        # DELETE should not be allowed
        response = self.client.delete(
            reverse(
                'notifications:notification-detail',
                kwargs={'pk': self.notif_a1.id},
            ),
        )
        self.assertIn(
            response.status_code,
            [status.HTTP_405_METHOD_NOT_ALLOWED, status.HTTP_404_NOT_FOUND],
        )
