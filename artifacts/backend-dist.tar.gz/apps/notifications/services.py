"""
Notification creation service.

Provides a single helper function for all notification creation throughout
the application. Notifications are always created system-side (never from
user API input).
"""

import logging
from typing import Optional
from uuid import UUID

from apps.notifications.models import Notification

logger = logging.getLogger(__name__)


def create_notification(
    recipient,
    type: str,
    title: str,
    content: str,
    related_object_type: Optional[str] = None,
    related_object_id: Optional[UUID] = None,
) -> Notification:
    """
    Create a notification for a user.

    This is the ONLY function through which notifications should be created.
    It is called by:
    - Approval workflow engine (approval_request, approved, rejected)
    - Celery Beat contract expiry check (expiry_reminder)
    - Celery Beat bid deadline reminder (bid_deadline)
    - Any future notification source

    Args:
        recipient: The User who will receive this notification.
        type: One of Notification.TYPE_* constants.
        title: Short title for the notification.
        content: Full message body.
        related_object_type: Optional type string (e.g., 'contract', 'bid', 'lead', 'approval').
        related_object_id: Optional UUID of the related object.

    Returns:
        The created Notification instance.
    """
    notification = Notification.objects.create(
        recipient=recipient,
        type=type,
        title=title,
        content=content,
        related_object_type=related_object_type,
        related_object_id=related_object_id,
    )
    logger.info(
        "Notification created: id=%s recipient=%s type=%s title='%s'",
        notification.id,
        recipient.id,
        type,
        title,
    )
    return notification


def notify_approval_request(recipient, contract_title: str, contract_id: UUID) -> Notification:
    """Helper: notify a user that an approval is requested from them."""
    return create_notification(
        recipient=recipient,
        type=Notification.TYPE_APPROVAL_REQUEST,
        title=f'Approval Request: {contract_title}',
        content=f'A new contract "{contract_title}" requires your approval. Please review and act.',
        related_object_type='contract',
        related_object_id=contract_id,
    )


def notify_approval_approved(recipient, contract_title: str, contract_id: UUID) -> Notification:
    """Helper: notify the contract owner that their contract has been approved."""
    return create_notification(
        recipient=recipient,
        type=Notification.TYPE_APPROVED,
        title=f'Approved: {contract_title}',
        content=f'Your contract "{contract_title}" has been fully approved. It is now ready for signing.',
        related_object_type='contract',
        related_object_id=contract_id,
    )


def notify_approval_rejected(recipient, contract_title: str, contract_id: UUID) -> Notification:
    """Helper: notify the contract owner that their contract has been rejected."""
    return create_notification(
        recipient=recipient,
        type=Notification.TYPE_REJECTED,
        title=f'Rejected: {contract_title}',
        content=f'Your contract "{contract_title}" has been rejected. Please review the feedback and resubmit if needed.',
        related_object_type='contract',
        related_object_id=contract_id,
    )


def notify_contract_expiry(
    recipient,
    contract_title: str,
    contract_id: UUID,
    days_until_expiry: int,
) -> Notification:
    """Helper: notify about an approaching contract expiration."""
    if days_until_expiry <= 7:
        urgency = 'URGENT'
    elif days_until_expiry <= 30:
        urgency = 'Warning'
    else:
        urgency = 'Reminder'

    return create_notification(
        recipient=recipient,
        type=Notification.TYPE_EXPIRY_REMINDER,
        title=f'[{urgency}] Contract Expiring: {contract_title}',
        content=(
            f'Contract "{contract_title}" expires in {days_until_expiry} days. '
            f'Please take appropriate action to renew or extend.'
        ),
        related_object_type='contract',
        related_object_id=contract_id,
    )


def notify_bid_deadline(
    recipient,
    bid_title: str,
    bid_id: UUID,
    days_until_deadline: int,
) -> Notification:
    """Helper: notify about an approaching bid deadline."""
    return create_notification(
        recipient=recipient,
        type=Notification.TYPE_BID_DEADLINE,
        title=f'Bid Deadline Approaching: {bid_title}',
        content=(
            f'Bid "{bid_title}" deadline is in {days_until_deadline} days. '
            f'Please ensure all documents are prepared and submitted on time.'
        ),
        related_object_type='bid',
        related_object_id=bid_id,
    )


def notify_task_assigned(
    recipient,
    task_description: str,
    related_object_type: Optional[str] = None,
    related_object_id: Optional[UUID] = None,
) -> Notification:
    """Helper: notify a user that a task has been assigned to them."""
    return create_notification(
        recipient=recipient,
        type=Notification.TYPE_TASK_ASSIGNED,
        title='New Task Assigned',
        content=task_description,
        related_object_type=related_object_type,
        related_object_id=related_object_id,
    )
