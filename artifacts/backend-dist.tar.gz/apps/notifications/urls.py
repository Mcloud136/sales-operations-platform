from django.urls import include, path
from rest_framework.routers import SimpleRouter

from apps.notifications import views

app_name = 'notifications'

router = SimpleRouter()
router.register('', views.NotificationViewSet, basename='notification')

urlpatterns = [
    path('', include(router.urls)),
]
