"""ViewSet classes for the Bid/Tender Management module."""

from rest_framework import viewsets, mixins, status, parsers
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from django.http import FileResponse

from apps.common.mixins import DataIsolationMixin
from apps.common.permissions import IsRoleAllowed
from apps.common.pagination import CursorPagination

from apps.bids.models import BidProject, Document
from apps.bids.serializers import (
    BidProjectListSerializer,
    BidProjectDetailSerializer,
    BidProjectCreateSerializer,
    BidProjectUpdateSerializer,
    DocumentSerializer,
    DocumentUploadSerializer,
)
from apps.bids.filters import BidProjectFilterSet


# ---------------------------------------------------------------------------
# Document ViewSet (nested under BidProject)
# ---------------------------------------------------------------------------

class DocumentViewSet(
    mixins.CreateModelMixin,
    mixins.ListModelMixin,
    mixins.RetrieveModelMixin,
    mixins.DestroyModelMixin,
    viewsets.GenericViewSet,
):
    """ViewSet for managing documents within a bid project.

    Nested under /api/v1/bids/{bid_pk}/documents/.
    The bid_project is injected from the URL kwargs into the serializer context.
    """

    permission_classes = [IsAuthenticated, IsRoleAllowed]
    allowed_roles = ["system_admin", "sales_manager", "sales_rep"]
    parser_classes = [parsers.MultiPartParser, parsers.FormParser]
    pagination_class = None  # Document lists are typically small

    def get_queryset(self):
        """Return documents for the parent bid project."""
        bid_pk = self.kwargs.get("bid_pk")
        qs = Document.objects.filter(bid_project__id=bid_pk).select_related("uploaded_by")
        return qs

    def get_serializer_class(self):
        if self.action == "create":
            return DocumentUploadSerializer
        return DocumentSerializer

    def get_serializer_context(self):
        """Inject bid_project into serializer context."""
        context = super().get_serializer_context()
        bid_pk = self.kwargs.get("bid_pk")
        try:
            bid_project = BidProject.all_objects.get(pk=bid_pk)
            context["bid_project"] = bid_project
        except BidProject.DoesNotExist:
            pass
        return context

    @action(detail=True, methods=["get"], url_path="download")
    def download(self, request, bid_pk=None, pk=None):
        """Return the file content as a downloadable response."""
        try:
            document = self.get_queryset().get(pk=pk)
        except Document.DoesNotExist:
            return Response(
                {"detail": "Document not found."},
                status=status.HTTP_404_NOT_FOUND,
            )

        file_handle = document.file.open("rb")
        response = FileResponse(file_handle, content_type="application/octet-stream")
        response["Content-Disposition"] = f'attachment; filename="{document.file_name}"'
        response["X-Document-Version"] = str(document.version)
        return response


# ---------------------------------------------------------------------------
# BidProject ViewSet
# ---------------------------------------------------------------------------

class BidProjectViewSet(
    DataIsolationMixin,
    viewsets.ModelViewSet,
):
    """ViewSet for BidProject CRUD operations.

    Uses DataIsolationMixin to enforce automatic data isolation.
    List endpoint returns lightweight BidProjectListSerializer.
    Detail endpoint returns full BidProjectDetailSerializer.
    Create uses BidProjectCreateSerializer (sets created_by from request).
    Update uses BidProjectUpdateSerializer (partial update support).
    """

    permission_classes = [IsAuthenticated, IsRoleAllowed]
    allowed_roles = ["system_admin", "sales_manager", "sales_rep"]
    pagination_class = CursorPagination
    filterset_class = BidProjectFilterSet

    def get_queryset(self):
        """Return BidProject queryset with customer prefetched."""
        qs = super().get_queryset()
        return qs.select_related("customer", "created_by")

    def get_serializer_class(self):
        """Return appropriate serializer based on action."""
        if self.action == "list":
            return BidProjectListSerializer
        if self.action == "retrieve":
            return BidProjectDetailSerializer
        if self.action == "create":
            return BidProjectCreateSerializer
        if self.action in ("update", "partial_update"):
            return BidProjectUpdateSerializer
        return BidProjectDetailSerializer

    def perform_create(self, serializer):
        """Set created_by to the authenticated user."""
        serializer.save(created_by=self.request.user)

    def perform_destroy(self, instance):
        """Soft-delete instead of physical deletion."""
        instance.soft_delete()
