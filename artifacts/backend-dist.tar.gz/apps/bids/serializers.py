"""Serializers for the Bid/Tender Management module."""

from rest_framework import serializers
from django.utils import timezone

from apps.bids.models import BidProject, Document, BID_STATUS_CHOICES


# ---------------------------------------------------------------------------
# Document Serializers
# ---------------------------------------------------------------------------

class DocumentSerializer(serializers.ModelSerializer):
    """Serializer for read-only document representation."""

    uploaded_by_name = serializers.CharField(
        source="uploaded_by.username",
        read_only=True,
    )
    file_size = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = Document
        fields = (
            "id",
            "bid_project",
            "contract",
            "file",
            "file_name",
            "file_type",
            "version",
            "uploaded_by",
            "uploaded_by_name",
            "uploaded_at",
            "file_size",
        )
        read_only_fields = (
            "id",
            "bid_project",
            "contract",
            "uploaded_by",
            "uploaded_at",
        )

    def get_file_size(self, obj):
        """Return human-readable file size."""
        try:
            size = obj.file.size
            if size < 1024:
                return f"{size} B"
            elif size < 1024 * 1024:
                return f"{size / 1024:.1f} KB"
            else:
                return f"{size / (1024 * 1024):.1f} MB"
        except (OSError, AttributeError):
            return "N/A"


class DocumentUploadSerializer(serializers.ModelSerializer):
    """Serializer for document upload (create-only).

    The bid_project is injected from the URL context by the ViewSet.
    Version is auto-calculated based on existing documents with the same
    file_name and file_type within the same parent.
    """

    class Meta:
        model = Document
        fields = ("file", "file_name", "file_type")

    def validate_file(self, value):
        """Validate file type and size."""
        # Max 50 MB
        max_size = 50 * 1024 * 1024
        if value.size > max_size:
            raise serializers.ValidationError(
                f"File size exceeds the 50 MB limit ({value.size / (1024 * 1024):.1f} MB)."
            )
        return value

    def validate_file_name(self, value):
        """Validate file name is not empty."""
        if not value or not value.strip():
            raise serializers.ValidationError("File name is required.")
        return value.strip()

    def create(self, validated_data):
        """Create document with auto-calculated version number."""
        bid_project = self.context.get("bid_project")
        file_name = validated_data["file_name"]
        file_type = validated_data["file_type"]

        # Calculate next version
        latest = Document.objects.filter(
            bid_project=bid_project,
            file_name=file_name,
            file_type=file_type,
        ).order_by("-version").first()

        version = (latest.version + 1) if latest else 1

        request = self.context.get("request")
        uploaded_by = request.user if request and hasattr(request, "user") else None

        doc = Document(
            bid_project=bid_project,
            contract=None,
            version=version,
            uploaded_by=uploaded_by,
            **validated_data,
        )
        doc.full_clean()
        doc.save()
        return doc


# ---------------------------------------------------------------------------
# BidProject Serializers
# ---------------------------------------------------------------------------

class BidProjectListSerializer(serializers.ModelSerializer):
    """Lightweight serializer for bid list views."""

    customer_name = serializers.CharField(
        source="customer.name",
        read_only=True,
    )
    status_display = serializers.CharField(
        source="get_status_display",
        read_only=True,
    )
    created_by_name = serializers.CharField(
        source="created_by.username",
        read_only=True,
    )
    days_remaining = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = BidProject
        fields = (
            "id",
            "title",
            "customer",
            "customer_name",
            "bidding_org",
            "bid_deadline",
            "status",
            "status_display",
            "estimated_amount",
            "created_by",
            "created_by_name",
            "created_at",
            "days_remaining",
        )
        read_only_fields = fields

    def get_days_remaining(self, obj):
        """Calculate days remaining until bid deadline.

        Returns positive number for future deadlines, 0 for today,
        and negative for past deadlines.
        """
        now = timezone.now()
        delta = obj.bid_deadline - now
        return max(0, delta.days)


class BidProjectDetailSerializer(serializers.ModelSerializer):
    """Full serializer for bid detail views."""

    customer_name = serializers.CharField(
        source="customer.name",
        read_only=True,
    )
    status_display = serializers.CharField(
        source="get_status_display",
        read_only=True,
    )
    created_by_name = serializers.CharField(
        source="created_by.username",
        read_only=True,
    )
    days_remaining = serializers.SerializerMethodField(read_only=True)
    assigned_team = serializers.PrimaryKeyRelatedField(
        many=True,
        queryset=None,  # set dynamically in __init__
        required=False,
    )
    document_count = serializers.SerializerMethodField(read_only=True)

    class Meta:
        model = BidProject
        fields = (
            "id",
            "title",
            "customer",
            "customer_name",
            "bidding_org",
            "bid_deadline",
            "bid_opening_date",
            "status",
            "status_display",
            "estimated_amount",
            "description",
            "assigned_team",
            "created_by",
            "created_by_name",
            "created_at",
            "updated_at",
            "days_remaining",
            "document_count",
        )
        read_only_fields = (
            "id",
            "created_by",
            "created_at",
            "updated_at",
        )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Set queryset dynamically so validation works
        self.fields["assigned_team"].queryset = self._get_user_queryset()

    def _get_user_queryset(self):
        """Return User queryset, accessible by current context user's isolation."""
        from apps.users.models import User
        return User.objects.all()

    def get_days_remaining(self, obj):
        """Calculate days remaining until bid deadline."""
        now = timezone.now()
        delta = obj.bid_deadline - now
        return max(0, delta.days)

    def get_document_count(self, obj):
        """Return count of documents for this bid project."""
        return obj.documents.count()


class BidProjectCreateSerializer(serializers.ModelSerializer):
    """Serializer for creating a new bid project."""

    customer_name = serializers.CharField(
        source="customer.name",
        read_only=True,
    )

    class Meta:
        model = BidProject
        fields = (
            "id",
            "title",
            "customer",
            "customer_name",
            "bidding_org",
            "bid_deadline",
            "bid_opening_date",
            "status",
            "estimated_amount",
            "description",
        )
        read_only_fields = ("id", "customer_name")

    def validate_bid_deadline(self, value):
        """Deadline should not be in the past (unless explicitly allowed)."""
        if value and value < timezone.now():
            raise serializers.ValidationError("Bid deadline cannot be in the past.")
        return value


class BidProjectUpdateSerializer(serializers.ModelSerializer):
    """Serializer for updating an existing bid project."""

    class Meta:
        model = BidProject
        fields = (
            "title",
            "bidding_org",
            "bid_deadline",
            "bid_opening_date",
            "status",
            "estimated_amount",
            "description",
            "assigned_team",
        )

    def validate_bid_deadline(self, value):
        """Allow past deadlines on update (bid may have already passed)."""
        return value
