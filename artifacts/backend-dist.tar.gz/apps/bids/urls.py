"""URL routing for the Bid/Tender Management module."""

from django.urls import path, include
from rest_framework.routers import DefaultRouter

from apps.bids.views import BidProjectViewSet, DocumentViewSet

# Register ViewSets
router = DefaultRouter()
router.register(r"bids", BidProjectViewSet, basename="bidproject")

# Nested document routes (must be before the main router include)
# Documents are nested under bids: /api/v1/bids/{bid_pk}/documents/
bid_nested_urls = [
    path(
        "<uuid:bid_pk>/documents/",
        DocumentViewSet.as_view({
            "get": "list",
            "post": "create",
        }),
        name="bid-document-list",
    ),
    path(
        "<uuid:bid_pk>/documents/<uuid:pk>/",
        DocumentViewSet.as_view({
            "get": "retrieve",
            "delete": "destroy",
        }),
        name="bid-document-detail",
    ),
    path(
        "<uuid:bid_pk>/documents/<uuid:pk>/download/",
        DocumentViewSet.as_view({
            "get": "download",
        }),
        name="bid-document-download",
    ),
]

urlpatterns = [
    path("", include(router.urls)),
    # Nested document routes must come after the main router
    # to avoid URL collision with bid detail endpoint
] + bid_nested_urls
