"""BidProject and Document models for the Bid/Tender Management module."""

from django.db import models
from django.core.exceptions import ValidationError
from django.utils import timezone

from uuid7 import uuid7

from apps.common.models import (
    UUIDv7ModelMixin,
    TimestampMixin,
    SoftDeleteModel,
    DataIsolationManager,
    ActiveManager,
)


# ---------------------------------------------------------------------------
# BidProject Status Choices
# ---------------------------------------------------------------------------

BID_STATUS_WATCHING = "watching"
BID_STATUS_PREPARING = "preparing"
BID_STATUS_SUBMITTED = "submitted"
BID_STATUS_WON = "won"
BID_STATUS_LOST = "lost"

BID_STATUS_CHOICES = [
    (BID_STATUS_WATCHING, "Watching"),
    (BID_STATUS_PREPARING, "Preparing"),
    (BID_STATUS_SUBMITTED, "Submitted"),
    (BID_STATUS_WON, "Won"),
    (BID_STATUS_LOST, "Lost"),
]


# ---------------------------------------------------------------------------
# Document File Type Choices
# ---------------------------------------------------------------------------

DOC_TYPE_TECHNICAL = "technical"
DOC_TYPE_COMMERCIAL = "commercial"
DOC_TYPE_QUALIFICATION = "qualification"
DOC_TYPE_CONTRACT_SCAN = "contract_scan"

DOCUMENT_TYPE_CHOICES = [
    (DOC_TYPE_TECHNICAL, "Technical"),
    (DOC_TYPE_COMMERCIAL, "Commercial"),
    (DOC_TYPE_QUALIFICATION, "Qualification"),
    (DOC_TYPE_CONTRACT_SCAN, "Contract Scan"),
]


# ---------------------------------------------------------------------------
# BidProject Model
# ---------------------------------------------------------------------------

class BidProject(UUIDv7ModelMixin, TimestampMixin, SoftDeleteModel):
    """Represents a bidding/tender project.

    Inherits SoftDeleteModel for soft deletion and UUIDv7ModelMixin for
    timestamp-ordered primary keys. Uses DataIsolationManager with
    isolation_field='created_by' so sales reps see only their own bids,
    managers see department bids, and admins see everything.
    """

    title = models.CharField(max_length=255)
    customer = models.ForeignKey(
        "customers.Customer",
        on_delete=models.PROTECT,
        related_name="bid_projects",
        db_index=True,
    )
    bidding_org = models.CharField(max_length=255, verbose_name="Bidding Organization")
    bid_deadline = models.DateTimeField(verbose_name="Bid Deadline")
    bid_opening_date = models.DateTimeField(null=True, blank=True, verbose_name="Bid Opening Date")
    status = models.CharField(max_length=20, choices=BID_STATUS_CHOICES, default=BID_STATUS_WATCHING)
    estimated_amount = models.DecimalField(max_digits=14, decimal_places=2, default=0)
    description = models.TextField(blank=True)
    assigned_team = models.ManyToManyField(
        "users.User",
        related_name="bid_projects_team",
        blank=True,
    )
    created_by = models.ForeignKey(
        "users.User",
        on_delete=models.PROTECT,
        related_name="created_bid_projects",
    )

    # Data isolation: filter by created_by
    _isolation_field = "created_by"

    objects = DataIsolationManager()
    all_objects = models.Manager()

    class Meta(UUIDv7ModelMixin.Meta, TimestampMixin.Meta, SoftDeleteModel.Meta):
        verbose_name = "Bid Project"
        verbose_name_plural = "Bid Projects"
        ordering = ["-created_at"]

    def __str__(self):
        return self.title


# ---------------------------------------------------------------------------
# Document Model
# ---------------------------------------------------------------------------

class DocumentManager(ActiveManager):
    """Manager for Document model (no soft delete, no isolation)."""
    pass


class Document(UUIDv7ModelMixin, TimestampMixin):
    """Represents a file attachment for a BidProject or Contract.

    Uses physical ForeignKeys (bid_project and contract) instead of
    GenericForeignKey for proper database integrity and select_related
    prefetching. Business rule: exactly one of bid_project or contract
    must be non-null (enforced in clean()).

    Document does NOT inherit SoftDeleteModel because documents are
    version-tracked and deletion is physical.
    """

    bid_project = models.ForeignKey(
        "bids.BidProject",
        on_delete=models.CASCADE,
        related_name="documents",
        null=True,
        blank=True,
    )
    contract = models.ForeignKey(
        "contracts.Contract",
        on_delete=models.CASCADE,
        related_name="documents",
        null=True,
        blank=True,
    )
    file = models.FileField(upload_to="documents/%Y/%m/")
    file_name = models.CharField(max_length=255)
    file_type = models.CharField(max_length=20, choices=DOCUMENT_TYPE_CHOICES)
    version = models.IntegerField(default=1)
    uploaded_by = models.ForeignKey(
        "users.User",
        on_delete=models.PROTECT,
        related_name="uploaded_documents",
    )

    objects = DocumentManager()

    class Meta(UUIDv7ModelMixin.Meta, TimestampMixin.Meta):
        verbose_name = "Document"
        verbose_name_plural = "Documents"
        ordering = ["-created_at"]

    def clean(self):
        """Enforce that exactly one of bid_project or contract is set."""
        super().clean()
        if self.bid_project and self.contract:
            raise ValidationError(
                "Document must have exactly one parent: either bid_project or contract, not both."
            )
        if not self.bid_project and not self.contract:
            raise ValidationError(
                "Document must have exactly one parent: either bid_project or contract must be set."
            )

    def __str__(self):
        return f"{self.file_name} (v{self.version})"
