"""Django admin registration for Bid/Tender Management module."""

from django.contrib import admin

from apps.bids.models import BidProject, Document


@admin.register(BidProject)
class BidProjectAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "title",
        "customer",
        "bidding_org",
        "status",
        "bid_deadline",
        "estimated_amount",
        "created_by",
        "created_at",
        "is_deleted",
    )
    list_filter = ("status", "is_deleted")
    search_fields = ("title", "bidding_org")
    raw_id_fields = ("customer", "created_by")
    filter_horizontal = ("assigned_team",)

    def get_queryset(self, request):
        """Show both active and soft-deleted records in admin."""
        return BidProject.all_objects.all()


@admin.register(Document)
class DocumentAdmin(admin.ModelAdmin):
    list_display = (
        "id",
        "file_name",
        "file_type",
        "version",
        "bid_project",
        "contract",
        "uploaded_by",
        "uploaded_at",
    )
    list_filter = ("file_type",)
    search_fields = ("file_name",)
    raw_id_fields = ("bid_project", "contract", "uploaded_by")
