"""Filter set for BidProject list endpoint."""

import django_filters
from django.utils import timezone


class BidProjectFilterSet(django_filters.FilterSet):
    """Filters for BidProject list endpoint.

    Supports filtering by:
    - status: exact match on bid status
    - customer: exact match on customer UUID
    - created_by: exact match on creator UUID
    - deadline_after: bid_deadline >= value (ISO datetime)
    - deadline_before: bid_deadline <= value (ISO datetime)
    """

    deadline_after = django_filters.DateTimeFilter(field_name="bid_deadline", lookup_expr="gte")
    deadline_before = django_filters.DateTimeFilter(field_name="bid_deadline", lookup_expr="lte")

    class Meta:
        from apps.bids.models import BidProject

        model = BidProject
        fields = {
            "status": ["exact"],
            "customer": ["exact"],
            "created_by": ["exact"],
        }
