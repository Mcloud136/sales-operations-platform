"""Tests for data isolation on BidProject model."""

import pytest
from rest_framework.test import APIClient

from apps.common.models import set_isolation_user, reset_isolation_user


@pytest.fixture
def two_users():
    """Create two sales_rep users in different departments."""
    from apps.users.models import User

    user_a = User.objects.create_user(
        username="iso_user_a",
        email="iso_a@example.com",
        role="sales_rep",
        password="testpass123",
    )
    user_b = User.objects.create_user(
        username="iso_user_b",
        email="iso_b@example.com",
        role="sales_rep",
        password="testpass123",
    )
    return user_a, user_b


@pytest.mark.django_db
def test_sales_rep_sees_own_bids_only(two_users, bid_project_attrs):
    """A sales_rep should only see bids they created."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject

    user_a, user_b = two_users
    customer = Customer.objects.create(
        name="Iso Customer",
        industry="technology",
        contact_person="Iso Contact",
        contact_phone="555-3000",
        contact_email="iso@isocustomer.com",
        address="700 Iso St",
        level="normal",
        source="self_developed",
        assigned_to=user_a,
    )

    bid_a = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Iso Board A",
        created_by=user_a,
    )
    bid_a.save()

    bid_b = BidProject(
        title="Other Bid",
        customer=customer,
        bidding_org="Iso Board B",
        bid_deadline=bid_project_attrs["bid_deadline"],
        status="watching",
        estimated_amount=100000,
        created_by=user_b,
    )
    bid_b.save()

    # User A sees only their own bid
    set_isolation_user(user_a)
    bids_for_a = list(BidProject.objects.all())
    assert len(bids_for_a) == 1
    assert bids_for_a[0].id == bid_a.id
    reset_isolation_user()

    # User B sees only their own bid
    set_isolation_user(user_b)
    bids_for_b = list(BidProject.objects.all())
    assert len(bids_for_b) == 1
    assert bids_for_b[0].id == bid_b.id
    reset_isolation_user()


@pytest.mark.django_db
def test_system_admin_sees_all_bids(two_users, bid_project_attrs):
    """A system_admin should see all bids regardless of creator."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject

    user_a, user_b = two_users
    admin_user = User.objects.create_user(
        username="iso_admin",
        email="iso_admin@example.com",
        role="system_admin",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Admin Iso Customer",
        industry="technology",
        contact_person="Admin Contact",
        contact_phone="555-3100",
        contact_email="admin@isocustomer.com",
        address="800 Admin St",
        level="normal",
        source="self_developed",
        assigned_to=user_a,
    )

    BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Admin Board A",
        created_by=user_a,
    ).save()

    BidProject(
        title="Admin Other Bid",
        customer=customer,
        bidding_org="Admin Board B",
        bid_deadline=bid_project_attrs["bid_deadline"],
        status="watching",
        estimated_amount=200000,
        created_by=user_b,
    ).save()

    # Admin sees all
    set_isolation_user(admin_user)
    all_bids = list(BidProject.objects.all())
    assert len(all_bids) == 2
    reset_isolation_user()


@pytest.mark.django_db
def test_sales_manager_sees_department_bids(two_users, bid_project_attrs):
    """A sales_manager should see bids created by anyone in their department."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject

    # Create a department
    from apps.users.models import Department  # May not exist yet; fallback
    dept = None  # If Department model doesn't exist, manager falls back to own bids

    user_a, user_b = two_users
    manager = User.objects.create_user(
        username="iso_manager",
        email="iso_manager@example.com",
        role="sales_manager",
        password="testpass123",
    )

    customer = Customer.objects.create(
        name="Mgr Iso Customer",
        industry="technology",
        contact_person="Mgr Contact",
        contact_phone="555-3200",
        contact_email="mgr@isocustomer.com",
        address="900 Mgr St",
        level="normal",
        source="self_developed",
        assigned_to=user_a,
    )

    BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Mgr Board",
        created_by=user_a,
    ).save()

    # Without explicit department, manager sees only their own bids
    set_isolation_user(manager)
    mgr_bids = list(BidProject.objects.all())
    assert len(mgr_bids) == 0  # Manager didn't create any bids
    reset_isolation_user()


@pytest.mark.django_db
def test_api_isolation_enforced(two_users, bid_project_attrs):
    """API should enforce data isolation -- user cannot see other user's bids."""
    from apps.customers.models import Customer
    from apps.bids.models import BidProject

    user_a, user_b = two_users
    customer = Customer.objects.create(
        name="API Iso Customer",
        industry="technology",
        contact_person="API Iso Contact",
        contact_phone="555-3300",
        contact_email="apiiso@isocustomer.com",
        address="1000 ApiIso St",
        level="normal",
        source="self_developed",
        assigned_to=user_a,
    )

    BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="API Iso Board",
        created_by=user_a,
    ).save()

    # User B should NOT see user A's bid via API
    client_b = APIClient()
    client_b.force_authenticate(user=user_b)
    response = client_b.get("/api/v1/bids/")
    assert response.status_code == 200
    assert len(response.data["results"]) == 0
