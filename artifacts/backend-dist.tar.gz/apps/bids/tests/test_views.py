import pytest
from django.utils import timezone
from datetime import timedelta
from rest_framework.test import APIClient


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def authenticated_client(api_client):
    """Return an API client authenticated as a sales_rep user."""
    from apps.users.models import User
    from apps.customers.models import Customer

    user = User.objects.create_user(
        username="apitest_user",
        email="apitest@example.com",
        role="sales_rep",
        password="testpass123",
    )
    Customer.objects.create(
        name="API Test Customer",
        industry="technology",
        contact_person="API Contact",
        contact_phone="555-2000",
        contact_email="api@testcustomer.com",
        address="600 API St",
        level="normal",
        source="self_developed",
        assigned_to=user,
    )
    api_client.force_authenticate(user=user)
    api_client.user = user
    return api_client


@pytest.fixture
def bid_project(authenticated_client, bid_project_attrs):
    """Create a bid project owned by the authenticated user."""
    from apps.customers.models import Customer
    from apps.bids.models import BidProject

    user = authenticated_client.user
    customer = Customer.objects.get(name="API Test Customer")

    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="API Test Board",
        created_by=user,
    )
    bid.save()
    return bid


# ---------------------------------------------------------------------------
# BidProject List endpoint
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_bid_list_returns_user_bids(authenticated_client, bid_project):
    """GET /api/v1/bids/ should return bids created by the current user."""
    response = authenticated_client.get("/api/v1/bids/")
    assert response.status_code == 200
    results = response.data["results"]
    assert len(results) >= 1
    assert any(str(bid_project.id) == r["id"] for r in results)


@pytest.mark.django_db
def test_bid_list_includes_days_remaining(authenticated_client, bid_project):
    """Bid list should include days_remaining field."""
    response = authenticated_client.get("/api/v1/bids/")
    assert response.status_code == 200
    result = next(r for r in response.data["results"] if r["id"] == str(bid_project.id))
    assert "days_remaining" in result
    assert result["days_remaining"] > 0


@pytest.mark.django_db
def test_bid_list_filters_by_status(authenticated_client, bid_project):
    """GET /api/v1/bids/?status=preparing should filter results."""
    response = authenticated_client.get("/api/v1/bids/", {"status": "preparing"})
    assert response.status_code == 200
    results = response.data["results"]
    assert all(r["status"] == "preparing" for r in results)


@pytest.mark.django_db
def test_bid_list_filters_by_deadline_range(authenticated_client, bid_project):
    """GET /api/v1/bids/?deadline_after and deadline_before should filter."""
    from apps.bids.models import BidProject
    now = timezone.now()

    # Create a bid with a different deadline
    future_bid = BidProject(
        title="Far Future Bid",
        customer=bid_project.customer,
        bidding_org="Future Board",
        bid_deadline=now + timedelta(days=90),
        status="watching",
        estimated_amount=100000,
        created_by=authenticated_client.user,
    )
    future_bid.save()

    response = authenticated_client.get("/api/v1/bids/", {
        "deadline_after": (now + timedelta(days=60)).isoformat(),
    })
    assert response.status_code == 200
    results = response.data["results"]
    assert any(str(future_bid.id) == r["id"] for r in results)
    assert not any(str(bid_project.id) == r["id"] for r in results)


# ---------------------------------------------------------------------------
# BidProject CRUD
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_bid_create(authenticated_client, bid_project_attrs):
    """POST /api/v1/bids/ should create a new bid project."""
    from apps.customers.models import Customer

    customer = Customer.objects.get(name="API Test Customer")
    data = {
        "title": "API Created Bid",
        "customer": str(customer.id),
        "bidding_org": "API Created Board",
        "bid_deadline": bid_project_attrs["bid_deadline"].isoformat(),
        "status": "watching",
        "estimated_amount": "200000.00",
        "description": "Created via API test.",
    }

    response = authenticated_client.post("/api/v1/bids/", data, format="json")
    assert response.status_code == 201
    assert response.data["title"] == "API Created Bid"
    assert response.data["created_by"] == str(authenticated_client.user.id)


@pytest.mark.django_db
def test_bid_detail_retrieve(authenticated_client, bid_project):
    """GET /api/v1/bids/{id}/ should return full bid detail."""
    response = authenticated_client.get(f"/api/v1/bids/{bid_project.id}/")
    assert response.status_code == 200
    assert response.data["title"] == "City Water Supply Upgrade"
    assert "description" in response.data
    assert "assigned_team" in response.data
    assert "document_count" in response.data


@pytest.mark.django_db
def test_bid_update(authenticated_client, bid_project):
    """PATCH /api/v1/bids/{id}/ should update bid fields."""
    data = {"status": "submitted", "description": "Updated description."}
    response = authenticated_client.patch(
        f"/api/v1/bids/{bid_project.id}/", data, format="json"
    )
    assert response.status_code == 200
    assert response.data["status"] == "submitted"
    assert response.data["description"] == "Updated description."


@pytest.mark.django_db
def test_bid_soft_delete(authenticated_client, bid_project):
    """DELETE /api/v1/bids/{id}/ should soft-delete the bid."""
    response = authenticated_client.delete(f"/api/v1/bids/{bid_project.id}/")
    assert response.status_code == 204

    # Should not appear in list
    response = authenticated_client.get("/api/v1/bids/")
    results = response.data["results"]
    assert not any(str(bid_project.id) == r["id"] for r in results)


# ---------------------------------------------------------------------------
# Document CRUD
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_document_upload(authenticated_client, bid_project):
    """POST /api/v1/bids/{id}/documents/ should upload a document."""
    from django.core.files.uploadedfile import SimpleUploadedFile

    fake_file = SimpleUploadedFile("test_doc.pdf", b"test content", content_type="application/pdf")

    data = {
        "file": fake_file,
        "file_name": "test_upload.pdf",
        "file_type": "technical",
    }
    response = authenticated_client.post(
        f"/api/v1/bids/{bid_project.id}/documents/", data, format="multipart"
    )
    assert response.status_code == 201
    assert response.data["file_name"] == "test_upload.pdf"
    assert response.data["file_type"] == "technical"
    assert response.data["version"] == 1


@pytest.mark.django_db
def test_document_version_increment(authenticated_client, bid_project):
    """Uploading a document with the same file_name should auto-increment version."""
    from django.core.files.uploadedfile import SimpleUploadedFile

    fake_file_v1 = SimpleUploadedFile("v1.pdf", b"v1", content_type="application/pdf")
    fake_file_v2 = SimpleUploadedFile("v2.pdf", b"v2", content_type="application/pdf")

    data_v1 = {
        "file": fake_file_v1,
        "file_name": "proposal.pdf",
        "file_type": "technical",
    }
    data_v2 = {
        "file": fake_file_v2,
        "file_name": "proposal.pdf",
        "file_type": "technical",
    }

    resp1 = authenticated_client.post(
        f"/api/v1/bids/{bid_project.id}/documents/", data_v1, format="multipart"
    )
    assert resp1.status_code == 201
    assert resp1.data["version"] == 1

    resp2 = authenticated_client.post(
        f"/api/v1/bids/{bid_project.id}/documents/", data_v2, format="multipart"
    )
    assert resp2.status_code == 201
    assert resp2.data["version"] == 2


@pytest.mark.django_db
def test_document_list(authenticated_client, bid_project):
    """GET /api/v1/bids/{id}/documents/ should list documents for the bid."""
    from django.core.files.uploadedfile import SimpleUploadedFile

    fake_file = SimpleUploadedFile("list.pdf", b"list content", content_type="application/pdf")
    data = {"file": fake_file, "file_name": "list_test.pdf", "file_type": "commercial"}
    authenticated_client.post(
        f"/api/v1/bids/{bid_project.id}/documents/", data, format="multipart"
    )

    response = authenticated_client.get(f"/api/v1/bids/{bid_project.id}/documents/")
    assert response.status_code == 200
    assert len(response.data) >= 1


@pytest.mark.django_db
def test_document_download(authenticated_client, bid_project):
    """GET /api/v1/bids/{id}/documents/{doc_id}/download/ should return the file."""
    from django.core.files.uploadedfile import SimpleUploadedFile
    from apps.bids.models import Document

    fake_file = SimpleUploadedFile("dl.pdf", b"download content", content_type="application/pdf")
    data = {"file": fake_file, "file_name": "download_test.pdf", "file_type": "qualification"}
    resp = authenticated_client.post(
        f"/api/v1/bids/{bid_project.id}/documents/", data, format="multipart"
    )
    doc_id = resp.data["id"]

    response = authenticated_client.get(
        f"/api/v1/bids/{bid_project.id}/documents/{doc_id}/download/"
    )
    assert response.status_code == 200
    assert b"download content" == response.content


@pytest.mark.django_db
def test_document_upload_missing_file_type(authenticated_client, bid_project):
    """Uploading without file_type should fail validation."""
    from django.core.files.uploadedfile import SimpleUploadedFile

    fake_file = SimpleUploadedFile("bad.pdf", b"bad", content_type="application/pdf")
    data = {
        "file": fake_file,
        "file_name": "bad.pdf",
    }
    response = authenticated_client.post(
        f"/api/v1/bids/{bid_project.id}/documents/", data, format="multipart"
    )
    assert response.status_code == 400
    assert "file_type" in response.data
