"""Tests for BidProjectFilterSet."""

import pytest
from datetime import timedelta
from django.utils import timezone


@pytest.fixture
def two_users():
    """Create two sales_rep users for filter tests."""
    from apps.users.models import User

    user_a = User.objects.create_user(
        username="filter_user_a",
        email="filter_a@example.com",
        role="sales_rep",
        password="testpass123",
    )
    user_b = User.objects.create_user(
        username="filter_user_b",
        email="filter_b@example.com",
        role="sales_rep",
        password="testpass123",
    )
    return user_a, user_b


@pytest.mark.django_db
def test_filter_by_status(bid_project_attrs, two_users):
    """BidProjectFilterSet should filter by status."""
    from apps.customers.models import Customer
    from apps.bids.models import BidProject
    from apps.common.models import set_isolation_user, reset_isolation_user

    user_a, _ = two_users
    customer = Customer.objects.create(
        name="Filter Customer",
        industry="technology",
        contact_person="Filter Contact",
        contact_phone="555-4000",
        contact_email="filter@filtercustomer.com",
        address="1100 Filter St",
        level="normal",
        source="self_developed",
        assigned_to=user_a,
    )

    BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Filter Board 1",
        created_by=user_a,
    ).save()

    BidProject(
        title="Watch Bid",
        customer=customer,
        bidding_org="Filter Board 2",
        bid_deadline=bid_project_attrs["bid_deadline"],
        status="watching",
        estimated_amount=300000,
        created_by=user_a,
    ).save()

    set_isolation_user(user_a)

    from apps.bids.filters import BidProjectFilterSet

    qs = BidProject.objects.all()
    filtered = BidProjectFilterSet(data={"status": "watching"}, queryset=qs)
    assert filtered.qs.count() == 1
    assert filtered.qs.first().status == "watching"

    reset_isolation_user()


@pytest.mark.django_db
def test_filter_by_deadline_range(bid_project_attrs, two_users):
    """BidProjectFilterSet should filter by deadline_after and deadline_before."""
    from apps.customers.models import Customer
    from apps.bids.models import BidProject
    from apps.common.models import set_isolation_user, reset_isolation_user

    user_a, _ = two_users
    customer = Customer.objects.create(
        name="Deadline Filter Customer",
        industry="technology",
        contact_person="Dl Contact",
        contact_phone="555-4100",
        contact_email="dl@dlcustomer.com",
        address="1200 Dl St",
        level="normal",
        source="self_developed",
        assigned_to=user_a,
    )

    now = timezone.now()

    bid_near = BidProject(
        title="Near Deadline Bid",
        customer=customer,
        bidding_org="Deadline Board 1",
        bid_deadline=now + timedelta(days=10),
        status="preparing",
        estimated_amount=100000,
        created_by=user_a,
    )
    bid_near.save()

    bid_far = BidProject(
        title="Far Deadline Bid",
        customer=customer,
        bidding_org="Deadline Board 2",
        bid_deadline=now + timedelta(days=60),
        status="preparing",
        estimated_amount=200000,
        created_by=user_a,
    )
    bid_far.save()

    set_isolation_user(user_a)

    from apps.bids.filters import BidProjectFilterSet

    qs = BidProject.objects.all()

    # Filter to deadlines within 20 days
    filtered = BidProjectFilterSet(
        data={
            "deadline_after": now.isoformat(),
            "deadline_before": (now + timedelta(days=20)).isoformat(),
        },
        queryset=qs,
    )
    assert filtered.qs.count() == 1
    assert filtered.qs.first().title == "Near Deadline Bid"

    reset_isolation_user()


@pytest.mark.django_db
def test_filter_by_customer(bid_project_attrs, two_users):
    """BidProjectFilterSet should filter by customer UUID."""
    from apps.customers.models import Customer
    from apps.bids.models import BidProject
    from apps.common.models import set_isolation_user, reset_isolation_user

    user_a, _ = two_users
    customer_a = Customer.objects.create(
        name="Customer A Filter",
        industry="technology",
        contact_person="A Contact",
        contact_phone="555-4200",
        contact_email="a@afilter.com",
        address="1300 A St",
        level="normal",
        source="self_developed",
        assigned_to=user_a,
    )
    customer_b = Customer.objects.create(
        name="Customer B Filter",
        industry="technology",
        contact_person="B Contact",
        contact_phone="555-4300",
        contact_email="b@bfilter.com",
        address="1400 B St",
        level="normal",
        source="self_developed",
        assigned_to=user_a,
    )

    BidProject(
        **bid_project_attrs,
        customer=customer_a,
        bidding_org="Customer Filter Board A",
        created_by=user_a,
    ).save()

    BidProject(
        title="Customer B Bid",
        customer=customer_b,
        bidding_org="Customer Filter Board B",
        bid_deadline=bid_project_attrs["bid_deadline"],
        status="watching",
        estimated_amount=150000,
        created_by=user_a,
    ).save()

    set_isolation_user(user_a)

    from apps.bids.filters import BidProjectFilterSet

    qs = BidProject.objects.all()
    filtered = BidProjectFilterSet(
        data={"customer": str(customer_a.id)},
        queryset=qs,
    )
    assert filtered.qs.count() == 1
    assert filtered.qs.first().customer == customer_a

    reset_isolation_user()
