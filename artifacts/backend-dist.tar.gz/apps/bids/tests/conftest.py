import pytest
from datetime import datetime, timedelta, timezone
from django.utils import timezone as django_timezone


@pytest.fixture
def future_deadline():
    """Return a deadline 30 days from now."""
    return django_timezone.now() + timedelta(days=30)


@pytest.fixture
def past_deadline():
    """Return a deadline 5 days ago."""
    return django_timezone.now() - timedelta(days=5)


@pytest.fixture
def urgent_deadline():
    """Return a deadline 3 days from now (urgency zone)."""
    return django_timezone.now() + timedelta(days=3)


@pytest.fixture
def bid_project_attrs(future_deadline):
    """Dictionary of attributes for creating a BidProject."""
    return {
        "title": "City Water Supply Upgrade",
        "bid_deadline": future_deadline,
        "bid_opening_date": future_deadline + timedelta(days=1),
        "status": "preparing",
        "estimated_amount": 500000,
        "description": "Upgrade water supply infrastructure for the city.",
    }
