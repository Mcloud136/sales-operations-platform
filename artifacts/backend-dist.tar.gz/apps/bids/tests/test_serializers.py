import pytest
from datetime import timedelta
from django.utils import timezone


@pytest.mark.django_db
def test_bid_project_list_serializer_fields(bid_project_attrs):
    """BidProjectListSerializer should include expected list-view fields."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject
    from apps.bids.serializers import BidProjectListSerializer

    user = User.objects.create_user(
        username="ser_user1",
        email="ser1@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Ser Customer",
        industry="manufacturing",
        contact_person="Ser Contact",
        contact_phone="555-1000",
        contact_email="ser@sercustomer.com",
        address="100 Ser Ave",
        level="normal",
        source="self_developed",
        assigned_to=user,
    )
    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Manufacturing Board",
        created_by=user,
    )
    bid.save()

    serializer = BidProjectListSerializer(bid)
    data = serializer.data

    assert "id" in data
    assert "title" in data
    assert "status" in data
    assert "bid_deadline" in data
    assert "estimated_amount" in data
    assert "customer" in data
    assert "customer_name" in data
    assert "days_remaining" in data
    # Detail-only fields should NOT appear
    assert "description" not in data
    assert "assigned_team" not in data


@pytest.mark.django_db
def test_bid_project_detail_serializer_fields(bid_project_attrs):
    """BidProjectDetailSerializer should include all fields including description and team."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject
    from apps.bids.serializers import BidProjectDetailSerializer

    user_a = User.objects.create_user(
        username="ser_user2",
        email="ser2@example.com",
        role="sales_rep",
        password="testpass123",
    )
    user_b = User.objects.create_user(
        username="ser_user3",
        email="ser3@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Detail Customer",
        industry="logistics",
        contact_person="Detail Contact",
        contact_phone="555-1100",
        contact_email="detail@detailcustomer.com",
        address="200 Detail Blvd",
        level="important",
        source="exhibition",
        assigned_to=user_a,
    )
    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Logistics Authority",
        created_by=user_a,
    )
    bid.save()
    bid.assigned_team.set([user_a, user_b])

    serializer = BidProjectDetailSerializer(bid)
    data = serializer.data

    assert "description" in data
    assert "assigned_team" in data
    assert "bidding_org" in data
    assert "bid_opening_date" in data
    assert len(data["assigned_team"]) == 2
    assert "customer_name" in data


@pytest.mark.django_db
def test_bid_project_create_serializer(bid_project_attrs):
    """BidProjectCreateSerializer should create a BidProject with valid data."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.serializers import BidProjectCreateSerializer

    user = User.objects.create_user(
        username="ser_user4",
        email="ser4@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Create Customer",
        industry="telecom",
        contact_person="Create Contact",
        contact_phone="555-1200",
        contact_email="create@createcustomer.com",
        address="300 Create Rd",
        level="normal",
        source="referral",
        assigned_to=user,
    )

    data = {
        "title": "New Telecom Infrastructure",
        "customer": str(customer.id),
        "bidding_org": "Telecom Commission",
        "bid_deadline": bid_project_attrs["bid_deadline"].isoformat(),
        "status": "watching",
        "estimated_amount": "750000.00",
        "description": "Build new 5G towers.",
    }

    serializer = BidProjectCreateSerializer(data=data, context={"request": type("Request", (), {"user": user})()})
    assert serializer.is_valid(raise_exception=True)

    bid = serializer.save(created_by=user)
    assert bid.title == "New Telecom Infrastructure"
    assert bid.created_by == user
    assert bid.customer == customer


@pytest.mark.django_db
def test_bid_project_create_serializer_invalid_status():
    """BidProjectCreateSerializer should reject invalid status value."""
    from apps.bids.serializers import BidProjectCreateSerializer
    from apps.users.models import User

    user = User.objects.create_user(
        username="ser_user5",
        email="ser5@example.com",
        role="sales_rep",
        password="testpass123",
    )

    data = {
        "title": "Invalid Status Bid",
        "customer": "00000000-0000-0000-0000-000000000001",
        "bidding_org": "Test Org",
        "bid_deadline": (timezone.now() + timedelta(days=10)).isoformat(),
        "status": "invalid_status",
        "estimated_amount": "100000.00",
    }

    serializer = BidProjectCreateSerializer(data=data, context={"request": type("Request", (), {"user": user})()})
    assert not serializer.is_valid()
    assert "status" in serializer.errors


@pytest.mark.django_db
def test_document_serializer(bid_project_attrs):
    """DocumentSerializer should serialize document fields correctly."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject, Document
    from apps.bids.serializers import DocumentSerializer
    from django.core.files.uploadedfile import SimpleUploadedFile

    user = User.objects.create_user(
        username="ser_user6",
        email="ser6@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Doc Ser Customer",
        industry="mining",
        contact_person="Doc Ser Contact",
        contact_phone="555-1300",
        contact_email="docser@docsercustomer.com",
        address="400 Doc Ser Way",
        level="normal",
        source="self_developed",
        assigned_to=user,
    )
    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Mining Bureau",
        created_by=user,
    )
    bid.save()

    fake_file = SimpleUploadedFile("doc.pdf", b"content", content_type="application/pdf")
    doc = Document(
        bid_project=bid,
        file=fake_file,
        file_name="technical_proposal.pdf",
        file_type="technical",
        version=1,
        uploaded_by=user,
    )
    doc.save()

    serializer = DocumentSerializer(doc)
    data = serializer.data

    assert data["file_name"] == "technical_proposal.pdf"
    assert data["file_type"] == "technical"
    assert data["version"] == 1
    assert "file" in data
    assert "uploaded_by" in data


@pytest.mark.django_db
def test_document_serializer_upload(bid_project_attrs):
    """DocumentSerializer should create a Document from uploaded file data."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject, Document
    from apps.bids.serializers import DocumentUploadSerializer
    from django.core.files.uploadedfile import SimpleUploadedFile

    user = User.objects.create_user(
        username="ser_user7",
        email="ser7@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Upload Customer",
        industry="agriculture",
        contact_person="Upload Contact",
        contact_phone="555-1400",
        contact_email="upload@uploadcustomer.com",
        address="500 Upload Ln",
        level="normal",
        source="self_developed",
        assigned_to=user,
    )
    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Agriculture Board",
        created_by=user,
    )
    bid.save()

    fake_file = SimpleUploadedFile("upload.pdf", b"new upload", content_type="application/pdf")

    data = {
        "file": fake_file,
        "file_name": "upload_test.pdf",
        "file_type": "commercial",
    }

    serializer = DocumentUploadSerializer(data=data, context={
        "bid_project": bid,
        "request": type("Request", (), {"user": user})(),
    })
    assert serializer.is_valid(raise_exception=True)

    doc = serializer.save()
    assert doc.bid_project == bid
    assert doc.file_name == "upload_test.pdf"
    assert doc.file_type == "commercial"
    assert doc.version == 1
    assert doc.uploaded_by == user
