import pytest
from django.core.exceptions import ValidationError
from django.utils import timezone

from apps.bids.tests.conftest import (
    bid_project_attrs,
    future_deadline,
    past_deadline,
    urgent_deadline,
)


# ---------------------------------------------------------------------------
# BidProject model tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_bid_project_creation(bid_project_attrs):
    """BidProject should be creatable with required fields."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject

    user = User.objects.create_user(
        username="salesrep1",
        email="sales@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Water Corp",
        industry="utilities",
        contact_person="John Smith",
        contact_phone="555-0100",
        contact_email="john@watercorp.com",
        address="123 Water St",
        level="important",
        source="exhibition",
        assigned_to=user,
    )

    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="City Municipal Authority",
        created_by=user,
    )
    bid.save()

    assert bid.id is not None
    # UUIDv7 starts with 0-7
    assert str(bid.id)[0] in "01234567"
    assert bid.title == "City Water Supply Upgrade"
    assert bid.customer == customer
    assert bid.created_by == user
    assert bid.status == "preparing"
    assert bid.is_deleted is False


@pytest.mark.django_db
def test_bid_project_soft_delete(bid_project_attrs):
    """BidProject should support soft delete via SoftDeleteModel."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject

    user = User.objects.create_user(
        username="salesrep2",
        email="sales2@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Power Corp",
        industry="energy",
        contact_person="Jane Doe",
        contact_phone="555-0200",
        contact_email="jane@powercorp.com",
        address="456 Power Ave",
        level="strategic",
        source="referral",
        assigned_to=user,
    )
    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Regional Energy Board",
        created_by=user,
    )
    bid.save()

    bid.soft_delete()
    assert bid.is_deleted is True
    assert bid.deleted_at is not None

    # Active manager should exclude it
    assert bid.id not in BidProject.objects.values_list("id", flat=True)
    # all_objects should still include it
    assert bid.id in BidProject.all_objects.values_list("id", flat=True)


@pytest.mark.django_db
def test_bid_project_status_choices():
    """BidProject.status should only accept valid choices."""
    from apps.bids.models import BidProject

    valid_choices = [choice[0] for choice in BidProject._meta.get_field("status").choices]
    assert valid_choices == ["watching", "preparing", "submitted", "won", "lost"]


@pytest.mark.django_db
def test_bid_project_uses_data_isolation_manager():
    """BidProject.objects should be a DataIsolationManager."""
    from apps.bids.models import BidProject
    from apps.common.models import DataIsolationManager

    assert isinstance(BidProject.objects, DataIsolationManager)


@pytest.mark.django_db
def test_bid_project_isolation_field():
    """BidProject isolation field should be 'created_by'."""
    from apps.bids.models import BidProject

    assert BidProject._isolation_field == "created_by"


@pytest.mark.django_db
def test_bid_project_string_representation(bid_project_attrs):
    """BidProject.__str__ should return the title."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject

    user = User.objects.create_user(
        username="salesrep3",
        email="sales3@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Tech Corp",
        industry="technology",
        contact_person="Alice Brown",
        contact_phone="555-0300",
        contact_email="alice@techcorp.com",
        address="789 Tech Blvd",
        level="normal",
        source="self_developed",
        assigned_to=user,
    )
    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Digital Services Agency",
        created_by=user,
    )
    bid.save()

    assert str(bid) == "City Water Supply Upgrade"


@pytest.mark.django_db
def test_bid_project_assigned_team(bid_project_attrs):
    """BidProject should support many-to-many team assignment."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject

    user_a = User.objects.create_user(
        username="team_a",
        email="teama@example.com",
        role="sales_rep",
        password="testpass123",
    )
    user_b = User.objects.create_user(
        username="team_b",
        email="teamb@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Build Corp",
        industry="construction",
        contact_person="Bob Builder",
        contact_phone="555-0400",
        contact_email="bob@buildcorp.com",
        address="321 Build Rd",
        level="important",
        source="bidding_site",
        assigned_to=user_a,
    )
    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="City Planning Commission",
        created_by=user_a,
    )
    bid.save()
    bid.assigned_team.set([user_a, user_b])

    assert bid.assigned_team.count() == 2


# ---------------------------------------------------------------------------
# Document model tests
# ---------------------------------------------------------------------------

@pytest.mark.django_db
def test_document_creation_with_bid_project(bid_project_attrs):
    """Document can be created with a bid_project FK."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject, Document
    from django.core.files.uploadedfile import SimpleUploadedFile

    user = User.objects.create_user(
        username="doc_user1",
        email="doc1@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Doc Customer",
        industry="healthcare",
        contact_person="Doc Person",
        contact_phone="555-0500",
        contact_email="doc@doccustomer.com",
        address="100 Doc St",
        level="normal",
        source="self_developed",
        assigned_to=user,
    )
    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Health Authority",
        created_by=user,
    )
    bid.save()

    fake_file = SimpleUploadedFile("proposal.pdf", b"fake pdf content", content_type="application/pdf")
    doc = Document(
        bid_project=bid,
        contract=None,
        file=fake_file,
        file_name="proposal.pdf",
        file_type="technical",
        version=1,
        uploaded_by=user,
    )
    doc.save()

    assert doc.id is not None
    assert str(doc.id)[0] in "01234567"
    assert doc.bid_project == bid
    assert doc.contract is None
    assert doc.file_name == "proposal.pdf"
    assert doc.file_type == "technical"
    assert doc.version == 1


@pytest.mark.django_db
def test_document_clean_enforces_exactly_one_parent(bid_project_attrs):
    """Document.clean() should raise ValidationError if both or neither FKs are set."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject, Document
    from django.core.files.uploadedfile import SimpleUploadedFile

    user = User.objects.create_user(
        username="doc_user2",
        email="doc2@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Validation Customer",
        industry="finance",
        contact_person="Val Person",
        contact_phone="555-0600",
        contact_email="val@valcustomer.com",
        address="200 Val St",
        level="normal",
        source="self_developed",
        assigned_to=user,
    )
    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Finance Board",
        created_by=user,
    )
    bid.save()

    fake_file = SimpleUploadedFile("test.docx", b"fake content", content_type="application/vnd.openxmlformats-officedocument.wordprocessingml.document")

    # Case 1: Neither FK set
    doc_orphan = Document(
        bid_project=None,
        contract=None,
        file=fake_file,
        file_name="test.docx",
        file_type="commercial",
        version=1,
        uploaded_by=user,
    )
    with pytest.raises(ValidationError, match="must have exactly one"):
        doc_orphan.clean()

    # Case 2: Both FKs set (contract is None here so only bid_project set -- that is valid)
    # We test the "both set" case by temporarily setting contract as well.
    # Since we don't have a Contract model in this phase's scope, we simulate
    # by assigning contract to a non-None sentinel.
    doc_both = Document(
        bid_project=bid,
        contract=bid,  # type: ignore[arg-type]  # sentinel; not a real Contract
        file=fake_file,
        file_name="test.docx",
        file_type="commercial",
        version=1,
        uploaded_by=user,
    )
    with pytest.raises(ValidationError, match="must have exactly one"):
        doc_both.clean()


@pytest.mark.django_db
def test_document_file_type_choices():
    """Document.file_type should accept valid choices."""
    from apps.bids.models import Document

    valid_choices = [choice[0] for choice in Document._meta.get_field("file_type").choices]
    assert "technical" in valid_choices
    assert "commercial" in valid_choices
    assert "qualification" in valid_choices
    assert "contract_scan" in valid_choices


@pytest.mark.django_db
def test_document_version_tracking(bid_project_attrs):
    """Document version should auto-increment logic (manual test of default)."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject, Document
    from django.core.files.uploadedfile import SimpleUploadedFile

    user = User.objects.create_user(
        username="doc_user3",
        email="doc3@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Version Customer",
        industry="retail",
        contact_person="Ver Person",
        contact_phone="555-0700",
        contact_email="ver@vercustomer.com",
        address="300 Ver St",
        level="normal",
        source="self_developed",
        assigned_to=user,
    )
    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Retail Authority",
        created_by=user,
    )
    bid.save()

    fake_file = SimpleUploadedFile("v1.pdf", b"v1 content", content_type="application/pdf")
    doc_v1 = Document(
        bid_project=bid,
        file=fake_file,
        file_name="proposal.pdf",
        file_type="technical",
        version=1,
        uploaded_by=user,
    )
    doc_v1.save()

    fake_file_v2 = SimpleUploadedFile("v2.pdf", b"v2 content", content_type="application/pdf")
    doc_v2 = Document(
        bid_project=bid,
        file=fake_file_v2,
        file_name="proposal.pdf",
        file_type="technical",
        version=2,
        uploaded_by=user,
    )
    doc_v2.save()

    assert doc_v2.version == 2

    # Query all versions of the same file for this bid
    versions = Document.objects.filter(
        bid_project=bid,
        file_name="proposal.pdf",
        file_type="technical",
    ).order_by("version")
    assert versions.count() == 2


@pytest.mark.django_db
def test_document_does_not_inherit_soft_delete():
    """Document should NOT inherit SoftDeleteModel (it has no isolation field)."""
    from apps.bids.models import Document
    from apps.common.models import SoftDeleteModel

    # Document does NOT have is_deleted field
    assert not hasattr(Document, "is_deleted")
    # Document is NOT a SoftDeleteModel subclass
    assert not issubclass(Document, SoftDeleteModel)


@pytest.mark.django_db
def test_document_string_representation(bid_project_attrs):
    """Document.__str__ should return file_name with version."""
    from apps.users.models import User
    from apps.customers.models import Customer
    from apps.bids.models import BidProject, Document
    from django.core.files.uploadedfile import SimpleUploadedFile

    user = User.objects.create_user(
        username="doc_user4",
        email="doc4@example.com",
        role="sales_rep",
        password="testpass123",
    )
    customer = Customer.objects.create(
        name="Str Customer",
        industry="education",
        contact_person="Str Person",
        contact_phone="555-0800",
        contact_email="str@strcustomer.com",
        address="400 Str St",
        level="normal",
        source="self_developed",
        assigned_to=user,
    )
    bid = BidProject(
        **bid_project_attrs,
        customer=customer,
        bidding_org="Education Board",
        created_by=user,
    )
    bid.save()

    fake_file = SimpleUploadedFile("str.pdf", b"str content", content_type="application/pdf")
    doc = Document(
        bid_project=bid,
        file=fake_file,
        file_name="requirements.pdf",
        file_type="qualification",
        version=2,
        uploaded_by=user,
    )
    doc.save()

    assert str(doc) == "requirements.pdf (v2)"
